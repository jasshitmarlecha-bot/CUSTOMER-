import React, { useState } from 'react';
import {
  ShieldCheck,
  Lock,
  CheckCircle2,
  AlertCircle,
  X,
  Users,
  Eye,
  Plus,
  Trash2,
  Download,
  Upload,
  Printer,
  Tags,
  Sparkles,
  BarChart3,
  QrCode,
  Key,
  Save
} from 'lucide-react';
import { StaffPermissions } from '../../types/index.ts';

interface StaffAccessModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentPermissions: StaffPermissions;
  onSavePermissions: (permissions: StaffPermissions) => Promise<void>;
  onUpdatePassword: (role: 'admin' | 'staff', newPass: string) => Promise<void>;
}

export const StaffAccessModal: React.FC<StaffAccessModalProps> = ({
  isOpen,
  onClose,
  currentPermissions,
  onSavePermissions,
  onUpdatePassword
}) => {
  const [permissions, setPermissions] = useState<StaffPermissions>(currentPermissions);
  const [isSaving, setIsSaving] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Password update state
  const [targetRole, setTargetRole] = useState<'admin' | 'staff'>('staff');
  const [newPassword, setNewPassword] = useState('');
  const [passwordNotice, setPasswordNotice] = useState<string | null>(null);

  if (!isOpen) return null;

  const togglePermission = (key: keyof StaffPermissions) => {
    setPermissions(prev => ({
      ...prev,
      [key]: !prev[key]
    }));
  };

  const handleSelectAll = (val: boolean) => {
    setPermissions({
      canViewCustomers: val,
      canAddEditCustomers: val,
      canDeleteCustomers: val,
      canExportData: val,
      canImportData: val,
      canPrintData: val,
      canManageCategories: val,
      canRunCleaning: val,
      canViewAnalytics: val,
      canViewCommonQR: val
    });
  };

  const handleSave = async () => {
    setIsSaving(true);
    setErrorMessage(null);
    setSaveSuccess(false);
    try {
      await onSavePermissions(permissions);
      setSaveSuccess(true);
      setTimeout(() => setSaveSuccess(false), 2500);
    } catch (err: any) {
      setErrorMessage(err.message || 'Failed to update staff permissions.');
    } finally {
      setIsSaving(false);
    }
  };

  const handleChangePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPassword.trim() || newPassword.trim().length < 4) {
      setPasswordNotice('Password must be at least 4 characters long.');
      return;
    }
    try {
      await onUpdatePassword(targetRole, newPassword.trim());
      setPasswordNotice(`Password for ${targetRole.toUpperCase()} updated successfully!`);
      setNewPassword('');
      setTimeout(() => setPasswordNotice(null), 3000);
    } catch (err: any) {
      setPasswordNotice(err.message || 'Failed to update password.');
    }
  };

  const permissionItems: Array<{
    key: keyof StaffPermissions;
    label: string;
    description: string;
    icon: any;
  }> = [
    {
      key: 'canViewCustomers',
      label: 'View Customer Directory',
      description: 'Can see list of customers and search profiles',
      icon: Users
    },
    {
      key: 'canAddEditCustomers',
      label: 'Add & Edit Customer Records',
      description: 'Can create new walk-in entries and edit details',
      icon: Plus
    },
    {
      key: 'canDeleteCustomers',
      label: 'Delete Customer Records',
      description: 'Can remove profiles or purge customer records',
      icon: Trash2
    },
    {
      key: 'canExportData',
      label: 'Export Data (Excel & PDF)',
      description: 'Can download customer database into Excel spreadsheets and PDF',
      icon: Download
    },
    {
      key: 'canImportData',
      label: 'Import Outside Customer Data',
      description: 'Can upload spreadsheets (.xlsx / .csv) into the store database',
      icon: Upload
    },
    {
      key: 'canPrintData',
      label: 'Print Customer Data & Rosters',
      description: 'Can format and trigger printouts of customer records',
      icon: Printer
    },
    {
      key: 'canManageCategories',
      label: 'Manage Dynamic Categories',
      description: 'Can create, edit, or delete jewelry categories and colors',
      icon: Tags
    },
    {
      key: 'canRunCleaning',
      label: 'Data Cleaning & Deduplication',
      description: 'Can merge duplicates and run phone/email health cleaners',
      icon: Sparkles
    },
    {
      key: 'canViewAnalytics',
      label: 'Store & Footfall Analytics',
      description: 'Can view visitor conversion metrics and traffic trends',
      icon: BarChart3
    },
    {
      key: 'canViewCommonQR',
      label: 'Common Showroom QR Portal',
      description: 'Can view common QR code, scan tracker, and print QR displays',
      icon: QrCode
    }
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-[#050b18] border border-blue-900/40 rounded-2xl w-full max-w-2xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="p-5 border-b border-slate-800 flex items-center justify-between bg-black">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-blue-600/20 border border-blue-500/40 flex items-center justify-center text-blue-400">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white flex items-center gap-2">
                <span>Staff Access & Permission Control</span>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-blue-950 text-blue-300 border border-blue-800 font-semibold">
                  Admin Authority
                </span>
              </h2>
              <p className="text-xs text-slate-400">
                Grant or restrict which features Counter Staff can access in Giri Jewels system.
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <div className="p-5 overflow-y-auto space-y-6 flex-1">
          {errorMessage && (
            <div className="p-3 bg-red-950/80 border border-red-800 rounded-xl text-xs text-red-200 flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-red-400 shrink-0" />
              <span>{errorMessage}</span>
            </div>
          )}

          {saveSuccess && (
            <div className="p-3 bg-emerald-950/80 border border-emerald-800 rounded-xl text-xs text-emerald-200 flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>Staff permissions updated and active immediately!</span>
            </div>
          )}

          {/* Quick Select Actions */}
          <div className="flex items-center justify-between border-b border-slate-800 pb-2">
            <span className="text-xs font-bold text-slate-200">Counter Staff Feature Permissions</span>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => handleSelectAll(true)}
                className="text-[11px] text-blue-400 hover:underline cursor-pointer font-semibold"
              >
                Grant All
              </button>
              <span className="text-slate-600">•</span>
              <button
                type="button"
                onClick={() => handleSelectAll(false)}
                className="text-[11px] text-slate-400 hover:underline cursor-pointer"
              >
                Revoke All
              </button>
            </div>
          </div>

          {/* Permissions Checklist */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {permissionItems.map((item) => {
              const Icon = item.icon;
              const isChecked = permissions[item.key];
              return (
                <div
                  key={item.key}
                  onClick={() => togglePermission(item.key)}
                  className={`p-3 rounded-xl border cursor-pointer transition-all flex items-start gap-3 ${
                    isChecked
                      ? 'bg-blue-950/30 border-blue-500/50 shadow-xs'
                      : 'bg-black/40 border-slate-800 opacity-60 hover:opacity-100'
                  }`}
                >
                  <input
                    type="checkbox"
                    checked={isChecked}
                    onChange={() => {}}
                    className="mt-0.5 rounded border-slate-700 text-blue-600 focus:ring-0 cursor-pointer"
                  />
                  <div className="min-w-0">
                    <div className="flex items-center gap-1.5 font-semibold text-xs text-white">
                      <Icon className={`w-3.5 h-3.5 ${isChecked ? 'text-blue-400' : 'text-slate-500'}`} />
                      <span>{item.label}</span>
                    </div>
                    <p className="text-[11px] text-slate-400 mt-0.5 line-clamp-2">
                      {item.description}
                    </p>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Password Management Section */}
          <div className="pt-4 border-t border-slate-800 space-y-3">
            <div className="flex items-center gap-2 text-xs font-bold text-white">
              <Key className="w-4 h-4 text-blue-400" />
              <span>Update User Passwords</span>
            </div>

            <form onSubmit={handleChangePassword} className="bg-black p-4 rounded-xl border border-slate-800 space-y-3">
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block text-[11px] text-slate-400 mb-1">User Account</label>
                  <select
                    value={targetRole}
                    onChange={(e) => setTargetRole(e.target.value as 'admin' | 'staff')}
                    className="w-full text-xs p-2 bg-slate-900 border border-slate-700 rounded-lg text-white font-medium focus:outline-none"
                  >
                    <option value="staff">Counter Staff (staff@)</option>
                    <option value="admin">Store Admin (admin@)</option>
                  </select>
                </div>

                <div className="sm:col-span-2">
                  <label className="block text-[11px] text-slate-400 mb-1">New Password</label>
                  <div className="flex gap-2">
                    <input
                      type="text"
                      value={newPassword}
                      onChange={(e) => setNewPassword(e.target.value)}
                      placeholder="Enter new password (min 4 chars)..."
                      className="flex-1 text-xs px-3 py-2 bg-slate-900 border border-slate-700 rounded-lg text-white font-mono focus:outline-none focus:ring-1 focus:ring-blue-500"
                    />
                    <button
                      type="submit"
                      className="px-3.5 py-2 bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold rounded-lg transition-colors shrink-0 cursor-pointer"
                    >
                      Update
                    </button>
                  </div>
                </div>
              </div>

              {passwordNotice && (
                <p className="text-[11px] text-blue-400 font-medium">{passwordNotice}</p>
              )}
            </form>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-800 flex items-center justify-between bg-black">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold text-slate-400 hover:text-white transition-colors cursor-pointer"
          >
            Cancel
          </button>
          <button
            type="button"
            disabled={isSaving}
            onClick={handleSave}
            className="flex items-center gap-2 py-2 px-5 bg-blue-600 hover:bg-blue-500 disabled:opacity-40 text-white font-bold text-xs rounded-xl shadow-md transition-all cursor-pointer"
          >
            <Save className="w-3.5 h-3.5" />
            <span>{isSaving ? 'Saving Changes...' : 'Save Staff Permissions'}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
