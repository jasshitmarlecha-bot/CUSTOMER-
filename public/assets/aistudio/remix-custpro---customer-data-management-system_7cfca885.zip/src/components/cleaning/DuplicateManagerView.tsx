import React, { useState, useEffect } from 'react';
import {
  ShieldAlert,
  CopyCheck,
  CheckCircle2,
  RefreshCw,
  AlertTriangle,
  ArrowRight,
  Merge,
  Trash2,
  Phone,
  Mail,
  MapPin,
  Calendar,
  Sparkles,
  ExternalLink,
  ShieldCheck,
  Users,
  Search,
  Filter
} from 'lucide-react';
import { Customer, DuplicateGroup } from '../../types/index.ts';
import { getDuplicates, mergeCustomers, autoMergeDuplicates } from '../../api/client.ts';
import { ConfirmationModal } from '../common/ConfirmationModal.tsx';

interface DuplicateManagerViewProps {
  customers: Customer[];
  onRefreshAll: () => Promise<void>;
  onEditCustomer?: (customer: Customer) => void;
  onNavigateToDirectory: () => void;
}

export const DuplicateManagerView: React.FC<DuplicateManagerViewProps> = ({
  customers,
  onRefreshAll,
  onEditCustomer,
  onNavigateToDirectory
}) => {
  const [duplicateGroups, setDuplicateGroups] = useState<DuplicateGroup[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [isMerging, setIsMerging] = useState(false);
  const [filterReason, setFilterReason] = useState<'all' | 'phone' | 'email' | 'name_similar'>('all');
  const [statusMessage, setStatusMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);
  const [dismissedGroupIds, setDismissedGroupIds] = useState<Set<string>>(new Set());

  // Showroom Confirmation Modal State
  const [confirmModal, setConfirmModal] = useState<{
    isOpen: boolean;
    title: string;
    description: string;
    confirmText?: string;
    variant?: 'danger' | 'warning' | 'primary';
    itemDetails?: Array<{ label: string; value: string }>;
    onConfirm: () => Promise<void> | void;
  }>({
    isOpen: false,
    title: '',
    description: '',
    onConfirm: () => {}
  });

  const loadDuplicateData = async () => {
    setIsLoading(true);
    setStatusMessage(null);
    try {
      const groups = await getDuplicates();
      setDuplicateGroups(groups);
    } catch (err: any) {
      setStatusMessage({ type: 'error', text: `Failed to scan duplicates: ${err.message}` });
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadDuplicateData();
  }, [customers]);

  // Handle merging two customers in a group
  const handleMergeGroup = async (primary: Customer, duplicates: Customer[]) => {
    setIsMerging(true);
    setStatusMessage(null);
    try {
      const dupIds = duplicates.map(d => d.id);
      await mergeCustomers(primary.id, dupIds);
      setStatusMessage({
        type: 'success',
        text: `Successfully merged ${dupIds.length} duplicate record(s) into ${primary.name}. Customer phone and purchase notes preserved!`
      });
      await onRefreshAll();
      await loadDuplicateData();
    } catch (err: any) {
      setStatusMessage({ type: 'error', text: `Merge error: ${err.message}` });
    } finally {
      setIsMerging(false);
    }
  };

  // Prompt confirmation dialog before consolidating a single cluster
  const promptMergeGroup = (primary: Customer, duplicates: Customer[]) => {
    setConfirmModal({
      isOpen: true,
      title: `Merge ${duplicates.length} duplicate(s) into ${primary.name}?`,
      description: `This will consolidate duplicate entries into ${primary.name}'s verified master profile. All customer notes, categories, email, and preferences will be preserved without loss.`,
      variant: 'primary',
      confirmText: 'Unify Duplicate Profile',
      itemDetails: [
        { label: 'Master Profile', value: `${primary.name} (${primary.phone})` },
        { label: 'Duplicates to Merge', value: `${duplicates.length} duplicate row(s)` },
        { label: 'Profile Registered', value: primary.createdAt ? new Date(primary.createdAt).toLocaleDateString() : 'N/A' }
      ],
      onConfirm: async () => {
        await handleMergeGroup(primary, duplicates);
      }
    });
  };

  // 1-Click Auto-Merge exact phone matches with luxury confirmation dialogue
  const handleAutoMergeAll = () => {
    setConfirmModal({
      isOpen: true,
      title: `Auto-Merge ${exactPhoneGroupsCount} Exact Duplicate Groups?`,
      description: 'Auto-merge will safely unify all identical phone number records across your database into their earliest customer profiles. All notes, jewelry tags, and preferences will be combined.',
      variant: 'primary',
      confirmText: `Auto-Merge All (${exactPhoneGroupsCount} Groups)`,
      itemDetails: [
        { label: 'Duplicate Groups Found', value: `${exactPhoneGroupsCount} identical phone clusters` },
        { label: 'Preservation Rule', value: 'Earliest customer ID retained, notes combined' },
        { label: 'Target Showroom', value: 'Giri Jewels Active Customer Database' }
      ],
      onConfirm: async () => {
        setIsMerging(true);
        setStatusMessage(null);
        try {
          const res = await autoMergeDuplicates();
          setStatusMessage({
            type: 'success',
            text: res.message || `Successfully auto-merged ${res.mergedGroupCount} duplicate group(s).`
          });
          await onRefreshAll();
          await loadDuplicateData();
        } catch (err: any) {
          setStatusMessage({ type: 'error', text: `Auto-merge error: ${err.message}` });
        } finally {
          setIsMerging(false);
        }
      }
    });
  };

  // Dismiss a group if user verifies they are distinct people (e.g. husband and wife sharing a number)
  const handleDismissGroup = (groupId: string) => {
    setDismissedGroupIds(prev => new Set(prev).add(groupId));
  };

  // Visible groups after filter and dismiss
  const visibleGroups = duplicateGroups.filter(g => {
    if (dismissedGroupIds.has(g.id)) return false;
    if (filterReason !== 'all' && g.reason !== filterReason) return false;
    return true;
  });

  const totalDuplicateRecords = duplicateGroups.reduce((acc, g) => acc + g.customers.length, 0);
  const exactPhoneGroupsCount = duplicateGroups.filter(g => g.reason === 'phone').length;

  return (
    <div className="space-y-6">
      {/* 1. Header & Dedicated Operation Banner */}
      <div className="bg-[#050b18] border border-blue-900/40 rounded-2xl p-6 shadow-xl flex flex-col sm:flex-row sm:items-center justify-between gap-5">
        <div className="space-y-1.5">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-blue-600/20 text-blue-400 border border-blue-500/30 flex items-center justify-center">
              <ShieldAlert className="w-4 h-4" />
            </div>
            <h1 className="text-xl sm:text-2xl font-black text-white tracking-tight">
              Customer Duplicate Manager
            </h1>
            <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full bg-blue-950 text-blue-300 border border-blue-800">
              Store Operation
            </span>
          </div>
          <p className="text-xs sm:text-sm text-slate-300 max-w-2xl leading-relaxed">
            Scan and resolve duplicate phone numbers, email addresses, and duplicate entries from walk-in intake, QR scans, and bulk imports.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          <button
            onClick={loadDuplicateData}
            disabled={isLoading}
            className="px-3.5 py-2 text-xs font-semibold text-slate-300 hover:text-white bg-slate-900 hover:bg-slate-800 border border-slate-700 rounded-xl transition-all flex items-center gap-1.5 cursor-pointer"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isLoading ? 'animate-spin text-blue-400' : ''}`} />
            <span>Scan Database</span>
          </button>

          {exactPhoneGroupsCount > 0 && (
            <button
              onClick={handleAutoMergeAll}
              disabled={isMerging}
              className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white text-xs font-black rounded-xl shadow-lg transition-all flex items-center gap-2 cursor-pointer active:scale-98"
              title="Automatically merge identical phone duplicates across the showroom database"
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>1-Click Auto-Merge All ({exactPhoneGroupsCount})</span>
            </button>
          )}
        </div>
      </div>

      {/* Status Notice */}
      {statusMessage && (
        <div className={`p-4 rounded-xl border text-xs flex items-center gap-2.5 shadow-md ${
          statusMessage.type === 'success'
            ? 'bg-emerald-950/60 border-emerald-500/50 text-emerald-300'
            : 'bg-rose-950/60 border-rose-500/50 text-rose-300'
        }`}>
          {statusMessage.type === 'success' ? (
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          ) : (
            <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0" />
          )}
          <span>{statusMessage.text}</span>
        </div>
      )}

      {/* 2. Audit Pulse Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-[#050b18] border border-blue-900/30 p-4 rounded-xl flex items-center justify-between">
          <div>
            <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">Duplicate Clusters</span>
            <span className="text-2xl font-black text-white mt-1 block">{duplicateGroups.length}</span>
            <span className="text-[11px] text-blue-400">
              {duplicateGroups.length === 0 ? 'Zero conflicts' : 'Requires attention'}
            </span>
          </div>
          <div className="w-10 h-10 rounded-xl bg-blue-950 text-blue-400 border border-blue-800 flex items-center justify-center">
            <CopyCheck className="w-5 h-5" />
          </div>
        </div>

        <div className="bg-[#050b18] border border-blue-900/30 p-4 rounded-xl flex items-center justify-between">
          <div>
            <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">Conflicting Records</span>
            <span className="text-2xl font-black text-white mt-1 block">{totalDuplicateRecords}</span>
            <span className="text-[11px] text-slate-400">Total customer rows in groups</span>
          </div>
          <div className="w-10 h-10 rounded-xl bg-slate-900 text-slate-300 border border-slate-700 flex items-center justify-center">
            <Users className="w-5 h-5" />
          </div>
        </div>

        <div className="bg-[#050b18] border border-blue-900/30 p-4 rounded-xl flex items-center justify-between">
          <div>
            <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">Clean Records Health</span>
            <span className="text-2xl font-black text-emerald-400 mt-1 block">
              {customers.length > 0
                ? `${Math.max(0, Math.round(((customers.length - totalDuplicateRecords) / customers.length) * 100))}%`
                : '100%'}
            </span>
            <span className="text-[11px] text-emerald-400">Verified unique profiles</span>
          </div>
          <div className="w-10 h-10 rounded-xl bg-emerald-950 text-emerald-400 border border-emerald-800 flex items-center justify-center">
            <ShieldCheck className="w-5 h-5" />
          </div>
        </div>
      </div>

      {/* 3. Filter Bar */}
      <div className="flex items-center justify-between gap-3 bg-[#050b18] p-3 rounded-xl border border-slate-800">
        <div className="flex items-center gap-1.5 overflow-x-auto">
          <span className="text-xs text-slate-400 font-semibold px-2 flex items-center gap-1">
            <Filter className="w-3 h-3 text-blue-400" />
            <span>Filter:</span>
          </span>
          <button
            onClick={() => setFilterReason('all')}
            className={`px-3 py-1 text-xs font-bold rounded-lg transition-colors cursor-pointer ${
              filterReason === 'all'
                ? 'bg-blue-600 text-white'
                : 'bg-black text-slate-400 hover:text-white border border-slate-800'
            }`}
          >
            All Conflicts ({duplicateGroups.length})
          </button>
          <button
            onClick={() => setFilterReason('phone')}
            className={`px-3 py-1 text-xs font-bold rounded-lg transition-colors cursor-pointer ${
              filterReason === 'phone'
                ? 'bg-blue-600 text-white'
                : 'bg-black text-slate-400 hover:text-white border border-slate-800'
            }`}
          >
            Same Phone Number ({duplicateGroups.filter(g => g.reason === 'phone').length})
          </button>
          <button
            onClick={() => setFilterReason('email')}
            className={`px-3 py-1 text-xs font-bold rounded-lg transition-colors cursor-pointer ${
              filterReason === 'email'
                ? 'bg-blue-600 text-white'
                : 'bg-black text-slate-400 hover:text-white border border-slate-800'
            }`}
          >
            Same Email ({duplicateGroups.filter(g => g.reason === 'email').length})
          </button>
          <button
            onClick={() => setFilterReason('name_similar')}
            className={`px-3 py-1 text-xs font-bold rounded-lg transition-colors cursor-pointer ${
              filterReason === 'name_similar'
                ? 'bg-blue-600 text-white'
                : 'bg-black text-slate-400 hover:text-white border border-slate-800'
            }`}
          >
            Same Name ({duplicateGroups.filter(g => g.reason === 'name_similar').length})
          </button>
        </div>

        <button
          onClick={onNavigateToDirectory}
          className="text-xs text-blue-400 hover:underline font-bold whitespace-nowrap cursor-pointer px-2"
        >
          View Full Directory →
        </button>
      </div>

      {/* 4. Duplicates Groups Comparison List */}
      {visibleGroups.length > 0 ? (
        <div className="space-y-4">
          {visibleGroups.map((group) => {
            // Sort so oldest record is first (recommended primary)
            const sortedCusts = [...group.customers].sort(
              (a, b) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime()
            );
            const primary = sortedCusts[0];
            const others = sortedCusts.slice(1);

            return (
              <div
                key={group.id}
                className="bg-[#050b18] border border-blue-900/50 rounded-2xl p-5 shadow-xl space-y-4"
              >
                {/* Group Header */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-800">
                  <div className="flex items-center gap-2">
                    <span className="w-2.5 h-2.5 rounded-full bg-blue-500 animate-pulse" />
                    <span className="text-xs font-bold uppercase tracking-wider text-blue-400">
                      {group.reason === 'phone' ? 'Phone Duplicate' : group.reason === 'email' ? 'Email Duplicate' : 'Name Conflict'}
                    </span>
                    <span className="text-xs font-mono px-2 py-0.5 rounded bg-black border border-slate-800 text-white">
                      {group.key}
                    </span>
                    <span className="text-xs text-slate-400">
                      ({group.customers.length} customer records)
                    </span>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => handleDismissGroup(group.id)}
                      className="px-2.5 py-1 text-xs text-slate-400 hover:text-white bg-black hover:bg-slate-900 rounded-lg border border-slate-800 transition-colors cursor-pointer"
                      title="Keep both records if they are family members sharing a number"
                    >
                      Keep Both Separate
                    </button>
                    <button
                      onClick={() => promptMergeGroup(primary, others)}
                      disabled={isMerging}
                      className="px-3.5 py-1.5 bg-blue-600 hover:bg-blue-500 text-white rounded-lg text-xs font-bold transition-all shadow-md flex items-center gap-1.5 cursor-pointer active:scale-95"
                    >
                      <Merge className="w-3.5 h-3.5" />
                      <span>Merge Into Primary</span>
                    </button>
                  </div>
                </div>

                {/* Side-by-Side Customer Comparison */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
                  {sortedCusts.map((cust, idx) => {
                    const isPrimary = idx === 0;
                    return (
                      <div
                        key={cust.id}
                        className={`p-4 rounded-xl border transition-all ${
                          isPrimary
                            ? 'bg-blue-950/20 border-blue-600/60 shadow-sm'
                            : 'bg-black/60 border-slate-800'
                        }`}
                      >
                        <div className="flex items-center justify-between mb-2">
                          <div className="flex items-center gap-2">
                            <span className="text-sm font-bold text-white">{cust.name}</span>
                            {isPrimary && (
                              <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-blue-900 text-blue-200 border border-blue-700">
                                Oldest Record (Primary)
                              </span>
                            )}
                          </div>
                          {onEditCustomer && (
                            <button
                              onClick={() => onEditCustomer(cust)}
                              className="text-[11px] text-blue-400 hover:underline cursor-pointer"
                            >
                              Edit Profile
                            </button>
                          )}
                        </div>

                        <div className="space-y-1.5 text-xs text-slate-300">
                          <div className="flex items-center gap-2 font-mono">
                            <Phone className="w-3 h-3 text-blue-400" />
                            <span>{cust.phone}</span>
                          </div>

                          {cust.email && (
                            <div className="flex items-center gap-2">
                              <Mail className="w-3 h-3 text-slate-400" />
                              <span>{cust.email}</span>
                            </div>
                          )}

                          <div className="flex flex-wrap items-center gap-2 pt-1 text-[11px] text-slate-400">
                            {cust.categoryName && (
                              <span className="px-2 py-0.5 rounded bg-slate-900 border border-slate-700 text-slate-300">
                                {cust.categoryName}
                              </span>
                            )}
                            {cust.city && (
                              <span className="flex items-center gap-1">
                                <MapPin className="w-3 h-3 text-slate-500" />
                                <span>{cust.city}</span>
                              </span>
                            )}
                            <span className="flex items-center gap-1 font-mono">
                              <Calendar className="w-3 h-3 text-slate-500" />
                              <span>{cust.createdAt ? new Date(cust.createdAt).toLocaleDateString() : 'N/A'}</span>
                            </span>
                            <span className="text-slate-500">
                              via {cust.source === 'walkin_qr' ? 'Showroom QR' : cust.source === 'import' ? 'Import' : 'Counter Staff'}
                            </span>
                          </div>

                          {cust.notes && (
                            <div className="mt-2 p-2 bg-slate-900/80 rounded border border-slate-800 text-[11px] text-slate-400 italic line-clamp-2">
                              "{cust.notes}"
                            </div>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        /* Empty State: Zero Duplicates */
        <div className="bg-[#050b18] border border-blue-900/30 rounded-2xl p-12 text-center space-y-4 shadow-xl">
          <div className="w-16 h-16 rounded-2xl bg-emerald-950/80 border border-emerald-500/40 text-emerald-400 flex items-center justify-center mx-auto shadow-inner">
            <ShieldCheck className="w-8 h-8" />
          </div>
          <div className="space-y-1">
            <h3 className="text-lg font-black text-white">Database 100% Deduplicated</h3>
            <p className="text-xs text-slate-400 max-w-md mx-auto">
              No duplicate customer phone numbers or email conflicts detected in Giri Jewels records.
              Deduplication safeguards are actively enforcing uniqueness across manual walk-in entry, QR scans, and bulk imports.
            </p>
          </div>
          <button
            onClick={onNavigateToDirectory}
            className="px-4 py-2 bg-white text-slate-950 text-xs font-bold rounded-xl shadow-lg hover:bg-slate-100 transition-colors cursor-pointer"
          >
            Open Customer Directory
          </button>
        </div>
      )}
      {/* Showroom Confirmation Dialog */}
      <ConfirmationModal
        isOpen={confirmModal.isOpen}
        onClose={() => setConfirmModal(prev => ({ ...prev, isOpen: false }))}
        onConfirm={confirmModal.onConfirm}
        title={confirmModal.title}
        description={confirmModal.description}
        confirmText={confirmModal.confirmText}
        variant={confirmModal.variant}
        itemDetails={confirmModal.itemDetails}
      />
    </div>
  );
};
