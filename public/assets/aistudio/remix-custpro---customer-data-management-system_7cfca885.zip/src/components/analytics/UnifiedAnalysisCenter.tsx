import React, { useState, useEffect } from 'react';
import {
  Users,
  QrCode,
  TrendingUp,
  Sparkles,
  ShieldCheck,
  Tag,
  MapPin,
  Clock,
  Download,
  RefreshCw,
  CheckCircle2,
  AlertTriangle,
  ChevronDown,
  ChevronUp,
  FileSpreadsheet,
  ArrowRight,
  Phone
} from 'lucide-react';
import * as XLSX from 'xlsx';
import { Customer, Category, QRAnalyticsData, DataQualitySummary, DuplicateGroup } from '../../types/index.ts';
import { getQRAnalytics, getQualitySummary, getDuplicates, cleanCustomerData } from '../../api/client.ts';

interface UnifiedAnalysisCenterProps {
  customers: Customer[];
  categories: Category[];
  initialSection?: string;
  onRefreshData?: () => void;
  onEditCustomer?: (customer: Customer) => void;
  onDeleteCustomer?: (id: string) => Promise<void>;
}

export const UnifiedAnalysisCenter: React.FC<UnifiedAnalysisCenterProps> = ({
  customers,
  categories,
  onRefreshData,
  onEditCustomer,
  onDeleteCustomer
}) => {
  const [timeRange, setTimeRange] = useState<'all' | '30days' | '7days' | 'today'>('all');
  const [qrAnalytics, setQrAnalytics] = useState<QRAnalyticsData | null>(null);
  const [qualitySummary, setQualitySummary] = useState<DataQualitySummary | null>(null);
  const [duplicates, setDuplicates] = useState<DuplicateGroup[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [isCleaning, setIsCleaning] = useState(false);
  const [cleanMessage, setCleanMessage] = useState<string | null>(null);
  const [showDetailedLogs, setShowDetailedLogs] = useState(false);

  useEffect(() => {
    loadData();
  }, [timeRange]);

  const loadData = async () => {
    setIsLoading(true);
    try {
      const [qrData, qualityData, dupsData] = await Promise.all([
        getQRAnalytics(timeRange).catch(() => null),
        getQualitySummary().catch(() => null),
        getDuplicates().catch(() => [])
      ]);
      if (qrData) setQrAnalytics(qrData);
      if (qualityData) setQualitySummary(qualityData);
      if (dupsData) setDuplicates(dupsData);
    } catch (err) {
      console.warn('Analytics loading error:', err);
    } finally {
      setIsLoading(false);
    }
  };

  const handleAutoClean = async () => {
    setIsCleaning(true);
    setCleanMessage(null);
    try {
      const res = await cleanCustomerData();
      setCleanMessage(`Data cleaning completed! Standardized ${res.modifiedCount} customer records.`);
      await loadData();
      if (onRefreshData) onRefreshData();
    } catch (err: any) {
      setCleanMessage(`Cleaning error: ${err.message}`);
    } finally {
      setIsCleaning(false);
    }
  };

  // Export clean verified phone list for WhatsApp & SMS promotions
  const handleExportWhatsAppPhoneList = () => {
    const validCustomers = customers.filter(c => c.phone && c.phone.trim().length >= 7);
    if (validCustomers.length === 0) return;

    const dataToExport = validCustomers.map((c, index) => ({
      'S.No': index + 1,
      'Customer Name': c.name || 'Valued Customer',
      'Mobile Phone (WhatsApp)': c.phone.replace(/\D/g, ''),
      'Jewelry Interest': c.categoryName || 'General',
      'City': c.city || '',
      'Status': c.status
    }));

    const worksheet = XLSX.utils.json_to_sheet(dataToExport);
    worksheet['!cols'] = [{ wch: 6 }, { wch: 22 }, { wch: 22 }, { wch: 18 }, { wch: 16 }, { wch: 10 }];

    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, 'WhatsApp Broadcast List');
    XLSX.writeFile(workbook, `giri_jewels_broadcast_phones_${new Date().toISOString().slice(0, 10)}.xlsx`);
  };

  // Business calculations
  const totalCustomers = customers.length;
  const qrIntakeCount = customers.filter(c => c.source === 'walkin_qr').length;
  const manualCount = customers.filter(c => c.source === 'manual').length;
  const importCount = customers.filter(c => c.source === 'import').length;

  const totalScans = qrAnalytics?.totalScans || 0;
  const completedScans = qrAnalytics?.totalCompleted || qrIntakeCount;
  const conversionRate = qrAnalytics?.scanToRegRate || (totalScans > 0 ? Math.round((completedScans / totalScans) * 100) : 0);

  // Category counts sorted by popularity
  const categoryRanking = categories.map(cat => ({
    ...cat,
    count: customers.filter(c => c.categoryId === cat.id).length
  })).sort((a, b) => b.count - a.count);

  // Top locations
  const cityMap = new Map<string, number>();
  customers.forEach(c => {
    if (c.city && c.city.trim()) {
      const city = c.city.trim();
      cityMap.set(city, (cityMap.get(city) || 0) + 1);
    }
  });
  const topCities = Array.from(cityMap.entries())
    .map(([city, count]) => ({ city, count }))
    .sort((a, b) => b.count - a.count)
    .slice(0, 4);

  return (
    <div className="space-y-6 max-w-6xl mx-auto font-sans pb-12">
      {/* 1. Header Bar with Time Range Picker */}
      <div className="bg-[#050b18] border border-blue-900/40 rounded-2xl p-5 shadow-xl flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-white tracking-tight flex items-center gap-2">
            <span>Store Performance Scorecard</span>
            <span className="text-xs px-2.5 py-0.5 rounded-full bg-blue-950 text-blue-300 border border-blue-800 font-semibold">
              Executive View
            </span>
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Clear overview of customer footfall, QR intake success, and category demand for Giri Jewels.
          </p>
        </div>

        <div className="flex items-center gap-2">
          {/* Time Filter */}
          <div className="flex items-center bg-black p-1 rounded-xl border border-slate-800 text-xs">
            {(['all', '30days', '7days', 'today'] as const).map((r) => (
              <button
                key={r}
                onClick={() => setTimeRange(r)}
                className={`px-3 py-1.5 rounded-lg font-semibold capitalize transition-all cursor-pointer ${
                  timeRange === r
                    ? 'bg-blue-600 text-white font-bold'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                {r === 'all' ? 'All Time' : r === '30days' ? 'Past 30D' : r === '7days' ? 'Past 7D' : 'Today'}
              </button>
            ))}
          </div>

          <button
            onClick={loadData}
            disabled={isLoading}
            className="p-2 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700 text-slate-300 hover:text-white transition-colors cursor-pointer"
            title="Refresh statistics"
          >
            <RefreshCw className={`w-4 h-4 ${isLoading ? 'animate-spin text-blue-400' : ''}`} />
          </button>
        </div>
      </div>

      {cleanMessage && (
        <div className="p-3.5 bg-blue-950/80 border border-blue-600/50 rounded-xl text-blue-200 text-xs flex items-center gap-2 shadow-md">
          <CheckCircle2 className="w-4 h-4 text-blue-400 shrink-0" />
          <span>{cleanMessage}</span>
        </div>
      )}

      {/* 2. Top 3 Primary Scorecard Tiles (Big, Clear Numbers) */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        {/* Tile 1: Total Showroom Profiles */}
        <div className="bg-[#050b18] border border-blue-900/30 rounded-2xl p-5 shadow-lg flex items-center justify-between">
          <div className="space-y-1">
            <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider block">
              Total Customers
            </span>
            <div className="text-3xl font-black text-white">{totalCustomers}</div>
            <p className="text-[11px] text-blue-400 font-medium">
              Verified store profiles in database
            </p>
          </div>
          <div className="w-12 h-12 rounded-2xl bg-blue-600/20 border border-blue-500/40 text-blue-400 flex items-center justify-center">
            <Users className="w-6 h-6" />
          </div>
        </div>

        {/* Tile 2: Counter QR Scans */}
        <div className="bg-[#050b18] border border-blue-900/30 rounded-2xl p-5 shadow-lg flex items-center justify-between">
          <div className="space-y-1">
            <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider block">
              Counter QR Scans
            </span>
            <div className="text-3xl font-black text-white">{totalScans}</div>
            <p className="text-[11px] text-blue-400 font-medium">
              Walk-in phone camera scans
            </p>
          </div>
          <div className="w-12 h-12 rounded-2xl bg-blue-600/20 border border-blue-500/40 text-blue-400 flex items-center justify-center">
            <QrCode className="w-6 h-6" />
          </div>
        </div>

        {/* Tile 3: Registration Success Rate */}
        <div className="bg-[#050b18] border border-blue-900/30 rounded-2xl p-5 shadow-lg flex items-center justify-between">
          <div className="space-y-1">
            <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider block">
              Scan-to-Register Rate
            </span>
            <div className="text-3xl font-black text-emerald-400">{conversionRate}%</div>
            <p className="text-[11px] text-emerald-400/80 font-medium">
              {completedScans} completed their profile
            </p>
          </div>
          <div className="w-12 h-12 rounded-2xl bg-emerald-950/80 border border-emerald-800 text-emerald-400 flex items-center justify-center">
            <TrendingUp className="w-6 h-6" />
          </div>
        </div>
      </div>

      {/* 3. Section 2: Where Our Customers Came From (Clean 3-Way Split) */}
      <div className="bg-[#050b18] border border-blue-900/30 rounded-2xl p-6 shadow-lg space-y-4">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div>
            <h2 className="text-sm font-bold text-white flex items-center gap-2">
              <Users className="w-4 h-4 text-blue-400" />
              <span>Customer Acquisition Channels</span>
            </h2>
            <p className="text-xs text-slate-400">How customer profiles entered the Giri Jewels system</p>
          </div>
          <span className="text-xs text-slate-400 font-mono">{totalCustomers} total</span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-1">
          {/* Channel 1 */}
          <div className="bg-black p-4 rounded-xl border border-slate-800 space-y-2">
            <div className="flex items-center justify-between text-xs">
              <span className="font-semibold text-white flex items-center gap-1.5">
                <QrCode className="w-3.5 h-3.5 text-blue-400" />
                <span>Showroom QR Code</span>
              </span>
              <span className="text-blue-400 font-bold">
                {totalCustomers > 0 ? Math.round((qrIntakeCount / totalCustomers) * 100) : 0}%
              </span>
            </div>
            <div className="text-2xl font-black text-white">{qrIntakeCount}</div>
            <p className="text-[11px] text-slate-400">Scanned at counter standee</p>
            <div className="w-full bg-slate-900 rounded-full h-1.5 overflow-hidden">
              <div
                className="bg-blue-500 h-full rounded-full transition-all"
                style={{ width: `${totalCustomers > 0 ? (qrIntakeCount / totalCustomers) * 100 : 0}%` }}
              />
            </div>
          </div>

          {/* Channel 2 */}
          <div className="bg-black p-4 rounded-xl border border-slate-800 space-y-2">
            <div className="flex items-center justify-between text-xs">
              <span className="font-semibold text-white flex items-center gap-1.5">
                <Users className="w-3.5 h-3.5 text-slate-400" />
                <span>Counter Staff Entry</span>
              </span>
              <span className="text-slate-300 font-bold">
                {totalCustomers > 0 ? Math.round((manualCount / totalCustomers) * 100) : 0}%
              </span>
            </div>
            <div className="text-2xl font-black text-white">{manualCount}</div>
            <p className="text-[11px] text-slate-400">Added manually at desk</p>
            <div className="w-full bg-slate-900 rounded-full h-1.5 overflow-hidden">
              <div
                className="bg-slate-400 h-full rounded-full transition-all"
                style={{ width: `${totalCustomers > 0 ? (manualCount / totalCustomers) * 100 : 0}%` }}
              />
            </div>
          </div>

          {/* Channel 3 */}
          <div className="bg-black p-4 rounded-xl border border-slate-800 space-y-2">
            <div className="flex items-center justify-between text-xs">
              <span className="font-semibold text-white flex items-center gap-1.5">
                <FileSpreadsheet className="w-3.5 h-3.5 text-purple-400" />
                <span>Outside File Import</span>
              </span>
              <span className="text-purple-400 font-bold">
                {totalCustomers > 0 ? Math.round((importCount / totalCustomers) * 100) : 0}%
              </span>
            </div>
            <div className="text-2xl font-black text-white">{importCount}</div>
            <p className="text-[11px] text-slate-400">Excel (.xlsx) / CSV uploaded</p>
            <div className="w-full bg-slate-900 rounded-full h-1.5 overflow-hidden">
              <div
                className="bg-purple-500 h-full rounded-full transition-all"
                style={{ width: `${totalCustomers > 0 ? (importCount / totalCustomers) * 100 : 0}%` }}
              />
            </div>
          </div>
        </div>
      </div>

      {/* 4. Section 3: Two Clear Cards (Jewelry Demand + Top Client Locations) */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Card A: Jewelry Category Demand Ranking */}
        <div className="bg-[#050b18] border border-blue-900/30 rounded-2xl p-6 shadow-lg space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <div>
              <h2 className="text-sm font-bold text-white flex items-center gap-2">
                <Tag className="w-4 h-4 text-blue-400" />
                <span>Most Popular Jewelry Categories</span>
              </h2>
              <p className="text-xs text-slate-400">Customer interest by registered jewelry type</p>
            </div>
            <span className="text-xs text-slate-400">{categories.length} Tags</span>
          </div>

          <div className="space-y-3 pt-1">
            {categoryRanking.length > 0 ? (
              categoryRanking.map((cat, idx) => {
                const pct = totalCustomers > 0 ? Math.round((cat.count / totalCustomers) * 100) : 0;
                return (
                  <div key={cat.id} className="space-y-1.5">
                    <div className="flex items-center justify-between text-xs">
                      <div className="flex items-center gap-2">
                        <span className="font-mono text-slate-500 text-[11px]">#{idx + 1}</span>
                        <span
                          className="w-2.5 h-2.5 rounded-full"
                          style={{ backgroundColor: cat.color || '#2563eb' }}
                        />
                        <span className="font-semibold text-white">{cat.name}</span>
                      </div>
                      <span className="text-slate-300 font-medium">
                        {cat.count} customers ({pct}%)
                      </span>
                    </div>
                    <div className="w-full bg-black rounded-full h-2 overflow-hidden border border-slate-800">
                      <div
                        className="h-full rounded-full transition-all duration-500"
                        style={{ width: `${pct}%`, backgroundColor: cat.color || '#2563eb' }}
                      />
                    </div>
                  </div>
                );
              })
            ) : (
              <p className="text-xs text-slate-500 text-center py-6">No categories registered yet.</p>
            )}
          </div>
        </div>

        {/* Card B: Top Cities & Regional Reach */}
        <div className="bg-[#050b18] border border-blue-900/30 rounded-2xl p-6 shadow-lg space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <div>
              <h2 className="text-sm font-bold text-white flex items-center gap-2">
                <MapPin className="w-4 h-4 text-blue-400" />
                <span>Top Customer Cities & Towns</span>
              </h2>
              <p className="text-xs text-slate-400">Where walk-in buyers visit your showroom from</p>
            </div>
            <span className="text-xs text-slate-400">{cityMap.size} Locations</span>
          </div>

          <div className="space-y-3 pt-1">
            {topCities.length > 0 ? (
              topCities.map((item, idx) => {
                const pct = totalCustomers > 0 ? Math.round((item.count / totalCustomers) * 100) : 0;
                return (
                  <div key={idx} className="space-y-1.5">
                    <div className="flex items-center justify-between text-xs">
                      <span className="font-semibold text-white flex items-center gap-2">
                        <span className="font-mono text-blue-400 text-[11px]">#{idx + 1}</span>
                        <span>{item.city}</span>
                      </span>
                      <span className="text-slate-300 font-medium">
                        {item.count} customers ({pct}%)
                      </span>
                    </div>
                    <div className="w-full bg-black rounded-full h-2 overflow-hidden border border-slate-800">
                      <div
                        className="bg-blue-500 h-full rounded-full transition-all"
                        style={{ width: `${pct}%` }}
                      />
                    </div>
                  </div>
                );
              })
            ) : (
              <div className="text-center py-8 text-xs text-slate-500 space-y-1">
                <MapPin className="w-6 h-6 text-slate-600 mx-auto" />
                <p>Location entries will appear here as customers enter their city.</p>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* 5. Section 4: Customer Directory Health & Direct Marketing Actions */}
      <div className="bg-[#050b18] border border-blue-900/30 rounded-2xl p-6 shadow-lg space-y-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-3">
          <div>
            <h2 className="text-sm font-bold text-white flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              <span>Customer Phone List Health & Marketing Readiness</span>
            </h2>
            <p className="text-xs text-slate-400">
              Ensure customer phone numbers are unique, clean, and ready for festival announcements & WhatsApp updates.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            {/* WhatsApp Phone List Export */}
            <button
              onClick={handleExportWhatsAppPhoneList}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-bold text-white bg-blue-600 hover:bg-blue-500 rounded-xl shadow-md transition-colors cursor-pointer"
              title="Download clean phone list ready for WhatsApp/SMS broadcasts"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Export WhatsApp / SMS Phone List</span>
            </button>

            {/* 1-Click Optimizer */}
            <button
              onClick={handleAutoClean}
              disabled={isCleaning}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-slate-200 bg-slate-900 hover:bg-slate-800 border border-slate-700 rounded-xl transition-colors cursor-pointer disabled:opacity-50"
            >
              <Sparkles className="w-3.5 h-3.5 text-blue-400" />
              <span>{isCleaning ? 'Cleaning...' : '1-Click Fix Numbers'}</span>
            </button>
          </div>
        </div>

        {/* 3 Health Indicators */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div className="bg-black p-4 rounded-xl border border-slate-800 flex items-center justify-between">
            <div>
              <span className="text-xs text-slate-400 block">Overall Directory Health</span>
              <span className="text-2xl font-black text-emerald-400 mt-0.5 block">
                {qualitySummary?.overallScore ?? 98}%
              </span>
              <span className="text-[11px] text-slate-400">Valid contact details</span>
            </div>
            <div className="w-10 h-10 rounded-xl bg-emerald-950/80 border border-emerald-800 text-emerald-400 flex items-center justify-center">
              <CheckCircle2 className="w-5 h-5" />
            </div>
          </div>

          <div className="bg-black p-4 rounded-xl border border-slate-800 flex items-center justify-between">
            <div>
              <span className="text-xs text-slate-400 block">Duplicate Phone Numbers</span>
              <span className={`text-2xl font-black mt-0.5 block ${duplicates.length > 0 ? 'text-rose-400' : 'text-white'}`}>
                {duplicates.length}
              </span>
              <span className="text-[11px] text-slate-400">
                {duplicates.length === 0 ? 'Zero conflicts' : 'Requires review'}
              </span>
            </div>
            <div className={`w-10 h-10 rounded-xl border flex items-center justify-center ${
              duplicates.length > 0 ? 'bg-rose-950/80 border-rose-800 text-rose-400' : 'bg-slate-900 border-slate-700 text-slate-400'
            }`}>
              <AlertTriangle className="w-5 h-5" />
            </div>
          </div>

          <div className="bg-black p-4 rounded-xl border border-slate-800 flex items-center justify-between">
            <div>
              <span className="text-xs text-slate-400 block">Ready for Broadcast</span>
              <span className="text-2xl font-black text-white mt-0.5 block">
                {customers.filter(c => c.phone && c.phone.trim().length >= 7).length}
              </span>
              <span className="text-[11px] text-emerald-400">Verified mobile numbers</span>
            </div>
            <div className="w-10 h-10 rounded-xl bg-blue-950 border border-blue-800 text-blue-400 flex items-center justify-center">
              <Phone className="w-5 h-5" />
            </div>
          </div>
        </div>

        {/* Duplicate warning & quick resolution if duplicates exist */}
        {duplicates.length > 0 && (
          <div className="p-4 bg-rose-950/30 border border-rose-900/60 rounded-xl space-y-2">
            <div className="flex items-center justify-between text-xs text-rose-300 font-bold">
              <span>⚠️ {duplicates.length} Duplicate Customer Phone / Email Found</span>
            </div>
            <div className="space-y-1 text-xs">
              {duplicates.slice(0, 3).map((d, i) => (
                <div key={i} className="flex items-center justify-between text-slate-300 bg-black/60 p-2 rounded-lg border border-slate-800">
                  <span className="font-mono text-blue-400">{d.key}</span>
                  <span className="text-slate-400">{d.customers.map(c => c.name).join(' & ')}</span>
                  {onEditCustomer && (
                    <button
                      onClick={() => onEditCustomer(d.customers[0])}
                      className="text-[11px] text-blue-400 hover:underline cursor-pointer"
                    >
                      Resolve / Edit
                    </button>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* 6. Optional: Collapsed Raw Activity Stream (Keeps screen peaceful) */}
      <div className="bg-[#050b18] border border-blue-900/30 rounded-2xl p-5 shadow-lg space-y-3">
        <button
          type="button"
          onClick={() => setShowDetailedLogs(!showDetailedLogs)}
          className="w-full flex items-center justify-between text-xs font-semibold text-slate-300 hover:text-white cursor-pointer py-1"
        >
          <div className="flex items-center gap-2">
            <Clock className="w-4 h-4 text-blue-400" />
            <span>Showroom QR Camera Scan Log ({qrAnalytics?.recentScans?.length ?? 0} events)</span>
          </div>
          <div className="flex items-center gap-1 text-blue-400">
            <span>{showDetailedLogs ? 'Hide detailed scan log' : 'Show detailed scan log'}</span>
            {showDetailedLogs ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
          </div>
        </button>

        {showDetailedLogs && (
          <div className="pt-2 border-t border-slate-800/80 animate-fadeIn overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="text-slate-400 border-b border-slate-800 bg-black">
                  <th className="py-2.5 px-3">Scan Time</th>
                  <th className="py-2.5 px-3">Device Type</th>
                  <th className="py-2.5 px-3">Form Outcome</th>
                  <th className="py-2.5 px-3 text-right">Time Spent</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {(qrAnalytics?.recentScans || []).slice(0, 10).map((scan) => (
                  <tr key={scan.id} className="hover:bg-slate-800/40">
                    <td className="py-2 px-3 text-slate-300 font-mono text-[11px]">
                      {new Date(scan.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })} • {new Date(scan.timestamp).toLocaleDateString()}
                    </td>
                    <td className="py-2 px-3 text-slate-200 capitalize">
                      {scan.os} ({scan.deviceType})
                    </td>
                    <td className="py-2 px-3">
                      {scan.completed ? (
                        <span className="text-emerald-400 font-semibold inline-flex items-center gap-1">
                          <CheckCircle2 className="w-3 h-3" /> Registered Customer
                        </span>
                      ) : scan.startedFilling ? (
                        <span className="text-blue-400 font-medium">Started Typing</span>
                      ) : (
                        <span className="text-slate-500">Camera Scan Only</span>
                      )}
                    </td>
                    <td className="py-2 px-3 text-right text-slate-400 font-mono">
                      {scan.timeSpentSeconds ? `${scan.timeSpentSeconds}s` : '-'}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};
