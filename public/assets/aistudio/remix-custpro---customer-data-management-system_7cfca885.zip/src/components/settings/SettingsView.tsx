import React, { useState, useEffect } from 'react';
import {
  Building,
  Save,
  Download,
  Database,
  ShieldCheck,
  Gem,
  MapPin,
  Phone,
  Mail,
  CheckCircle2,
  Trash2,
  QrCode,
  Sparkles,
  Lock,
  Tag,
  DollarSign,
  Coins,
  FileText,
  Clock,
  AlertTriangle,
  RotateCcw,
  Sliders
} from 'lucide-react';
import { Customer, Category, StoreSettings } from '../../types/index.ts';
import { ConfirmationModal } from '../common/ConfirmationModal.tsx';

interface SettingsViewProps {
  businessName: string;
  onUpdateBusinessName: (name: string) => void;
  customers: Customer[];
  categories: Category[];
  storeSettings?: StoreSettings;
  onUpdateSettings?: (settings: Partial<StoreSettings>) => Promise<void>;
  onClearAllCustomers?: () => Promise<void>;
  onClearAllQRData?: () => Promise<void>;
}

const DEFAULT_SETTINGS_FALLBACK: StoreSettings = {
  businessName: 'Giri Jewels',
  tagline: 'Fine Gold, Diamond & Heritage Bridal Jewellery',
  branchName: 'Trivandrum Flagship Showroom',
  address: 'MG Road, Overbridge Junction, East Fort',
  city: 'Thiruvananthapuram',
  state: 'Kerala',
  pincode: '695001',
  phone: '+91 98470 54321',
  whatsappPhone: '+91 98470 54321',
  email: 'girijewelstvm@gmail.com',
  gstin: '32AABCG1234F1Z9',
  bisHallmarkNumber: 'HM/C-7849201',

  currency: '₹',
  rate22kGold: 6850,
  rate24kGold: 7470,
  rateSilver: 98,
  showDailyRatesOnDashboard: true,

  enableDuplicateGuard: true,
  minPhoneDigits: 10,
  defaultCategoryId: 'cat-1',
  autoFormatNames: true,
  requireCityOnWalkin: true,

  standeeTagline: 'Scan to join VIP rewards & fast showroom customer intake',
  qrIntakeActive: true,
  qrWelcomeHeading: 'Welcome to Giri Jewels',
  qrSubtitle: 'Register your counter visit for bespoke assistance, hallmark warranty & exclusive festive previews',
  qrSuccessMessage: 'Thank you for visiting Giri Jewels! Your showroom visit details have been registered. Our jewellery specialist will assist you shortly.',
  collectAnniversaryDate: true,

  masterSecurityPin: 'GIRI-7788',
  allowStaffExports: true,
  sessionTimeoutMinutes: 60
};

export const SettingsView: React.FC<SettingsViewProps> = ({
  businessName,
  onUpdateBusinessName,
  customers,
  categories,
  storeSettings,
  onUpdateSettings,
  onClearAllCustomers,
  onClearAllQRData
}) => {
  const [activeTab, setActiveTab] = useState<'identity' | 'rates' | 'intake' | 'qr' | 'security'>('identity');
  const [settings, setSettings] = useState<StoreSettings>({
    ...DEFAULT_SETTINGS_FALLBACK,
    ...(storeSettings || {}),
    businessName: businessName || storeSettings?.businessName || 'Giri Jewels'
  });

  const [isSaving, setIsSaving] = useState(false);
  const [savedSuccess, setSavedSuccess] = useState(false);
  const [statusMessage, setStatusMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  // Confirmation Modals State
  const [confirmModal, setConfirmModal] = useState<{
    isOpen: boolean;
    title: string;
    description: string;
    confirmText?: string;
    variant?: 'danger' | 'warning' | 'primary';
    itemDetails?: Array<{ label: string; value: string }>;
    onConfirm: () => Promise<void> | void;
  }>({
    isOpen: false,
    title: '',
    description: '',
    onConfirm: () => {}
  });

  useEffect(() => {
    if (storeSettings) {
      setSettings(prev => ({
        ...prev,
        ...storeSettings,
        businessName: businessName || storeSettings.businessName || prev.businessName
      }));
    }
  }, [storeSettings, businessName]);

  const handleFieldChange = (field: keyof StoreSettings, value: any) => {
    setSettings(prev => ({ ...prev, [field]: value }));
  };

  const handleSaveAll = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    setIsSaving(true);
    setStatusMessage(null);

    try {
      if (settings.businessName.trim() !== businessName) {
        onUpdateBusinessName(settings.businessName.trim());
      }
      if (onUpdateSettings) {
        await onUpdateSettings(settings);
      }
      setSavedSuccess(true);
      setStatusMessage({
        type: 'success',
        text: 'All showroom settings, counter rates, and intake configurations saved successfully!'
      });
      setTimeout(() => setSavedSuccess(false), 3500);
    } catch (err: any) {
      setStatusMessage({
        type: 'error',
        text: err.message || 'Failed to save store settings. Please try again.'
      });
    } finally {
      setIsSaving(false);
    }
  };

  // Full Database JSON Backup
  const handleExportFullBackup = () => {
    const backupData = {
      backupVersion: '2.0-full',
      showroom: settings.businessName,
      branch: settings.branchName,
      address: settings.address,
      city: settings.city,
      gstin: settings.gstin,
      bisHallmark: settings.bisHallmarkNumber,
      exportedAt: new Date().toISOString(),
      customerCount: customers.length,
      categoryCount: categories.length,
      storeSettings: settings,
      customers,
      categories
    };

    const blob = new Blob([JSON.stringify(backupData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `${settings.businessName.toLowerCase().replace(/\s+/g, '_')}_backup_${new Date().toISOString().slice(0, 10)}.json`;
    link.click();
    URL.revokeObjectURL(url);

    setStatusMessage({
      type: 'success',
      text: `Full database backup (${customers.length} customers, ${categories.length} categories, store settings) downloaded successfully.`
    });
  };

  // Prompt Clear All QR Scan Activity Logs
  const promptClearQRData = () => {
    setConfirmModal({
      isOpen: true,
      title: 'Reset & Clear All Showroom QR Scan Data?',
      description: 'This will completely wipe all historical QR scan activity, visitor device statistics, conversion metrics, and drop-off records. Your registered customer profiles and category tags will NOT be deleted.',
      confirmText: 'Wipe All QR Logs',
      variant: 'warning',
      itemDetails: [
        { label: 'Target Target', value: 'Showroom QR Standee Scan Activity Logs' },
        { label: 'Customer Profiles', value: 'Safe & Untouched' },
        { label: 'Action Result', value: 'QR Analytics reset to 0 scans' }
      ],
      onConfirm: async () => {
        if (onClearAllQRData) {
          await onClearAllQRData();
          setStatusMessage({
            type: 'success',
            text: 'All showroom QR scan logs and analytics have been reset to zero.'
          });
        }
      }
    });
  };

  // Prompt Clear All Customers
  const promptClearCustomers = () => {
    setConfirmModal({
      isOpen: true,
      title: 'Clear Entire Customer Database?',
      description: `WARNING: This will permanently delete all ${customers.length} registered customer records from your Giri Jewels database. Please make sure you have downloaded a JSON backup first.`,
      confirmText: `Permanently Delete ${customers.length} Customers`,
      variant: 'danger',
      itemDetails: [
        { label: 'Customer Rows', value: `${customers.length} records to be erased` },
        { label: 'Irreversible Action', value: 'Requires Manager Authorization' }
      ],
      onConfirm: async () => {
        if (onClearAllCustomers) {
          await onClearAllCustomers();
          setStatusMessage({
            type: 'success',
            text: 'All customer records have been cleared from the database.'
          });
        }
      }
    });
  };

  return (
    <div className="space-y-6">
      {/* 1. Header Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl sm:text-2xl font-black text-white tracking-tight">
              Store & Showroom Settings
            </h1>
            <span className="text-[10px] px-2.5 py-0.5 rounded-full bg-blue-950 text-blue-300 border border-blue-800 font-bold uppercase tracking-wider">
              System Admin
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1 max-w-2xl">
            Reliable configuration for Giri Jewels: Showroom identity, BIS hallmark compliance, daily gold counter rates, deduplication safeguards, and QR standee customization.
          </p>
        </div>

        <div className="flex items-center gap-2.5">
          <button
            type="button"
            onClick={handleExportFullBackup}
            className="px-3.5 py-2 text-xs font-semibold text-slate-300 hover:text-white bg-black hover:bg-slate-900 border border-slate-700 rounded-xl transition-all flex items-center gap-1.5 cursor-pointer"
            title="Download offline JSON backup file"
          >
            <Download className="w-3.5 h-3.5 text-blue-400" />
            <span>Download Backup</span>
          </button>

          <button
            type="button"
            onClick={() => handleSaveAll()}
            disabled={isSaving}
            className="px-4 py-2 bg-blue-600 hover:bg-blue-500 disabled:opacity-50 text-white text-xs font-black rounded-xl shadow-lg shadow-blue-900/40 transition-all flex items-center gap-2 cursor-pointer active:scale-98"
          >
            <Save className="w-3.5 h-3.5" />
            <span>{isSaving ? 'Saving...' : 'Save Settings'}</span>
          </button>
        </div>
      </div>

      {/* Status Alert Notice */}
      {statusMessage && (
        <div
          className={`p-3.5 rounded-xl border text-xs flex items-center gap-2.5 shadow-md ${
            statusMessage.type === 'success'
              ? 'bg-emerald-950/70 border-emerald-500/50 text-emerald-300'
              : 'bg-rose-950/70 border-rose-500/50 text-rose-300'
          }`}
        >
          {statusMessage.type === 'success' ? (
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          ) : (
            <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0" />
          )}
          <span>{statusMessage.text}</span>
        </div>
      )}

      {/* 2. Settings Category Navigation Tabs */}
      <div className="flex flex-wrap items-center gap-2 bg-[#050b18] p-2 rounded-2xl border border-slate-800">
        <button
          onClick={() => setActiveTab('identity')}
          className={`px-3.5 py-2 text-xs font-bold rounded-xl transition-all flex items-center gap-2 cursor-pointer ${
            activeTab === 'identity'
              ? 'bg-blue-600 text-white shadow-md'
              : 'text-slate-400 hover:text-white hover:bg-slate-900'
          }`}
        >
          <Building className="w-3.5 h-3.5" />
          <span>Showroom & Identity</span>
        </button>

        <button
          onClick={() => setActiveTab('rates')}
          className={`px-3.5 py-2 text-xs font-bold rounded-xl transition-all flex items-center gap-2 cursor-pointer ${
            activeTab === 'rates'
              ? 'bg-blue-600 text-white shadow-md'
              : 'text-slate-400 hover:text-white hover:bg-slate-900'
          }`}
        >
          <Coins className="w-3.5 h-3.5" />
          <span>Daily Rates & Pricing</span>
        </button>

        <button
          onClick={() => setActiveTab('intake')}
          className={`px-3.5 py-2 text-xs font-bold rounded-xl transition-all flex items-center gap-2 cursor-pointer ${
            activeTab === 'intake'
              ? 'bg-blue-600 text-white shadow-md'
              : 'text-slate-400 hover:text-white hover:bg-slate-900'
          }`}
        >
          <Sliders className="w-3.5 h-3.5" />
          <span>Customer & Deduplication</span>
        </button>

        <button
          onClick={() => setActiveTab('qr')}
          className={`px-3.5 py-2 text-xs font-bold rounded-xl transition-all flex items-center gap-2 cursor-pointer ${
            activeTab === 'qr'
              ? 'bg-blue-600 text-white shadow-md'
              : 'text-slate-400 hover:text-white hover:bg-slate-900'
          }`}
        >
          <QrCode className="w-3.5 h-3.5" />
          <span>Showroom QR Portal</span>
        </button>

        <button
          onClick={() => setActiveTab('security')}
          className={`px-3.5 py-2 text-xs font-bold rounded-xl transition-all flex items-center gap-2 cursor-pointer ${
            activeTab === 'security'
              ? 'bg-blue-600 text-white shadow-md'
              : 'text-slate-400 hover:text-white hover:bg-slate-900'
          }`}
        >
          <Lock className="w-3.5 h-3.5" />
          <span>Security & Maintenance</span>
        </button>
      </div>

      {/* 3. Settings Form Sections */}
      <form onSubmit={handleSaveAll} className="space-y-6">
        {/* =========================================================================
            TAB 1: SHOWROOM IDENTITY & BIS COMPLIANCE
        ========================================================================= */}
        {activeTab === 'identity' && (
          <div className="bg-[#050b18] border border-blue-900/40 rounded-2xl p-6 shadow-xl space-y-6">
            <div className="border-b border-slate-800 pb-4">
              <h2 className="text-base font-bold text-white flex items-center gap-2">
                <Building className="w-4 h-4 text-blue-400" />
                <span>Showroom Identity & Government Registrations</span>
              </h2>
              <p className="text-xs text-slate-400 mt-1">
                Official business details printed on customer summary receipts, export files, and QR portal footer.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-slate-300">
                  Jewellery Store Name *
                </label>
                <input
                  type="text"
                  required
                  value={settings.businessName}
                  onChange={(e) => handleFieldChange('businessName', e.target.value)}
                  className="w-full px-3.5 py-2.5 text-xs bg-black border border-slate-700 rounded-xl text-white focus:outline-none focus:ring-1 focus:ring-blue-500 font-bold"
                  placeholder="e.g. Giri Jewels"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-slate-300">
                  Showroom Tagline / Slogan
                </label>
                <input
                  type="text"
                  value={settings.tagline}
                  onChange={(e) => handleFieldChange('tagline', e.target.value)}
                  className="w-full px-3.5 py-2.5 text-xs bg-black border border-slate-700 rounded-xl text-white focus:outline-none focus:ring-1 focus:ring-blue-500"
                  placeholder="e.g. Fine Gold, Diamond & Heritage Bridal Jewellery"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-slate-300">
                  Branch / Landmark
                </label>
                <input
                  type="text"
                  value={settings.branchName}
                  onChange={(e) => handleFieldChange('branchName', e.target.value)}
                  className="w-full px-3.5 py-2.5 text-xs bg-black border border-slate-700 rounded-xl text-white focus:outline-none focus:ring-1 focus:ring-blue-500"
                  placeholder="e.g. Trivandrum Flagship Showroom"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-slate-300">
                  GSTIN Tax Registration Number
                </label>
                <input
                  type="text"
                  value={settings.gstin}
                  onChange={(e) => handleFieldChange('gstin', e.target.value.toUpperCase())}
                  className="w-full px-3.5 py-2.5 text-xs bg-black border border-slate-700 rounded-xl text-white font-mono focus:outline-none focus:ring-1 focus:ring-blue-500 uppercase"
                  placeholder="e.g. 32AABCG1234F1Z9"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-slate-300 flex items-center justify-between">
                  <span>BIS Hallmark Licence / HUID Registration</span>
                  <span className="text-[10px] text-emerald-400 font-semibold">100% Certified</span>
                </label>
                <input
                  type="text"
                  value={settings.bisHallmarkNumber}
                  onChange={(e) => handleFieldChange('bisHallmarkNumber', e.target.value)}
                  className="w-full px-3.5 py-2.5 text-xs bg-black border border-slate-700 rounded-xl text-white font-mono focus:outline-none focus:ring-1 focus:ring-blue-500"
                  placeholder="e.g. HM/C-7849201"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-slate-300">
                  Official Showroom Email
                </label>
                <input
                  type="email"
                  value={settings.email}
                  onChange={(e) => handleFieldChange('email', e.target.value)}
                  className="w-full px-3.5 py-2.5 text-xs bg-black border border-slate-700 rounded-xl text-white focus:outline-none focus:ring-1 focus:ring-blue-500 font-mono"
                  placeholder="e.g. girijewelstvm@gmail.com"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-slate-300">
                  Store Contact Landline / Phone
                </label>
                <input
                  type="text"
                  value={settings.phone}
                  onChange={(e) => handleFieldChange('phone', e.target.value)}
                  className="w-full px-3.5 py-2.5 text-xs bg-black border border-slate-700 rounded-xl text-white focus:outline-none focus:ring-1 focus:ring-blue-500 font-mono"
                  placeholder="e.g. +91 98470 54321"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-slate-300">
                  Customer WhatsApp Hotline
                </label>
                <input
                  type="text"
                  value={settings.whatsappPhone}
                  onChange={(e) => handleFieldChange('whatsappPhone', e.target.value)}
                  className="w-full px-3.5 py-2.5 text-xs bg-black border border-slate-700 rounded-xl text-white focus:outline-none focus:ring-1 focus:ring-blue-500 font-mono"
                  placeholder="e.g. +91 98470 54321"
                />
              </div>
            </div>

            {/* Address Details */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-2 border-t border-slate-800">
              <div className="sm:col-span-3 space-y-1.5">
                <label className="text-xs font-semibold text-slate-300">
                  Full Showroom Street Address
                </label>
                <input
                  type="text"
                  value={settings.address}
                  onChange={(e) => handleFieldChange('address', e.target.value)}
                  className="w-full px-3.5 py-2.5 text-xs bg-black border border-slate-700 rounded-xl text-white focus:outline-none focus:ring-1 focus:ring-blue-500"
                  placeholder="e.g. MG Road, Overbridge Junction, East Fort"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-slate-300">City / District</label>
                <input
                  type="text"
                  value={settings.city}
                  onChange={(e) => handleFieldChange('city', e.target.value)}
                  className="w-full px-3.5 py-2 text-xs bg-black border border-slate-700 rounded-xl text-white focus:outline-none focus:ring-1 focus:ring-blue-500"
                  placeholder="e.g. Thiruvananthapuram"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-slate-300">State</label>
                <input
                  type="text"
                  value={settings.state}
                  onChange={(e) => handleFieldChange('state', e.target.value)}
                  className="w-full px-3.5 py-2 text-xs bg-black border border-slate-700 rounded-xl text-white focus:outline-none focus:ring-1 focus:ring-blue-500"
                  placeholder="e.g. Kerala"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-slate-300">Postal PIN Code</label>
                <input
                  type="text"
                  value={settings.pincode}
                  onChange={(e) => handleFieldChange('pincode', e.target.value)}
                  className="w-full px-3.5 py-2 text-xs bg-black border border-slate-700 rounded-xl text-white focus:outline-none focus:ring-1 focus:ring-blue-500 font-mono"
                  placeholder="e.g. 695001"
                />
              </div>
            </div>
          </div>
        )}

        {/* =========================================================================
            TAB 2: DAILY COUNTER RATES & PRICING
        ========================================================================= */}
        {activeTab === 'rates' && (
          <div className="bg-[#050b18] border border-blue-900/40 rounded-2xl p-6 shadow-xl space-y-6">
            <div className="border-b border-slate-800 pb-4 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <div>
                <h2 className="text-base font-bold text-white flex items-center gap-2">
                  <Coins className="w-4 h-4 text-blue-400" />
                  <span>Daily Jewellery Market Rates & Currency</span>
                </h2>
                <p className="text-xs text-slate-400 mt-1">
                  Reference daily bullion rates shown on executive counter dashboard and customer estimation sheets.
                </p>
              </div>

              <label className="flex items-center gap-2.5 text-xs text-slate-300 cursor-pointer bg-black/60 px-3 py-1.5 rounded-xl border border-slate-800">
                <input
                  type="checkbox"
                  checked={settings.showDailyRatesOnDashboard}
                  onChange={(e) => handleFieldChange('showDailyRatesOnDashboard', e.target.checked)}
                  className="rounded border-slate-700 text-blue-600 focus:ring-blue-500"
                />
                <span>Show Rates Bar on Dashboard</span>
              </label>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-slate-300">
                  Currency Symbol
                </label>
                <input
                  type="text"
                  required
                  value={settings.currency}
                  onChange={(e) => handleFieldChange('currency', e.target.value)}
                  className="w-full px-3.5 py-2.5 text-sm bg-black border border-slate-700 rounded-xl text-white font-mono font-bold focus:outline-none focus:ring-1 focus:ring-blue-500"
                  placeholder="₹"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-slate-300">
                  22K Gold Rate (per gram)
                </label>
                <div className="relative">
                  <span className="absolute left-3.5 top-2.5 text-xs text-slate-500 font-mono">{settings.currency}</span>
                  <input
                    type="number"
                    min="0"
                    step="1"
                    value={settings.rate22kGold}
                    onChange={(e) => handleFieldChange('rate22kGold', Number(e.target.value) || 0)}
                    className="w-full pl-8 pr-3.5 py-2.5 text-sm bg-black border border-slate-700 rounded-xl text-white font-mono font-bold focus:outline-none focus:ring-1 focus:ring-blue-500"
                  />
                </div>
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-slate-300">
                  24K Pure Gold Rate (per gram)
                </label>
                <div className="relative">
                  <span className="absolute left-3.5 top-2.5 text-xs text-slate-500 font-mono">{settings.currency}</span>
                  <input
                    type="number"
                    min="0"
                    step="1"
                    value={settings.rate24kGold}
                    onChange={(e) => handleFieldChange('rate24kGold', Number(e.target.value) || 0)}
                    className="w-full pl-8 pr-3.5 py-2.5 text-sm bg-black border border-slate-700 rounded-xl text-white font-mono font-bold focus:outline-none focus:ring-1 focus:ring-blue-500"
                  />
                </div>
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-slate-300">
                  Fine Silver Rate (per gram)
                </label>
                <div className="relative">
                  <span className="absolute left-3.5 top-2.5 text-xs text-slate-500 font-mono">{settings.currency}</span>
                  <input
                    type="number"
                    min="0"
                    step="0.5"
                    value={settings.rateSilver}
                    onChange={(e) => handleFieldChange('rateSilver', Number(e.target.value) || 0)}
                    className="w-full pl-8 pr-3.5 py-2.5 text-sm bg-black border border-slate-700 rounded-xl text-white font-mono font-bold focus:outline-none focus:ring-1 focus:ring-blue-500"
                  />
                </div>
              </div>
            </div>

            <div className="p-4 bg-black/60 rounded-xl border border-slate-800 flex items-center justify-between text-xs text-slate-300">
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-emerald-400" />
                <span>All rates applied in showroom estimate calculations use BIS Hallmark certified purity factors.</span>
              </div>
              <span className="text-[11px] text-slate-500 font-mono">Purity: 91.6 (22K) • 99.9 (24K)</span>
            </div>
          </div>
        )}

        {/* =========================================================================
            TAB 3: CUSTOMER INTAKE & DEDUPLICATION SAFEGUARDS
        ========================================================================= */}
        {activeTab === 'intake' && (
          <div className="bg-[#050b18] border border-blue-900/40 rounded-2xl p-6 shadow-xl space-y-6">
            <div className="border-b border-slate-800 pb-4">
              <h2 className="text-base font-bold text-white flex items-center gap-2">
                <Sliders className="w-4 h-4 text-blue-400" />
                <span>Customer Data Quality & Deduplication Policies</span>
              </h2>
              <p className="text-xs text-slate-400 mt-1">
                Configure automated rules that protect your customer directory from messy duplicates and incomplete entries.
              </p>
            </div>

            <div className="space-y-4">
              <label className="flex items-start gap-3 p-4 bg-black/60 rounded-xl border border-slate-800 cursor-pointer hover:border-blue-900 transition-colors">
                <input
                  type="checkbox"
                  checked={settings.enableDuplicateGuard}
                  onChange={(e) => handleFieldChange('enableDuplicateGuard', e.target.checked)}
                  className="mt-0.5 rounded border-slate-700 text-blue-600 focus:ring-blue-500"
                />
                <div>
                  <span className="text-xs font-bold text-white block">
                    Automatic Phone Duplicate Guard (Recommended)
                  </span>
                  <span className="text-[11px] text-slate-400 block mt-0.5">
                    Checks customer mobile numbers in real time while typing. If existing customer is found, offers 1-click update instead of creating redundant profiles.
                  </span>
                </div>
              </label>

              <label className="flex items-start gap-3 p-4 bg-black/60 rounded-xl border border-slate-800 cursor-pointer hover:border-blue-900 transition-colors">
                <input
                  type="checkbox"
                  checked={settings.autoFormatNames}
                  onChange={(e) => handleFieldChange('autoFormatNames', e.target.checked)}
                  className="mt-0.5 rounded border-slate-700 text-blue-600 focus:ring-blue-500"
                />
                <div>
                  <span className="text-xs font-bold text-white block">
                    Auto-Format Customer Names (Proper Title Case)
                  </span>
                  <span className="text-[11px] text-slate-400 block mt-0.5">
                    Automatically cleans uppercase or lowercase inputs (e.g. "rahul nair" → "Rahul Nair") for polished showroom records.
                  </span>
                </div>
              </label>

              <label className="flex items-start gap-3 p-4 bg-black/60 rounded-xl border border-slate-800 cursor-pointer hover:border-blue-900 transition-colors">
                <input
                  type="checkbox"
                  checked={settings.requireCityOnWalkin}
                  onChange={(e) => handleFieldChange('requireCityOnWalkin', e.target.checked)}
                  className="mt-0.5 rounded border-slate-700 text-blue-600 focus:ring-blue-500"
                />
                <div>
                  <span className="text-xs font-bold text-white block">
                    Promote City / Locality Capture on Walk-In Registration
                  </span>
                  <span className="text-[11px] text-slate-400 block mt-0.5">
                    Prompts staff to record the customer's native town or district for regional jewelry preference analytics.
                  </span>
                </div>
              </label>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
                <div className="space-y-1.5">
                  <label className="text-xs font-semibold text-slate-300">
                    Minimum Phone Number Digits
                  </label>
                  <input
                    type="number"
                    min="7"
                    max="15"
                    value={settings.minPhoneDigits}
                    onChange={(e) => handleFieldChange('minPhoneDigits', Number(e.target.value) || 10)}
                    className="w-full px-3.5 py-2.5 text-xs bg-black border border-slate-700 rounded-xl text-white font-mono focus:outline-none focus:ring-1 focus:ring-blue-500"
                  />
                  <span className="text-[10px] text-slate-500 block">Default is 10 digits for Indian standard numbers</span>
                </div>

                <div className="space-y-1.5">
                  <label className="text-xs font-semibold text-slate-300">
                    Default Customer Jewelry Category Tag
                  </label>
                  <select
                    value={settings.defaultCategoryId}
                    onChange={(e) => handleFieldChange('defaultCategoryId', e.target.value)}
                    className="w-full px-3.5 py-2.5 text-xs bg-black border border-slate-700 rounded-xl text-white focus:outline-none focus:ring-1 focus:ring-blue-500 cursor-pointer"
                  >
                    {categories.map((c) => (
                      <option key={c.id} value={c.id}>
                        {c.name} {c.isDefault ? '(System Default)' : ''}
                      </option>
                    ))}
                  </select>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* =========================================================================
            TAB 4: SHOWROOM QR PORTAL & STANDEE CUSTOMIZATION
        ========================================================================= */}
        {activeTab === 'qr' && (
          <div className="bg-[#050b18] border border-blue-900/40 rounded-2xl p-6 shadow-xl space-y-6">
            <div className="border-b border-slate-800 pb-4 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <div>
                <h2 className="text-base font-bold text-white flex items-center gap-2">
                  <QrCode className="w-4 h-4 text-blue-400" />
                  <span>Universal Showroom QR Standee Portal</span>
                </h2>
                <p className="text-xs text-slate-400 mt-1">
                  Customize the customer-facing mobile registration screen that opens when visitors scan your showroom counter QR standee.
                </p>
              </div>

              <label className="flex items-center gap-2.5 text-xs text-slate-300 cursor-pointer bg-black/60 px-3 py-1.5 rounded-xl border border-slate-800">
                <input
                  type="checkbox"
                  checked={settings.qrIntakeActive}
                  onChange={(e) => handleFieldChange('qrIntakeActive', e.target.checked)}
                  className="rounded border-slate-700 text-blue-600 focus:ring-blue-500"
                />
                <span className="font-semibold text-emerald-400">QR Intake Enabled</span>
              </label>
            </div>

            <div className="space-y-4">
              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-slate-300">
                  Welcome Heading (Customer Phone Screen)
                </label>
                <input
                  type="text"
                  value={settings.qrWelcomeHeading}
                  onChange={(e) => handleFieldChange('qrWelcomeHeading', e.target.value)}
                  className="w-full px-3.5 py-2.5 text-xs bg-black border border-slate-700 rounded-xl text-white font-bold focus:outline-none focus:ring-1 focus:ring-blue-500"
                  placeholder="Welcome to Giri Jewels"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-slate-300">
                  Form Subtitle / Invitation Note
                </label>
                <textarea
                  rows={2}
                  value={settings.qrSubtitle}
                  onChange={(e) => handleFieldChange('qrSubtitle', e.target.value)}
                  className="w-full px-3.5 py-2 text-xs bg-black border border-slate-700 rounded-xl text-white focus:outline-none focus:ring-1 focus:ring-blue-500 resize-none"
                  placeholder="Kindly register your details for personalized service, jewelry care updates, and festival offers..."
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-slate-300">
                  Thank You / Completion Message (Shown after registration)
                </label>
                <textarea
                  rows={2}
                  value={settings.qrSuccessMessage}
                  onChange={(e) => handleFieldChange('qrSuccessMessage', e.target.value)}
                  className="w-full px-3.5 py-2 text-xs bg-black border border-slate-700 rounded-xl text-white focus:outline-none focus:ring-1 focus:ring-blue-500 resize-none"
                  placeholder="Thank you for visiting Giri Jewels! Your showroom visit details have been registered..."
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-slate-300">
                  Counter Standee Print Tagline
                </label>
                <input
                  type="text"
                  value={settings.standeeTagline}
                  onChange={(e) => handleFieldChange('standeeTagline', e.target.value)}
                  className="w-full px-3.5 py-2.5 text-xs bg-black border border-slate-700 rounded-xl text-white focus:outline-none focus:ring-1 focus:ring-blue-500"
                  placeholder="Scan to join VIP rewards & fast showroom customer intake"
                />
              </div>

              <div className="pt-3 border-t border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-black/60 p-4 rounded-xl border border-slate-800">
                <div>
                  <span className="text-xs font-bold text-white block">
                    Showroom QR Logs & Analytics Reset
                  </span>
                  <span className="text-[11px] text-slate-400 block mt-0.5">
                    Clear all past QR scan counts and device analytics to start with a fresh visitor log.
                  </span>
                </div>
                <button
                  type="button"
                  onClick={promptClearQRData}
                  className="px-3.5 py-2 text-xs font-bold text-amber-300 hover:text-white bg-amber-950/60 hover:bg-amber-900 border border-amber-800/80 rounded-xl transition-colors cursor-pointer flex items-center gap-1.5 shrink-0"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>Clear All QR Scan Data</span>
                </button>
              </div>
            </div>
          </div>
        )}

        {/* =========================================================================
            TAB 5: SECURITY, BACKUPS & MAINTENANCE
        ========================================================================= */}
        {activeTab === 'security' && (
          <div className="bg-[#050b18] border border-blue-900/40 rounded-2xl p-6 shadow-xl space-y-6">
            <div className="border-b border-slate-800 pb-4">
              <h2 className="text-base font-bold text-white flex items-center gap-2">
                <Lock className="w-4 h-4 text-blue-400" />
                <span>Showroom Security, Admin Overrides & Backups</span>
              </h2>
              <p className="text-xs text-slate-400 mt-1">
                Configure manager PIN codes, role-based export permissions, and perform database maintenance.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-slate-300 flex items-center justify-between">
                  <span>Store Master Security PIN *</span>
                  <span className="text-[10px] text-blue-400 font-mono">Used for on-screen overrides</span>
                </label>
                <input
                  type="text"
                  required
                  value={settings.masterSecurityPin}
                  onChange={(e) => handleFieldChange('masterSecurityPin', e.target.value.trim())}
                  className="w-full px-3.5 py-2.5 text-xs bg-black border border-slate-700 rounded-xl text-white font-mono font-bold focus:outline-none focus:ring-1 focus:ring-blue-500"
                  placeholder="GIRI-7788"
                />
                <span className="text-[10px] text-slate-500 block">
                  Accepted in PermissionModal when counter staff request deletion or restricted actions
                </span>
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-slate-300">
                  Session Inactivity Auto-Lock
                </label>
                <select
                  value={settings.sessionTimeoutMinutes}
                  onChange={(e) => handleFieldChange('sessionTimeoutMinutes', Number(e.target.value) || 60)}
                  className="w-full px-3.5 py-2.5 text-xs bg-black border border-slate-700 rounded-xl text-white focus:outline-none focus:ring-1 focus:ring-blue-500 cursor-pointer"
                >
                  <option value={15}>15 Minutes</option>
                  <option value={30}>30 Minutes</option>
                  <option value={60}>60 Minutes (Recommended)</option>
                  <option value={120}>2 Hours</option>
                  <option value={0}>Never (Always Open)</option>
                </select>
              </div>
            </div>

            <div className="p-4 bg-black/60 rounded-xl border border-slate-800 space-y-3">
              <label className="flex items-center gap-3 cursor-pointer">
                <input
                  type="checkbox"
                  checked={settings.allowStaffExports}
                  onChange={(e) => handleFieldChange('allowStaffExports', e.target.checked)}
                  className="rounded border-slate-700 text-blue-600 focus:ring-blue-500"
                />
                <div>
                  <span className="text-xs font-bold text-white block">
                    Allow Counter Staff to Export Excel & PDF Reports
                  </span>
                  <span className="text-[11px] text-slate-400 block mt-0.5">
                    When disabled, only Store Admin can download customer lists to preserve customer phone privacy.
                  </span>
                </div>
              </label>
            </div>

            {/* Danger Zone: Database Reset */}
            <div className="pt-4 border-t border-rose-950/60 p-4 bg-rose-950/20 border border-rose-900/40 rounded-xl space-y-3">
              <div className="flex items-center gap-2 text-rose-400 font-bold text-xs uppercase tracking-wider">
                <AlertTriangle className="w-4 h-4 text-rose-500" />
                <span>Danger Zone: Database Reset</span>
              </div>
              <p className="text-xs text-slate-400 leading-relaxed">
                Clear all {customers.length} customer records from your live showroom storage. Always download a JSON backup first.
              </p>
              <button
                type="button"
                onClick={promptClearCustomers}
                className="px-4 py-2 bg-rose-700 hover:bg-rose-600 text-white text-xs font-bold rounded-xl shadow-lg transition-all flex items-center gap-2 cursor-pointer"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Clear All Customer Records ({customers.length})</span>
              </button>
            </div>
          </div>
        )}

        {/* Floating Bottom Save Action */}
        <div className="p-4 bg-[#050b18] border border-blue-900/40 rounded-2xl flex items-center justify-between shadow-xl">
          <div className="text-xs text-slate-400">
            Showroom changes take effect across all counter terminals immediately.
          </div>
          <button
            type="submit"
            disabled={isSaving}
            className="px-6 py-2.5 bg-blue-600 hover:bg-blue-500 disabled:opacity-50 text-white text-xs font-black rounded-xl shadow-lg shadow-blue-900/40 transition-all flex items-center gap-2 cursor-pointer active:scale-98"
          >
            <Save className="w-4 h-4" />
            <span>{isSaving ? 'Saving Changes...' : 'Save All Settings'}</span>
          </button>
        </div>
      </form>

      {/* Showroom Confirmation Dialog */}
      <ConfirmationModal
        isOpen={confirmModal.isOpen}
        onClose={() => setConfirmModal(prev => ({ ...prev, isOpen: false }))}
        onConfirm={confirmModal.onConfirm}
        title={confirmModal.title}
        description={confirmModal.description}
        confirmText={confirmModal.confirmText}
        variant={confirmModal.variant}
        itemDetails={confirmModal.itemDetails}
      />
    </div>
  );
};
