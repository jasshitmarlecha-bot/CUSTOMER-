import { Users, QrCode, Sparkles, UserPlus, Gem, ShieldCheck, Lock, LogOut, Upload } from 'lucide-react';
import { StaffUser } from '../../types/index.ts';

interface NavbarProps {
  currentUser: StaffUser;
  onLogout: () => void;
  onOpenStaffAccessModal: () => void;
  onOpenAddCustomer: () => void;
  onNavigateTab: (tab: string) => void;
  businessName: string;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentUser,
  onLogout,
  onOpenStaffAccessModal,
  onOpenAddCustomer,
  onNavigateTab,
  businessName
}) => {
  const permissions = currentUser.permissions || {
    canAddEditCustomers: currentUser.role === 'admin',
    canImportData: currentUser.role === 'admin',
    canViewCommonQR: true
  };

  return (
    <header className="bg-[#050b18]/95 backdrop-blur-md border-b border-slate-800 sticky top-0 z-30 shadow-lg">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
        {/* Brand */}
        <div className="flex items-center gap-3">
          <button
            onClick={() => onNavigateTab('dashboard')}
            className="flex items-center gap-3 text-left focus:outline-none group cursor-pointer"
          >
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-blue-600 to-slate-950 flex items-center justify-center text-white shadow-lg shadow-blue-900/30 border border-blue-500/40 group-hover:scale-105 transition-transform">
              <Gem className="w-5 h-5 text-white" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-bold text-lg text-white tracking-tight group-hover:text-blue-400 transition-colors">
                  {businessName || 'Giri Jewels'}
                </span>
                <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full bg-blue-950 text-blue-300 border border-blue-800">
                  MANAGEMENT SYSTEM
                </span>
              </div>
              <p className="text-xs text-slate-400 hidden sm:block">Customer Database & Showroom QR Suite</p>
            </div>
          </button>
        </div>

        {/* Quick Actions & Staff Profile */}
        <div className="flex items-center gap-2.5">
          {/* QR Suite button */}
          <button
            onClick={() => onNavigateTab('qr_common')}
            className="hidden sm:inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-white bg-slate-900 hover:bg-slate-800 border border-slate-700 rounded-lg transition-colors cursor-pointer"
            title="Open Showroom QR Suite"
          >
            <QrCode className="w-3.5 h-3.5 text-blue-400" />
            <span>QR Suite</span>
          </button>

          {/* Import Data button in Menu Bar */}
          {permissions.canImportData && (
            <button
              onClick={() => onNavigateTab('import')}
              className="hidden md:inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-200 hover:text-white bg-slate-900 hover:bg-slate-800 border border-slate-700 rounded-lg transition-colors cursor-pointer"
              title="Import outside customer data (Excel & CSV)"
            >
              <Upload className="w-3.5 h-3.5 text-blue-400" />
              <span>Import Data</span>
            </button>
          )}

          {/* Add Customer button (Crisp White / Black or Blue) */}
          {permissions.canAddEditCustomers && (
            <button
              onClick={onOpenAddCustomer}
              className="inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-bold text-white bg-blue-600 hover:bg-blue-500 active:scale-95 rounded-lg shadow-md shadow-blue-900/30 transition-all border border-blue-400/40 cursor-pointer"
            >
              <UserPlus className="w-3.5 h-3.5 text-white" />
              <span>+ Add Walk-In</span>
            </button>
          )}

          {/* Admin Staff Permissions Manager Button */}
          {currentUser.role === 'admin' && (
            <button
              onClick={onOpenStaffAccessModal}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-blue-300 bg-blue-950/80 hover:bg-blue-900/60 border border-blue-800/80 rounded-lg transition-colors cursor-pointer"
              title="Manage Staff Permissions & Access"
            >
              <ShieldCheck className="w-3.5 h-3.5 text-blue-400" />
              <span className="hidden md:inline">Staff Access Control</span>
            </button>
          )}

          <div className="h-6 w-px bg-slate-800 mx-1 hidden sm:block" />

          {/* User Account & Clean Logout / Exit */}
          <div className="flex items-center gap-2.5">
            <div className="text-right hidden sm:block">
              <p className="text-xs font-semibold text-white leading-tight">{currentUser.name}</p>
              <span className={`text-[10px] font-semibold capitalize px-1.5 py-0.5 rounded border ${
                currentUser.role === 'admin'
                  ? 'text-white bg-blue-950 border-blue-700'
                  : 'text-blue-300 bg-slate-900 border-slate-700'
              }`}>
                {currentUser.role === 'admin' ? 'Store Admin' : 'Counter Staff'}
              </span>
            </div>

            <button
              onClick={onLogout}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-300 hover:text-white bg-slate-900 hover:bg-slate-800 border border-slate-700 rounded-lg transition-all cursor-pointer shadow-xs"
              title="Log out and return to password login gate"
            >
              <LogOut className="w-3.5 h-3.5 text-slate-400" />
              <span>Log Out</span>
            </button>
          </div>
        </div>
      </div>
    </header>
  );
};
