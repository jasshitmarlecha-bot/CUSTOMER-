import React from 'react';
import {
  LayoutDashboard,
  Users,
  Tags,
  QrCode,
  Sparkles,
  BarChart3,
  Settings,
  UserPlus,
  ShieldCheck,
  Lock,
  Gem,
  Printer,
  Upload,
  CopyCheck
} from 'lucide-react';
import { StaffUser } from '../../types/index.ts';

interface SidebarProps {
  activeTab: string;
  onSelectTab: (tab: string) => void;
  onOpenAddCustomer: () => void;
  onOpenStaffAccessModal?: () => void;
  customerCount: number;
  currentUser: StaffUser;
}

export const Sidebar: React.FC<SidebarProps> = ({
  activeTab,
  onSelectTab,
  onOpenAddCustomer,
  onOpenStaffAccessModal,
  customerCount,
  currentUser
}) => {
  const permissions = currentUser.permissions || {
    canViewCustomers: true,
    canAddEditCustomers: currentUser.role === 'admin',
    canDeleteCustomers: currentUser.role === 'admin',
    canExportData: true,
    canImportData: currentUser.role === 'admin',
    canPrintData: true,
    canManageCategories: currentUser.role === 'admin',
    canRunCleaning: currentUser.role === 'admin',
    canViewAnalytics: true,
    canViewCommonQR: true
  };

  const menuSections = [
    {
      title: 'Store Operations',
      items: [
        {
          id: 'dashboard',
          label: 'Store Dashboard',
          icon: LayoutDashboard,
          badge: 'Home',
          isPermitted: true
        },
        {
          id: 'customers',
          label: 'Customer Directory',
          icon: Users,
          badge: customerCount > 0 ? customerCount : null,
          isPermitted: permissions.canViewCustomers
        },
        {
          id: 'import',
          label: 'Import Customer Data',
          icon: Upload,
          badge: 'Excel/CSV',
          isPermitted: permissions.canImportData
        },
        {
          id: 'duplicates',
          label: 'Duplicate Manager',
          icon: CopyCheck,
          badge: 'Deduplicate',
          isPermitted: permissions.canRunCleaning
        },
        {
          id: 'qr_common',
          label: 'Showroom Common QR',
          icon: QrCode,
          badge: 'Live',
          isPermitted: permissions.canViewCommonQR
        }
      ]
    },
    {
      title: 'Intelligence & Reports',
      badge: 'All-In-One',
      items: [
        {
          id: 'analytics',
          label: 'Analysis Hub (Scans, Growth, Quality)',
          icon: BarChart3,
          badge: '3 Reports',
          isPermitted: permissions.canViewAnalytics
        }
      ]
    },
    {
      title: 'Catalog & Store Setup',
      items: [
        {
          id: 'categories',
          label: 'Jewelry Categories',
          icon: Tags,
          badge: null,
          isPermitted: permissions.canManageCategories
        },
        {
          id: 'settings',
          label: 'Store Settings & Access',
          icon: Settings,
          badge: null,
          isPermitted: currentUser.role === 'admin'
        }
      ]
    }
  ];

  return (
    <aside className="w-full md:w-64 bg-[#050b18] border-r border-slate-800 flex flex-col shrink-0 font-sans">
      {/* Quick Add Walk-In Button (Crisp White / Black contrast) */}
      {permissions.canAddEditCustomers && (
        <div className="p-4 pb-2">
          <button
            onClick={onOpenAddCustomer}
            className="w-full flex items-center justify-center gap-2 px-3 py-2.5 rounded-xl bg-white hover:bg-slate-100 text-slate-950 font-bold text-xs shadow-md transition-all cursor-pointer active:scale-[0.98]"
          >
            <UserPlus className="w-4 h-4 text-slate-950" />
            <span>+ Quick Walk-In Entry</span>
          </button>
        </div>
      )}

      {/* Structured, Comfortable Menus */}
      <div className="p-3 space-y-5 overflow-y-auto flex-1">
        {menuSections.map((section, sIdx) => (
          <div key={sIdx} className="space-y-1">
            <div className="flex items-center justify-between px-3">
              <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">
                {section.title}
              </p>
              {section.badge && (
                <span className="text-[9px] font-bold uppercase tracking-wider px-1.5 py-0.2 rounded bg-blue-950 text-blue-300 border border-blue-800">
                  {section.badge}
                </span>
              )}
            </div>

            <div className="space-y-0.5">
              {section.items.map((item) => {
                const Icon = item.icon;
                const isActive =
                  activeTab === item.id ||
                  (item.id === 'qr_common' && (activeTab === 'intake' || activeTab.startsWith('qr_'))) ||
                  (item.id === 'analytics' && activeTab === 'cleaning');
                const isPermitted = item.isPermitted;

                return (
                  <button
                    key={item.id}
                    disabled={!isPermitted}
                    onClick={() => onSelectTab(item.id)}
                    className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-medium transition-all ${
                      !isPermitted
                        ? 'opacity-40 cursor-not-allowed text-slate-500'
                        : isActive
                        ? 'bg-blue-600 text-white font-bold shadow-md shadow-blue-900/40 cursor-pointer'
                        : 'text-slate-300 hover:text-white hover:bg-slate-900/90 border border-transparent cursor-pointer'
                    }`}
                  >
                    <div className="flex items-center gap-2.5 min-w-0">
                      <Icon
                        className={`w-4 h-4 shrink-0 ${
                          isActive
                            ? 'text-white'
                            : isPermitted
                            ? 'text-blue-400'
                            : 'text-slate-600'
                        }`}
                      />
                      <span className="truncate">{item.label}</span>
                    </div>

                    {!isPermitted ? (
                      <span title="Admin permission required">
                        <Lock className="w-3 h-3 text-slate-600" />
                      </span>
                    ) : item.badge !== null ? (
                      <span
                        className={`text-[10px] px-2 py-0.5 rounded-full font-semibold shrink-0 ml-1 ${
                          isActive
                            ? 'bg-white/20 text-white border border-white/30'
                            : typeof item.badge === 'number'
                            ? 'bg-slate-900 text-slate-300 border border-slate-700'
                            : 'bg-blue-950 text-blue-300 border border-blue-800'
                        }`}
                      >
                        {item.badge}
                      </span>
                    ) : null}
                  </button>
                );
              })}
            </div>
          </div>
        ))}

        {/* Admin Staff Access Shortcut */}
        {currentUser.role === 'admin' && onOpenStaffAccessModal && (
          <div className="px-3 pt-1">
            <button
              onClick={onOpenStaffAccessModal}
              className="w-full flex items-center justify-between p-2.5 rounded-xl bg-blue-950/40 hover:bg-blue-950/80 border border-blue-800/60 text-blue-300 text-xs font-semibold transition-colors cursor-pointer"
            >
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-blue-400" />
                <span>Staff Access Control</span>
              </div>
              <span className="text-[10px] px-1.5 py-0.2 bg-blue-600/30 rounded text-blue-200">
                Manage
              </span>
            </button>
          </div>
        )}
      </div>

      {/* Bottom Store DB Status */}
      <div className="mt-auto p-3 border-t border-slate-800/80">
        <div className="bg-black rounded-xl p-3 border border-slate-800 text-xs text-slate-400 space-y-1.5">
          <div className="flex items-center justify-between font-semibold text-white">
            <div className="flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4 text-blue-400" />
              <span>Giri Jewels Counter DB</span>
            </div>
            <span className="text-[10px] text-blue-400 font-mono">v1.4</span>
          </div>
          <p className="text-[11px] text-slate-400 leading-relaxed">
            Encrypted store records with real-time QR footfall tracking and access control.
          </p>
        </div>
      </div>
    </aside>
  );
};
