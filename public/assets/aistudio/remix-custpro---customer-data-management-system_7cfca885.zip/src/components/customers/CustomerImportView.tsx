import React, { useState, useRef } from 'react';
import {
  Upload,
  FileSpreadsheet,
  Download,
  AlertCircle,
  CheckCircle2,
  FileText,
  Table,
  HelpCircle,
  Sparkles,
  ArrowRight,
  Users,
  Check,
  RefreshCw,
  ShieldCheck,
  Filter,
  CopyCheck,
  AlertTriangle
} from 'lucide-react';
import * as XLSX from 'xlsx';
import { Customer } from '../../types/index.ts';

interface CustomerImportViewProps {
  existingCustomers?: Customer[];
  onImportComplete: (
    customers: Array<{
      name: string;
      phone: string;
      email?: string;
      category?: string;
      address?: string;
      city?: string;
      status?: 'active' | 'lead' | 'inactive';
    }>,
    strategy?: 'skip' | 'update' | 'all'
  ) => Promise<{ importedCount: number; updatedCount?: number; skippedCount?: number; errors: string[] }>;
  onNavigateToDirectory: () => void;
  totalCustomersCount: number;
}

interface ParsedCustomerRow {
  name: string;
  phone: string;
  email?: string;
  category?: string;
  address?: string;
  city?: string;
  status: 'active' | 'lead' | 'inactive';
  isValid: boolean;
  validationError?: string;
  duplicateType: 'none' | 'database' | 'file';
  duplicateMatchName?: string;
}

export const CustomerImportView: React.FC<CustomerImportViewProps> = ({
  existingCustomers = [],
  onImportComplete,
  onNavigateToDirectory,
  totalCustomersCount
}) => {
  const [file, setFile] = useState<File | null>(null);
  const [parsedRows, setParsedRows] = useState<ParsedCustomerRow[]>([]);
  const [isProcessing, setIsProcessing] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorNotice, setErrorNotice] = useState<string | null>(null);
  const [pasteData, setPasteData] = useState('');
  const [importMode, setImportMode] = useState<'upload' | 'paste'>('upload');
  const [deduplicateStrategy, setDeduplicateStrategy] = useState<'skip' | 'update' | 'all'>('skip');
  const [importResult, setImportResult] = useState<{
    importedCount: number;
    updatedCount?: number;
    skippedCount?: number;
    errors: string[];
  } | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Generate and download a sample template
  const handleDownloadTemplate = (format: 'xlsx' | 'csv') => {
    const templateData = [
      {
        Name: 'Priya Sharma',
        Phone: '9845012345',
        Email: 'priya.sharma@example.com',
        Category: 'VIP Customer',
        Address: '42 MG Road, Indiranagar',
        City: 'Bangalore',
        Status: 'active'
      },
      {
        Name: 'Rajesh Verma',
        Phone: '9876543210',
        Email: 'rajesh.v@example.com',
        Category: 'Retail Walk-in',
        Address: '7th Cross, Gandhinagar',
        City: 'Mumbai',
        Status: 'lead'
      },
      {
        Name: 'Ananya Nair',
        Phone: '9123456789',
        Email: 'ananya@example.com',
        Category: 'Wholesale / B2B',
        Address: 'Marine Drive',
        City: 'Kochi',
        Status: 'active'
      }
    ];

    const worksheet = XLSX.utils.json_to_sheet(templateData);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, 'Customers');

    if (format === 'xlsx') {
      XLSX.writeFile(workbook, 'giri_jewels_import_template.xlsx');
    } else {
      XLSX.writeFile(workbook, 'giri_jewels_import_template.csv', { bookType: 'csv' });
    }
  };

  const processRawData = (rows: any[]) => {
    const parsed: ParsedCustomerRow[] = [];
    const seenPhonesInBatch = new Set<string>();

    for (const r of rows) {
      const keys = Object.keys(r);
      const findKey = (candidates: string[]) => {
        const found = keys.find(k => candidates.includes(k.trim().toLowerCase()));
        return found ? String(r[found] || '').trim() : '';
      };

      const name = findKey(['name', 'customer name', 'full name', 'client']);
      const phone = findKey(['phone', 'mobile', 'phone number', 'contact', 'telephone', 'mobile number']);
      const email = findKey(['email', 'email address', 'mail']);
      const category = findKey(['category', 'category name', 'type', 'group']);
      const address = findKey(['address', 'street', 'locality']);
      const city = findKey(['city', 'town', 'district', 'location']);
      const rawStatus = findKey(['status', 'state']).toLowerCase();

      let status: 'active' | 'lead' | 'inactive' = 'active';
      if (rawStatus === 'lead') status = 'lead';
      else if (rawStatus === 'inactive') status = 'inactive';

      const isValid = Boolean(name && phone && phone.replace(/\D/g, '').length >= 7);
      let validationError: string | undefined;
      if (!name) validationError = 'Missing name';
      else if (!phone) validationError = 'Missing phone number';
      else if (phone.replace(/\D/g, '').length < 7) validationError = 'Phone number too short (minimum 7 digits)';

      const cleanPhone = phone ? phone.replace(/\D/g, '').slice(-10) : '';
      const cleanEmail = email ? email.trim().toLowerCase() : '';

      // Check duplicates
      let duplicateType: 'none' | 'database' | 'file' = 'none';
      let duplicateMatchName: string | undefined;

      if (cleanPhone && cleanPhone.length >= 7 && seenPhonesInBatch.has(cleanPhone)) {
        duplicateType = 'file';
        duplicateMatchName = 'Repeated row in this file';
      } else if (existingCustomers && existingCustomers.length > 0) {
        const match = existingCustomers.find(c => {
          const cPhone = c.phone ? c.phone.replace(/\D/g, '').slice(-10) : '';
          if (cleanPhone && cleanPhone.length >= 7 && cPhone === cleanPhone) return true;
          if (cleanEmail && cleanEmail.includes('@') && c.email?.trim().toLowerCase() === cleanEmail) return true;
          return false;
        });
        if (match) {
          duplicateType = 'database';
          duplicateMatchName = `Already in DB (${match.name})`;
        }
      }

      if (cleanPhone && cleanPhone.length >= 7) {
        seenPhonesInBatch.add(cleanPhone);
      }

      parsed.push({
        name,
        phone,
        email: email || undefined,
        category: category || undefined,
        address: address || undefined,
        city: city || undefined,
        status,
        isValid,
        validationError,
        duplicateType,
        duplicateMatchName
      });
    }

    setParsedRows(parsed);
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const uploadedFile = e.target.files?.[0];
    if (!uploadedFile) return;

    setFile(uploadedFile);
    setIsProcessing(true);
    setErrorNotice(null);
    setImportResult(null);

    const reader = new FileReader();
    reader.onload = (evt) => {
      try {
        const data = evt.target?.result;
        const workbook = XLSX.read(data, { type: 'binary' });
        const firstSheetName = workbook.SheetNames[0];
        const worksheet = workbook.Sheets[firstSheetName];
        const json = XLSX.utils.sheet_to_json(worksheet);

        if (!json || json.length === 0) {
          setErrorNotice('The file appears empty or cannot be parsed.');
          setParsedRows([]);
        } else {
          processRawData(json);
        }
      } catch (err: any) {
        setErrorNotice(`Error parsing file: ${err.message}`);
      } finally {
        setIsProcessing(false);
      }
    };
    reader.onerror = () => {
      setErrorNotice('Failed to read file from disk.');
      setIsProcessing(false);
    };
    reader.readAsBinaryString(uploadedFile);
  };

  const handleProcessPasted = () => {
    if (!pasteData.trim()) return;
    setImportResult(null);
    try {
      const workbook = XLSX.read(pasteData, { type: 'string' });
      const firstSheetName = workbook.SheetNames[0];
      const worksheet = workbook.Sheets[firstSheetName];
      const json = XLSX.utils.sheet_to_json(worksheet);

      if (!json || json.length === 0) {
        setErrorNotice('Could not recognize any valid rows in the pasted text.');
        setParsedRows([]);
      } else {
        processRawData(json);
      }
    } catch (err: any) {
      setErrorNotice(`Failed to process pasted content: ${err.message}`);
    }
  };

  const handleConfirmImport = async () => {
    const validRows = parsedRows.filter(r => r.isValid);
    if (validRows.length === 0) {
      setErrorNotice('No valid records to import. Please check required columns (Name and Phone).');
      return;
    }

    setIsSubmitting(true);
    setErrorNotice(null);

    try {
      const result = await onImportComplete(validRows, deduplicateStrategy);
      setImportResult(result);
    } catch (err: any) {
      setErrorNotice(err.message || 'Import failed.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const validCount = parsedRows.filter(r => r.isValid).length;
  const invalidCount = parsedRows.length - validCount;
  const dbDuplicatesCount = parsedRows.filter(r => r.duplicateType === 'database').length;
  const fileDuplicatesCount = parsedRows.filter(r => r.duplicateType === 'file').length;

  return (
    <div className="space-y-6">
      {/* Title & Status Banner */}
      <div className="bg-[#050b18] border border-blue-900/40 rounded-2xl p-5 shadow-xl flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-blue-600/20 border border-blue-500/40 flex items-center justify-center text-blue-400">
              <Upload className="w-4 h-4" />
            </div>
            <h1 className="text-xl font-bold text-white tracking-tight">Import Customer Data</h1>
            <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full bg-blue-950 text-blue-300 border border-blue-800">
              Menu Operation
            </span>
          </div>
          <p className="text-xs text-slate-300">
            Bulk upload customer records with real-time deduplication prevention against existing database numbers.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => handleDownloadTemplate('xlsx')}
            className="px-3 py-2 bg-blue-950 hover:bg-blue-900 text-blue-200 border border-blue-800 text-xs font-semibold rounded-xl flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Sample Excel (.xlsx)</span>
          </button>
          <button
            onClick={() => handleDownloadTemplate('csv')}
            className="px-3 py-2 bg-slate-900 hover:bg-slate-800 text-slate-300 border border-slate-700 text-xs font-semibold rounded-xl flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Sample CSV</span>
          </button>
        </div>
      </div>

      {/* Successful Import Result Banner */}
      {importResult && (
        <div className="p-5 bg-gradient-to-r from-emerald-950/90 via-slate-950 to-blue-950/60 border border-emerald-500/50 rounded-2xl shadow-xl space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center border border-emerald-500/40">
                <CheckCircle2 className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-white">Import & Deduplication Finished!</h3>
                <p className="text-xs text-emerald-300">
                  {importResult.importedCount} new customers created • {importResult.updatedCount || 0} existing records updated • {importResult.skippedCount || 0} duplicates skipped.
                </p>
              </div>
            </div>

            <button
              onClick={onNavigateToDirectory}
              className="px-4 py-2 bg-white text-slate-950 text-xs font-bold rounded-xl shadow-md hover:bg-slate-100 transition-colors flex items-center gap-1.5 cursor-pointer"
            >
              <span>View Customer Directory</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          {importResult.errors.length > 0 && (
            <div className="p-3 bg-black/60 rounded-xl border border-slate-800 text-xs text-rose-300 space-y-1">
              <span className="font-semibold block text-rose-400">Warnings / Skipped entries:</span>
              {importResult.errors.slice(0, 3).map((err, i) => (
                <div key={i} className="text-[11px] text-slate-400">• {err}</div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Main Workspace Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left Column: Specifications & Deduplication Strategy */}
        <div className="lg:col-span-5 bg-[#050b18] border border-blue-900/30 rounded-2xl p-5 shadow-lg space-y-4">
          <div className="space-y-1">
            <h2 className="text-sm font-bold text-white flex items-center gap-2">
              <CopyCheck className="w-4 h-4 text-blue-400" />
              <span>Deduplication Strategy</span>
            </h2>
            <p className="text-xs text-slate-400">
              Choose how the system handles rows matching existing phone numbers or emails.
            </p>
          </div>

          {/* Strategy Picker Options */}
          <div className="space-y-2">
            <label
              onClick={() => setDeduplicateStrategy('skip')}
              className={`p-3 rounded-xl border flex items-start gap-3 cursor-pointer transition-colors ${
                deduplicateStrategy === 'skip'
                  ? 'bg-blue-950/60 border-blue-500 text-white'
                  : 'bg-black/40 border-slate-800 text-slate-400 hover:text-white'
              }`}
            >
              <input
                type="radio"
                name="strategy"
                checked={deduplicateStrategy === 'skip'}
                onChange={() => setDeduplicateStrategy('skip')}
                className="mt-0.5"
              />
              <div className="space-y-0.5">
                <span className="text-xs font-bold text-white block">Skip Duplicates (Recommended)</span>
                <span className="text-[11px] text-slate-400 block">
                  Only imports fresh customers. Existing customer records in the database remain untouched.
                </span>
              </div>
            </label>

            <label
              onClick={() => setDeduplicateStrategy('update')}
              className={`p-3 rounded-xl border flex items-start gap-3 cursor-pointer transition-colors ${
                deduplicateStrategy === 'update'
                  ? 'bg-blue-950/60 border-blue-500 text-white'
                  : 'bg-black/40 border-slate-800 text-slate-400 hover:text-white'
              }`}
            >
              <input
                type="radio"
                name="strategy"
                checked={deduplicateStrategy === 'update'}
                onChange={() => setDeduplicateStrategy('update')}
                className="mt-0.5"
              />
              <div className="space-y-0.5">
                <span className="text-xs font-bold text-white block">Update / Enrich Existing Records</span>
                <span className="text-[11px] text-slate-400 block">
                  If phone matches an existing customer, updates their category, city, and notes instead of duplicating.
                </span>
              </div>
            </label>

            <label
              onClick={() => setDeduplicateStrategy('all')}
              className={`p-3 rounded-xl border flex items-start gap-3 cursor-pointer transition-colors ${
                deduplicateStrategy === 'all'
                  ? 'bg-blue-950/60 border-blue-500 text-white'
                  : 'bg-black/40 border-slate-800 text-slate-400 hover:text-white'
              }`}
            >
              <input
                type="radio"
                name="strategy"
                checked={deduplicateStrategy === 'all'}
                onChange={() => setDeduplicateStrategy('all')}
                className="mt-0.5"
              />
              <div className="space-y-0.5">
                <span className="text-xs font-bold text-white block">Import All Rows Raw</span>
                <span className="text-[11px] text-slate-400 block">
                  Creates all records without deduplication checks.
                </span>
              </div>
            </label>
          </div>

          {/* Expected Columns Table */}
          <div className="pt-2 border-t border-slate-800 space-y-2">
            <span className="text-xs font-bold text-white block">Supported Columns</span>
            <div className="border border-slate-800 rounded-xl overflow-hidden bg-black">
              <table className="w-full text-left text-xs">
                <tbody className="divide-y divide-slate-800/60 text-slate-300">
                  <tr>
                    <td className="py-1.5 px-3 font-mono text-blue-300 font-bold">Name</td>
                    <td className="py-1.5 px-3 text-rose-400 font-semibold">Required</td>
                    <td className="py-1.5 px-3">Priya Sharma</td>
                  </tr>
                  <tr>
                    <td className="py-1.5 px-3 font-mono text-blue-300 font-bold">Phone</td>
                    <td className="py-1.5 px-3 text-rose-400 font-semibold">Required</td>
                    <td className="py-1.5 px-3">9845012345</td>
                  </tr>
                  <tr>
                    <td className="py-1.5 px-3 font-mono text-slate-200">Email</td>
                    <td className="py-1.5 px-3 text-slate-400">Optional</td>
                    <td className="py-1.5 px-3">priya@example.com</td>
                  </tr>
                  <tr>
                    <td className="py-1.5 px-3 font-mono text-slate-200">Category</td>
                    <td className="py-1.5 px-3 text-slate-400">Optional</td>
                    <td className="py-1.5 px-3">VIP Customer</td>
                  </tr>
                  <tr>
                    <td className="py-1.5 px-3 font-mono text-slate-200">City</td>
                    <td className="py-1.5 px-3 text-slate-400">Optional</td>
                    <td className="py-1.5 px-3">Trivandrum</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </div>

        {/* Right Column: Upload / Paste Area & Live Validation Table */}
        <div className="lg:col-span-7 bg-[#050b18] border border-slate-800 rounded-2xl p-5 shadow-lg space-y-4">
          {/* Mode Switcher */}
          <div className="flex items-center gap-2 border-b border-slate-800 pb-3">
            <button
              type="button"
              onClick={() => setImportMode('upload')}
              className={`px-3.5 py-1.5 text-xs font-semibold rounded-xl transition-colors cursor-pointer ${
                importMode === 'upload'
                  ? 'bg-blue-600 text-white font-bold shadow-md shadow-blue-900/30'
                  : 'text-slate-400 hover:text-white bg-black'
              }`}
            >
              Upload Spreadsheet File (.xlsx / .csv)
            </button>
            <button
              type="button"
              onClick={() => setImportMode('paste')}
              className={`px-3.5 py-1.5 text-xs font-semibold rounded-xl transition-colors cursor-pointer ${
                importMode === 'paste'
                  ? 'bg-blue-600 text-white font-bold shadow-md shadow-blue-900/30'
                  : 'text-slate-400 hover:text-white bg-black'
              }`}
            >
              Paste Table Text Directly
            </button>
          </div>

          {importMode === 'upload' ? (
            /* Dropzone */
            <div
              onClick={() => fileInputRef.current?.click()}
              className="border-2 border-dashed border-slate-700 hover:border-blue-500 rounded-2xl p-8 text-center cursor-pointer transition-colors bg-black/60 hover:bg-black"
            >
              <input
                ref={fileInputRef}
                type="file"
                accept=".xlsx,.xls,.csv"
                onChange={handleFileUpload}
                className="hidden"
              />
              <Upload className="w-10 h-10 text-blue-400 mx-auto mb-2" />
              <p className="text-sm font-semibold text-white">
                {file ? file.name : 'Click to select Excel (.xlsx) or CSV file from your computer'}
              </p>
              <p className="text-xs text-slate-400 mt-1">
                Drag and drop files here to parse customer records
              </p>
            </div>
          ) : (
            /* Paste Box */
            <div className="space-y-2">
              <textarea
                rows={5}
                value={pasteData}
                onChange={(e) => setPasteData(e.target.value)}
                placeholder="Paste rows copied from Excel or CSV here (with Name, Phone, Email columns)..."
                className="w-full text-xs font-mono p-3 bg-black border border-slate-700 rounded-xl text-white placeholder:text-slate-600 focus:outline-none focus:ring-1 focus:ring-blue-500"
              />
              <button
                type="button"
                onClick={handleProcessPasted}
                className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-blue-300 text-xs font-semibold rounded-xl border border-slate-700 cursor-pointer"
              >
                Parse Pasted Table
              </button>
            </div>
          )}

          {errorNotice && (
            <div className="p-3 bg-red-950/80 border border-red-800 rounded-xl text-xs text-red-200 flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-red-400 shrink-0" />
              <span>{errorNotice}</span>
            </div>
          )}

          {/* Parsed Preview Table */}
          {parsedRows.length > 0 && (
            <div className="space-y-3 pt-2">
              <div className="flex flex-wrap items-center justify-between text-xs border-b border-slate-800 pb-2 gap-2">
                <span className="font-bold text-white">Parsed Preview ({parsedRows.length} total rows)</span>
                <div className="flex flex-wrap items-center gap-2">
                  <span className="text-emerald-400 font-semibold">{validCount} valid</span>
                  {dbDuplicatesCount > 0 && (
                    <span className="text-amber-400 font-semibold bg-amber-950/60 px-2 py-0.5 rounded border border-amber-800">
                      {dbDuplicatesCount} already in DB
                    </span>
                  )}
                  {fileDuplicatesCount > 0 && (
                    <span className="text-blue-300 font-semibold bg-blue-950/60 px-2 py-0.5 rounded border border-blue-800">
                      {fileDuplicatesCount} in file
                    </span>
                  )}
                  {invalidCount > 0 && (
                    <span className="text-rose-400 font-semibold">{invalidCount} invalid</span>
                  )}
                </div>
              </div>

              <div className="border border-slate-800 rounded-xl overflow-x-auto max-h-64 bg-black">
                <table className="w-full text-left text-xs">
                  <thead>
                    <tr className="bg-black border-b border-slate-800 text-slate-400">
                      <th className="py-2.5 px-3">Validation & Dup Check</th>
                      <th className="py-2.5 px-3">Name</th>
                      <th className="py-2.5 px-3">Phone</th>
                      <th className="py-2.5 px-3">Category</th>
                      <th className="py-2.5 px-3">City</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/60">
                    {parsedRows.slice(0, 15).map((row, idx) => (
                      <tr key={idx} className={row.isValid ? 'hover:bg-slate-800/30' : 'bg-red-950/20'}>
                        <td className="py-2 px-3">
                          {row.duplicateType === 'database' ? (
                            <span className="inline-flex items-center gap-1 text-[10px] text-amber-300 font-semibold px-2 py-0.5 rounded bg-amber-950 border border-amber-800" title={row.duplicateMatchName}>
                              <AlertTriangle className="w-3 h-3" />
                              <span>In Database</span>
                            </span>
                          ) : row.duplicateType === 'file' ? (
                            <span className="inline-flex items-center gap-1 text-[10px] text-blue-300 font-semibold px-2 py-0.5 rounded bg-blue-950 border border-blue-800" title="Repeated row in uploaded file">
                              <CopyCheck className="w-3 h-3" />
                              <span>File Dup</span>
                            </span>
                          ) : row.isValid ? (
                            <span className="inline-flex items-center gap-1 text-[10px] text-emerald-400 font-semibold">
                              <CheckCircle2 className="w-3 h-3" /> Fresh Record
                            </span>
                          ) : (
                            <span className="inline-flex items-center gap-1 text-[10px] text-rose-400 font-semibold" title={row.validationError}>
                              <AlertCircle className="w-3 h-3" /> {row.validationError || 'Invalid'}
                            </span>
                          )}
                        </td>
                        <td className="py-2 px-3 font-medium text-white">{row.name || '-'}</td>
                        <td className="py-2 px-3 text-slate-200 font-mono">{row.phone || '-'}</td>
                        <td className="py-2 px-3 text-blue-400">{row.category || '-'}</td>
                        <td className="py-2 px-3 text-slate-400">{row.city || '-'}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              {parsedRows.length > 15 && (
                <p className="text-[11px] text-slate-500 text-center">
                  Showing first 15 of {parsedRows.length} rows parsed from file
                </p>
              )}

              {/* Import Confirmation Action */}
              <div className="pt-2 flex items-center justify-between">
                <button
                  type="button"
                  onClick={() => {
                    setParsedRows([]);
                    setFile(null);
                    setPasteData('');
                  }}
                  className="text-xs text-slate-400 hover:text-white cursor-pointer"
                >
                  Clear Preview
                </button>

                <button
                  type="button"
                  disabled={validCount === 0 || isSubmitting || isProcessing}
                  onClick={handleConfirmImport}
                  className="flex items-center gap-2 py-2.5 px-6 bg-blue-600 hover:bg-blue-500 disabled:opacity-40 text-white font-bold text-xs rounded-xl shadow-lg shadow-blue-900/30 transition-all cursor-pointer active:scale-98"
                >
                  <span>
                    {isSubmitting
                      ? 'Importing...'
                      : `Confirm Import (${validCount} records • Strategy: ${deduplicateStrategy})`}
                  </span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
