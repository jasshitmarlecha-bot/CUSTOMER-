import React, { useState, useMemo } from 'react';
import {
  Users,
  Search,
  Plus,
  Trash2,
  Edit2,
  Mail,
  Phone,
  Tag,
  MapPin,
  Calendar,
  Filter,
  RefreshCw,
  QrCode,
  Download,
  Upload,
  Printer,
  ChevronDown,
  X,
  FileSpreadsheet,
  FileText,
  User,
  SlidersHorizontal,
  ArrowUpDown
} from 'lucide-react';
import * as XLSX from 'xlsx';
import { Customer, Category, StaffUser } from '../../types/index.ts';
import { CustomerImportModal } from './CustomerImportModal.tsx';
import { CustomerPrintModal } from './CustomerPrintModal.tsx';
import { ConfirmationModal } from '../common/ConfirmationModal.tsx';
import { PermissionModal } from '../common/PermissionModal.tsx';

interface CustomerListViewProps {
  customers: Customer[];
  categories: Category[];
  currentUser: StaffUser;
  onAddCustomer: () => void;
  onEditCustomer: (customer: Customer) => void;
  onDeleteCustomer: (id: string) => Promise<void>;
  onClearAllCustomers: () => Promise<void>;
  onNavigateToQR: () => void;
  onImportCustomers: (customers: any[]) => Promise<{ importedCount: number; errors: string[] }>;
  onNavigateToImport?: () => void;
  businessName?: string;
}

export const CustomerListView: React.FC<CustomerListViewProps> = ({
  customers,
  categories,
  currentUser,
  onAddCustomer,
  onEditCustomer,
  onDeleteCustomer,
  onClearAllCustomers,
  onNavigateToQR,
  onImportCustomers,
  onNavigateToImport,
  businessName = 'Giri Jewels'
}) => {
  // Filters & Search state
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [selectedStatus, setSelectedStatus] = useState('all');
  const [selectedSource, setSelectedSource] = useState('all');
  const [selectedCity, setSelectedCity] = useState('all');
  const [sortBy, setSortBy] = useState<'newest' | 'oldest' | 'name_asc' | 'name_desc'>('newest');
  const [isDeletingId, setIsDeletingId] = useState<string | null>(null);

  // Modals state
  const [isPrintModalOpen, setIsPrintModalOpen] = useState(false);
  const [isImportModalOpen, setIsImportModalOpen] = useState(false);
  const [isExportDropdownOpen, setIsExportDropdownOpen] = useState(false);

  // Reusable Confirmation & Permission Dialogues
  const [confirmModal, setConfirmModal] = useState<{
    isOpen: boolean;
    title: string;
    description: string;
    confirmText?: string;
    variant?: 'danger' | 'warning' | 'primary';
    itemDetails?: Array<{ label: string; value: string }>;
    onConfirm: () => Promise<void> | void;
  }>({
    isOpen: false,
    title: '',
    description: '',
    onConfirm: () => {}
  });

  const [permissionModal, setPermissionModal] = useState<{
    isOpen: boolean;
    actionTitle: string;
    actionDescription?: string;
    onAuthorizeOverride?: () => void;
  }>({
    isOpen: false,
    actionTitle: ''
  });

  const permissions = currentUser.permissions || {
    canViewCustomers: true,
    canAddEditCustomers: currentUser.role === 'admin',
    canDeleteCustomers: currentUser.role === 'admin',
    canExportData: true,
    canImportData: currentUser.role === 'admin',
    canPrintData: true,
    canManageCategories: currentUser.role === 'admin',
    canRunCleaning: currentUser.role === 'admin',
    canViewAnalytics: true,
    canViewCommonQR: true
  };

  // Distinct cities extracted for dynamic location filter
  const uniqueCities = useMemo(() => {
    const set = new Set<string>();
    customers.forEach(c => {
      if (c.city && c.city.trim()) set.add(c.city.trim());
    });
    return Array.from(set).sort();
  }, [customers]);

  // Real-time comprehensive filtering & search logic
  const filteredCustomers = useMemo(() => {
    const query = searchQuery.trim().toLowerCase();

    const filtered = customers.filter((customer) => {
      const matchesSearch =
        !query ||
        (customer.name && customer.name.toLowerCase().includes(query)) ||
        (customer.email && customer.email.toLowerCase().includes(query)) ||
        (customer.phone && customer.phone.includes(query)) ||
        (customer.city && customer.city.toLowerCase().includes(query)) ||
        (customer.address && customer.address.toLowerCase().includes(query)) ||
        (customer.categoryName && customer.categoryName.toLowerCase().includes(query)) ||
        (customer.notes && customer.notes.toLowerCase().includes(query));

      const matchesCategory =
        selectedCategory === 'all' || customer.categoryId === selectedCategory;

      const matchesStatus =
        selectedStatus === 'all' || customer.status === selectedStatus;

      const matchesSource =
        selectedSource === 'all' || customer.source === selectedSource;

      const matchesCity =
        selectedCity === 'all' || (customer.city && customer.city.trim().toLowerCase() === selectedCity.toLowerCase());

      return matchesSearch && matchesCategory && matchesStatus && matchesSource && matchesCity;
    });

    // Sorting
    return filtered.sort((a, b) => {
      if (sortBy === 'oldest') {
        return new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime();
      }
      if (sortBy === 'name_asc') {
        return (a.name || '').localeCompare(b.name || '');
      }
      if (sortBy === 'name_desc') {
        return (b.name || '').localeCompare(a.name || '');
      }
      // default: newest
      return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
    });
  }, [customers, searchQuery, selectedCategory, selectedStatus, selectedSource, selectedCity, sortBy]);

  const hasActiveFilters =
    searchQuery.trim() !== '' ||
    selectedCategory !== 'all' ||
    selectedStatus !== 'all' ||
    selectedSource !== 'all' ||
    selectedCity !== 'all';

  const resetFilters = () => {
    setSearchQuery('');
    setSelectedCategory('all');
    setSelectedStatus('all');
    setSelectedSource('all');
    setSelectedCity('all');
    setSortBy('newest');
  };

  const selectedCategoryObj = categories.find(c => c.id === selectedCategory);

  const handleDelete = (id: string, name: string, phone: string = '') => {
    if (!permissions.canDeleteCustomers) {
      setPermissionModal({
        isOpen: true,
        actionTitle: 'Delete Customer Record',
        actionDescription: 'Administrator credentials are required to delete customer profiles from the showroom roster.',
        onAuthorizeOverride: () => {
          promptDeleteConfirmation(id, name, phone);
        }
      });
      return;
    }
    promptDeleteConfirmation(id, name, phone);
  };

  const promptDeleteConfirmation = (id: string, name: string, phone: string = '') => {
    setConfirmModal({
      isOpen: true,
      title: 'Delete Customer Record?',
      description: `Are you sure you want to permanently delete "${name}"? Their contact details, jewelry purchase notes, and records will be removed.`,
      confirmText: 'Delete Customer',
      variant: 'danger',
      itemDetails: [
        { label: 'Customer Name', value: name },
        ...(phone ? [{ label: 'Mobile Number', value: phone }] : [])
      ],
      onConfirm: async () => {
        setIsDeletingId(id);
        try {
          await onDeleteCustomer(id);
        } finally {
          setIsDeletingId(null);
        }
      }
    });
  };

  const handleClearAll = () => {
    if (!permissions.canDeleteCustomers) {
      setPermissionModal({
        isOpen: true,
        actionTitle: 'Wipe Entire Customer Database',
        actionDescription: 'Administrator credentials are required to clear customer records.',
        onAuthorizeOverride: () => {
          promptClearAllConfirmation();
        }
      });
      return;
    }
    promptClearAllConfirmation();
  };

  const promptClearAllConfirmation = () => {
    setConfirmModal({
      isOpen: true,
      title: 'Wipe All Customer Records?',
      description: 'WARNING: This will permanently delete ALL customer records currently in the Giri Jewels database. This operation CANNOT be undone!',
      confirmText: 'Yes, Wipe Database',
      variant: 'danger',
      itemDetails: [
        { label: 'Total Records to Delete', value: String(customers.length) },
        { label: 'Target Store', value: businessName || 'Giri Jewels' }
      ],
      onConfirm: async () => {
        await onClearAllCustomers();
      }
    });
  };

  // Export to Excel (.xlsx) using SheetJS
  const handleExportExcel = () => {
    if (filteredCustomers.length === 0) return;
    setIsExportDropdownOpen(false);

    const dataToExport = filteredCustomers.map((c, index) => ({
      'S.No': index + 1,
      'Customer Name': c.name || '',
      'Mobile Phone': c.phone || '',
      'Email Address': c.email || '',
      'Category': c.categoryName || 'General',
      'City / Area': c.city || c.address || '',
      'Status': c.status,
      'Source': c.source === 'walkin_qr' ? 'Common QR' : c.source === 'import' ? 'Imported' : 'Manual Entry',
      'Registered Date': new Date(c.createdAt).toLocaleDateString('en-IN')
    }));

    const worksheet = XLSX.utils.json_to_sheet(dataToExport);

    // Auto-fit column widths
    const colWidths = [
      { wch: 6 },
      { wch: 22 },
      { wch: 15 },
      { wch: 26 },
      { wch: 16 },
      { wch: 20 },
      { wch: 10 },
      { wch: 14 },
      { wch: 15 }
    ];
    worksheet['!cols'] = colWidths;

    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, 'Customers');
    XLSX.writeFile(workbook, `giri_jewels_customers_${new Date().toISOString().slice(0, 10)}.xlsx`);
  };

  // Export to CSV
  const handleExportCSV = () => {
    if (filteredCustomers.length === 0) return;
    setIsExportDropdownOpen(false);

    const headers = ['Name', 'Phone', 'Email', 'Category', 'Address/City', 'Status', 'Source', 'Registered Date'];
    const rows = filteredCustomers.map(c => [
      `"${(c.name || '').replace(/"/g, '""')}"`,
      `"${(c.phone || '').replace(/"/g, '""')}"`,
      `"${(c.email || '').replace(/"/g, '""')}"`,
      `"${(c.categoryName || 'General').replace(/"/g, '""')}"`,
      `"${(c.city || c.address || '').replace(/"/g, '""')}"`,
      `"${c.status}"`,
      `"${c.source === 'walkin_qr' ? 'Common QR' : c.source === 'import' ? 'Imported' : 'Manual Entry'}"`,
      `"${new Date(c.createdAt).toLocaleDateString('en-IN')}"`
    ]);

    const csvContent = [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `giri_jewels_customers_${new Date().toISOString().slice(0, 10)}.csv`;
    link.click();
    URL.revokeObjectURL(url);
  };

  // Export to PDF / Printable view
  const handleExportPDF = () => {
    setIsExportDropdownOpen(false);
    setIsPrintModalOpen(true);
  };

  return (
    <div className="space-y-4 font-sans">
      {/* Page Title & Top Toolbar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-xl font-bold text-white tracking-tight flex items-center gap-2">
            <span>Customer Directory</span>
            <span className="text-xs px-2.5 py-0.5 rounded-full bg-blue-950 text-blue-300 border border-blue-800 font-semibold">
              {customers.length} total
            </span>
          </h1>
          <p className="text-xs text-slate-400">
            Showroom client profiles, walk-in leads, and QR registrations with full real-time filtering & search.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {/* Print Customer Data Button */}
          {permissions.canPrintData && customers.length > 0 && (
            <button
              onClick={() => setIsPrintModalOpen(true)}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-white bg-slate-900 hover:bg-slate-800 border border-slate-700 rounded-lg shadow-xs transition-colors cursor-pointer"
              title="Print Customer Data"
            >
              <Printer className="w-3.5 h-3.5 text-blue-400" />
              <span>Print Data</span>
            </button>
          )}

          {/* Export Dropdown (Excel & PDF) */}
          {permissions.canExportData && customers.length > 0 && (
            <div className="relative">
              <button
                onClick={() => setIsExportDropdownOpen(!isExportDropdownOpen)}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-white bg-slate-900 hover:bg-slate-800 border border-slate-700 rounded-lg shadow-xs transition-colors cursor-pointer"
                title="Export customer records"
              >
                <Download className="w-3.5 h-3.5 text-blue-400" />
                <span>Export</span>
                <ChevronDown className="w-3 h-3 text-slate-400" />
              </button>

              {isExportDropdownOpen && (
                <div className="absolute right-0 mt-1 w-44 bg-slate-900 border border-slate-700 rounded-xl shadow-xl z-20 py-1 text-xs">
                  <button
                    onClick={handleExportExcel}
                    className="w-full flex items-center gap-2 px-3 py-2 text-left text-slate-200 hover:bg-slate-800 hover:text-white transition-colors cursor-pointer"
                  >
                    <FileSpreadsheet className="w-3.5 h-3.5 text-blue-400" />
                    <span>Export to Excel (.xlsx)</span>
                  </button>
                  <button
                    onClick={handleExportPDF}
                    className="w-full flex items-center gap-2 px-3 py-2 text-left text-slate-200 hover:bg-slate-800 hover:text-white transition-colors cursor-pointer"
                  >
                    <Printer className="w-3.5 h-3.5 text-slate-300" />
                    <span>Export to PDF Document</span>
                  </button>
                  <button
                    onClick={handleExportCSV}
                    className="w-full flex items-center gap-2 px-3 py-2 text-left text-slate-200 hover:bg-slate-800 hover:text-white transition-colors cursor-pointer"
                  >
                    <FileText className="w-3.5 h-3.5 text-blue-400" />
                    <span>Export to CSV (.csv)</span>
                  </button>
                </div>
              )}
            </div>
          )}

          {/* Import Customers Button (links to operation) */}
          {permissions.canImportData && (
            <button
              onClick={() => {
                if (onNavigateToImport) {
                  onNavigateToImport();
                } else {
                  setIsImportModalOpen(true);
                }
              }}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-white bg-slate-900 hover:bg-slate-800 border border-slate-700 rounded-lg shadow-xs transition-colors cursor-pointer"
              title="Import outside customer data from Excel or CSV"
            >
              <Upload className="w-3.5 h-3.5 text-blue-400" />
              <span>Import Data</span>
            </button>
          )}

          {/* Add Customer */}
          {permissions.canAddEditCustomers && (
            <button
              onClick={onAddCustomer}
              className="inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-bold text-white bg-blue-600 hover:bg-blue-500 active:scale-95 rounded-lg shadow-md shadow-blue-900/30 transition-all cursor-pointer border border-blue-400/30"
            >
              <Plus className="w-4 h-4" />
              <span>+ Add Customer</span>
            </button>
          )}
        </div>
      </div>

      {/* ========================================================================= */}
      {/* FILTER SEARCH PANEL (Search Input + Multi-Dropdowns + Filter Chips)       */}
      {/* ========================================================================= */}
      <div className="bg-[#050b18] p-4 sm:p-5 rounded-2xl border border-blue-900/40 shadow-xl space-y-3.5">
        <div className="flex flex-col lg:flex-row items-stretch lg:items-center gap-3">
          {/* Main Search Input */}
          <div className="relative flex-1">
            <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-500">
              <Search className="w-4 h-4 text-blue-400" />
            </div>
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search by customer name, phone number, email, or city / area..."
              className="w-full pl-10 pr-9 py-2 text-xs bg-black border border-slate-700 rounded-xl transition-colors focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500 text-white placeholder:text-slate-500 font-medium"
            />
            {searchQuery && (
              <button
                type="button"
                onClick={() => setSearchQuery('')}
                className="absolute inset-y-0 right-0 pr-3 flex items-center text-slate-400 hover:text-white cursor-pointer"
                title="Clear search query"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          {/* Filters Row */}
          <div className="flex flex-wrap sm:flex-nowrap items-center gap-2">
            {/* Category Filter */}
            <div className="flex items-center gap-1.5 bg-black border border-slate-700 rounded-xl px-2.5 py-1.5 text-xs">
              <Tag className="w-3.5 h-3.5 text-blue-400" />
              <select
                value={selectedCategory}
                onChange={(e) => setSelectedCategory(e.target.value)}
                className="bg-transparent text-slate-200 font-medium focus:outline-none cursor-pointer text-xs"
              >
                <option value="all" className="bg-slate-900 text-slate-200">
                  All Categories ({categories.length})
                </option>
                {categories.map((c) => (
                  <option key={c.id} value={c.id} className="bg-slate-900 text-slate-200">
                    {c.name}
                  </option>
                ))}
              </select>
            </div>

            {/* Status Filter */}
            <div className="flex items-center gap-1.5 bg-black border border-slate-700 rounded-xl px-2.5 py-1.5 text-xs">
              <select
                value={selectedStatus}
                onChange={(e) => setSelectedStatus(e.target.value)}
                className="bg-transparent text-slate-200 font-medium focus:outline-none cursor-pointer text-xs"
              >
                <option value="all" className="bg-slate-900 text-slate-200">All Statuses</option>
                <option value="active" className="bg-slate-900 text-slate-200">Active Only</option>
                <option value="lead" className="bg-slate-900 text-slate-200">Leads Only</option>
                <option value="inactive" className="bg-slate-900 text-slate-200">Inactive</option>
              </select>
            </div>

            {/* Source Filter */}
            <div className="flex items-center gap-1.5 bg-black border border-slate-700 rounded-xl px-2.5 py-1.5 text-xs">
              <select
                value={selectedSource}
                onChange={(e) => setSelectedSource(e.target.value)}
                className="bg-transparent text-slate-200 font-medium focus:outline-none cursor-pointer text-xs"
              >
                <option value="all" className="bg-slate-900 text-slate-200">All Sources</option>
                <option value="walkin_qr" className="bg-slate-900 text-slate-200">Common QR Scan</option>
                <option value="manual" className="bg-slate-900 text-slate-200">Staff Manual</option>
                <option value="import" className="bg-slate-900 text-slate-200">Bulk Imported</option>
              </select>
            </div>

            {/* City Filter (if cities exist) */}
            {uniqueCities.length > 0 && (
              <div className="flex items-center gap-1.5 bg-black border border-slate-700 rounded-xl px-2.5 py-1.5 text-xs">
                <MapPin className="w-3.5 h-3.5 text-blue-400" />
                <select
                  value={selectedCity}
                  onChange={(e) => setSelectedCity(e.target.value)}
                  className="bg-transparent text-slate-200 font-medium focus:outline-none cursor-pointer text-xs"
                >
                  <option value="all" className="bg-slate-900 text-slate-200">All Cities ({uniqueCities.length})</option>
                  {uniqueCities.map((city) => (
                    <option key={city} value={city} className="bg-slate-900 text-slate-200">
                      {city}
                    </option>
                  ))}
                </select>
              </div>
            )}

            {/* Sort Order Selector */}
            <div className="flex items-center gap-1.5 bg-black border border-slate-700 rounded-xl px-2.5 py-1.5 text-xs">
              <ArrowUpDown className="w-3.5 h-3.5 text-slate-400" />
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value as any)}
                className="bg-transparent text-slate-200 font-medium focus:outline-none cursor-pointer text-xs"
              >
                <option value="newest" className="bg-slate-900 text-slate-200">Newest First</option>
                <option value="oldest" className="bg-slate-900 text-slate-200">Oldest First</option>
                <option value="name_asc" className="bg-slate-900 text-slate-200">Name (A-Z)</option>
                <option value="name_desc" className="bg-slate-900 text-slate-200">Name (Z-A)</option>
              </select>
            </div>

            {/* Reset Filters */}
            {hasActiveFilters && (
              <button
                type="button"
                onClick={resetFilters}
                className="inline-flex items-center gap-1 px-3 py-1.5 text-xs text-blue-400 hover:text-blue-300 hover:bg-slate-900 rounded-xl transition-colors cursor-pointer border border-blue-900/50"
                title="Reset all filter & search fields"
              >
                <RefreshCw className="w-3 h-3" />
                <span>Reset</span>
              </button>
            )}
          </div>
        </div>

        {/* Active Filter Chips / Badges Row */}
        {hasActiveFilters && (
          <div className="flex flex-wrap items-center gap-2 pt-2 border-t border-slate-800/80">
            <span className="text-[11px] font-semibold text-slate-400 flex items-center gap-1">
              <Filter className="w-3 h-3 text-blue-400" />
              <span>Active Filter Search:</span>
            </span>

            {searchQuery.trim() && (
              <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-medium bg-blue-950 text-blue-300 border border-blue-800">
                <span>Keyword: "{searchQuery}"</span>
                <button
                  type="button"
                  onClick={() => setSearchQuery('')}
                  className="hover:text-white cursor-pointer"
                >
                  <X className="w-3 h-3" />
                </button>
              </span>
            )}

            {selectedCategory !== 'all' && (
              <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-medium bg-blue-950 text-blue-300 border border-blue-800">
                <span>Category: {selectedCategoryObj?.name || selectedCategory}</span>
                <button
                  type="button"
                  onClick={() => setSelectedCategory('all')}
                  className="hover:text-white cursor-pointer"
                >
                  <X className="w-3 h-3" />
                </button>
              </span>
            )}

            {selectedStatus !== 'all' && (
              <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-medium bg-blue-950 text-blue-300 border border-blue-800">
                <span>Status: {selectedStatus.toUpperCase()}</span>
                <button
                  type="button"
                  onClick={() => setSelectedStatus('all')}
                  className="hover:text-white cursor-pointer"
                >
                  <X className="w-3 h-3" />
                </button>
              </span>
            )}

            {selectedSource !== 'all' && (
              <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-medium bg-blue-950 text-blue-300 border border-blue-800">
                <span>Source: {selectedSource === 'walkin_qr' ? 'Common QR' : selectedSource === 'import' ? 'Imported' : 'Manual'}</span>
                <button
                  type="button"
                  onClick={() => setSelectedSource('all')}
                  className="hover:text-white cursor-pointer"
                >
                  <X className="w-3 h-3" />
                </button>
              </span>
            )}

            {selectedCity !== 'all' && (
              <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-medium bg-blue-950 text-blue-300 border border-blue-800">
                <span>City: {selectedCity}</span>
                <button
                  type="button"
                  onClick={() => setSelectedCity('all')}
                  className="hover:text-white cursor-pointer"
                >
                  <X className="w-3 h-3" />
                </button>
              </span>
            )}

            <button
              type="button"
              onClick={resetFilters}
              className="text-[11px] text-slate-400 hover:text-white underline cursor-pointer ml-1"
            >
              Clear all
            </button>
          </div>
        )}

        {/* Filter Summary Status */}
        <div className="flex items-center justify-between text-[11px] text-slate-400 pt-1 border-t border-slate-800/80">
          <div>
            Showing <strong className="text-white font-semibold">{filteredCustomers.length}</strong> of {customers.length} customer records
            {hasActiveFilters && (
              <span className="text-blue-400 ml-1.5">
                ({customers.length - filteredCustomers.length} filtered out)
              </span>
            )}
          </div>
          {customers.length > 0 && (
            <button
              type="button"
              onClick={handleClearAll}
              className="text-rose-400 hover:text-rose-300 hover:underline cursor-pointer"
            >
              Clear entire database
            </button>
          )}
        </div>
      </div>

      {/* ========================================================================= */}
      {/* CUSTOMER RECORDS TABLE                                                    */}
      {/* ========================================================================= */}
      <div className="bg-[#050b18] rounded-2xl border border-slate-800 shadow-md overflow-hidden">
        {filteredCustomers.length === 0 ? (
          <div className="p-10 text-center space-y-3">
            <div className="w-12 h-12 rounded-2xl bg-black border border-slate-800 flex items-center justify-center mx-auto text-slate-400">
              <User className="w-6 h-6 text-blue-400" />
            </div>
            <h3 className="text-sm font-bold text-white">
              {hasActiveFilters ? 'No customers match your filter search' : 'No customers in directory yet'}
            </h3>
            <p className="text-xs text-slate-400 max-w-sm mx-auto">
              {hasActiveFilters
                ? 'Try broadening your search term or clearing one of the active filters above.'
                : 'Customers who scan your Common Showroom QR code will automatically appear here, or you can add them manually or import from outside files.'}
            </p>
            <div className="pt-2 flex items-center justify-center gap-2">
              {hasActiveFilters ? (
                <button
                  onClick={resetFilters}
                  className="px-4 py-2 text-xs font-semibold bg-blue-600 hover:bg-blue-500 text-white rounded-xl shadow-md transition-colors cursor-pointer"
                >
                  Reset All Filters
                </button>
              ) : (
                <>
                  <button
                    onClick={onNavigateToQR}
                    className="inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-bold bg-blue-600 hover:bg-blue-500 text-white rounded-xl shadow-sm transition-all cursor-pointer"
                  >
                    <QrCode className="w-3.5 h-3.5" />
                    <span>View Common QR</span>
                  </button>
                  {permissions.canAddEditCustomers && (
                    <button
                      onClick={onAddCustomer}
                      className="inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold bg-slate-900 hover:bg-slate-800 text-slate-200 rounded-xl border border-slate-700 transition-colors cursor-pointer"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      <span>Add Customer</span>
                    </button>
                  )}
                </>
              )}
            </div>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-black text-slate-400 font-semibold border-b border-slate-800">
                <tr>
                  <th className="py-3 px-4 font-semibold">Customer Details</th>
                  <th className="py-3 px-4 font-semibold">Contact Info</th>
                  <th className="py-3 px-4 font-semibold">Category</th>
                  <th className="py-3 px-4 font-semibold">Status</th>
                  <th className="py-3 px-4 font-semibold">Intake Channel</th>
                  <th className="py-3 px-4 font-semibold">Registered</th>
                  <th className="py-3 px-4 font-semibold text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {filteredCustomers.map((customer) => (
                  <tr
                    key={customer.id}
                    className="hover:bg-slate-800/40 transition-colors group"
                  >
                    {/* Customer Details */}
                    <td className="py-3 px-4">
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-full bg-slate-800 border border-slate-700 flex items-center justify-center text-blue-300 font-bold text-xs shrink-0">
                          {customer.name ? customer.name.charAt(0).toUpperCase() : 'C'}
                        </div>
                        <div>
                          <div className="font-semibold text-white group-hover:text-blue-400 transition-colors">
                            {customer.name}
                          </div>
                          {customer.city && (
                            <div className="text-[11px] text-slate-400 flex items-center gap-1 mt-0.5">
                              <MapPin className="w-3 h-3 text-slate-500" />
                              <span>{customer.city}</span>
                            </div>
                          )}
                        </div>
                      </div>
                    </td>

                    {/* Contact Info */}
                    <td className="py-3 px-4 space-y-0.5">
                      <div className="font-mono text-slate-200 flex items-center gap-1.5">
                        <Phone className="w-3 h-3 text-blue-400" />
                        <span>{customer.phone || 'No phone'}</span>
                      </div>
                      {customer.email ? (
                        <div className="text-[11px] text-slate-400 flex items-center gap-1.5">
                          <Mail className="w-3 h-3 text-slate-500" />
                          <span>{customer.email}</span>
                        </div>
                      ) : (
                        <span className="text-[10px] text-slate-600 italic">No email</span>
                      )}
                    </td>

                    {/* Category */}
                    <td className="py-3 px-4">
                      <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-[11px] font-medium bg-slate-800 text-slate-300 border border-slate-700">
                        {customer.categoryName || 'General Retail'}
                      </span>
                    </td>

                    {/* Status */}
                    <td className="py-3 px-4">
                      <span
                        className={`inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-semibold ${
                          customer.status === 'active'
                            ? 'bg-blue-950 text-blue-300 border border-blue-700'
                            : customer.status === 'lead'
                            ? 'bg-slate-800 text-white border border-slate-600'
                            : 'bg-slate-900 text-slate-400 border border-slate-800'
                        }`}
                      >
                        {customer.status}
                      </span>
                    </td>

                    {/* Source */}
                    <td className="py-3 px-4">
                      {customer.source === 'walkin_qr' ? (
                        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-semibold bg-blue-950 text-blue-300 border border-blue-800">
                          <QrCode className="w-3 h-3" />
                          <span>Common QR</span>
                        </span>
                      ) : customer.source === 'import' ? (
                        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-semibold bg-purple-950 text-purple-300 border border-purple-800">
                          <Upload className="w-3 h-3" />
                          <span>Imported</span>
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-medium bg-slate-800 text-slate-400 border border-slate-700">
                          <span>Manual</span>
                        </span>
                      )}
                    </td>

                    {/* Registered Date */}
                    <td className="py-3 px-4 text-slate-400 text-[11px]">
                      {new Date(customer.createdAt).toLocaleDateString('en-IN', {
                        day: 'numeric',
                        month: 'short',
                        year: 'numeric'
                      })}
                    </td>

                    {/* Actions */}
                    <td className="py-3 px-4 text-right">
                      <div className="flex items-center justify-end gap-1.5">
                        {permissions.canAddEditCustomers && (
                          <button
                            onClick={() => onEditCustomer(customer)}
                            className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition-colors cursor-pointer"
                            title="Edit customer details"
                          >
                            <Edit2 className="w-3.5 h-3.5" />
                          </button>
                        )}
                        <button
                          onClick={() => handleDelete(customer.id, customer.name, customer.phone)}
                          disabled={isDeletingId === customer.id}
                          className="p-1.5 text-rose-400 hover:text-rose-300 hover:bg-rose-950/40 rounded-lg transition-colors cursor-pointer disabled:opacity-50"
                          title="Delete customer record"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Customer Import Modal */}
      <CustomerImportModal
        isOpen={isImportModalOpen}
        onClose={() => setIsImportModalOpen(false)}
        onImportComplete={onImportCustomers}
      />

      {/* Customer Print Modal */}
      <CustomerPrintModal
        isOpen={isPrintModalOpen}
        onClose={() => setIsPrintModalOpen(false)}
        customers={filteredCustomers}
        businessName={businessName}
        filterSummary={
          hasActiveFilters
            ? `${selectedCategory !== 'all' ? `Category: ${selectedCategory}, ` : ''}${selectedStatus !== 'all' ? `Status: ${selectedStatus}, ` : ''}${selectedSource !== 'all' ? `Source: ${selectedSource}, ` : ''}${selectedCity !== 'all' ? `City: ${selectedCity}` : ''}`
            : undefined
        }
      />

      {/* Reusable Showroom Confirmation Dialogue */}
      <ConfirmationModal
        isOpen={confirmModal.isOpen}
        onClose={() => setConfirmModal(prev => ({ ...prev, isOpen: false }))}
        onConfirm={confirmModal.onConfirm}
        title={confirmModal.title}
        description={confirmModal.description}
        confirmText={confirmModal.confirmText}
        variant={confirmModal.variant}
        itemDetails={confirmModal.itemDetails}
      />

      {/* Role-Based Permission & Admin PIN Dialogue */}
      <PermissionModal
        isOpen={permissionModal.isOpen}
        onClose={() => setPermissionModal(prev => ({ ...prev, isOpen: false }))}
        actionTitle={permissionModal.actionTitle}
        actionDescription={permissionModal.actionDescription}
        currentUser={currentUser}
        onAuthorizeOverride={permissionModal.onAuthorizeOverride}
      />
    </div>
  );
};
