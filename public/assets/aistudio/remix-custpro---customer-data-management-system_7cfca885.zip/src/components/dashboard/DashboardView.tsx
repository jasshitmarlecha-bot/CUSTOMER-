import React, { useState, useEffect, useMemo, useRef } from 'react';
import {
  Users,
  QrCode,
  TrendingUp,
  Plus,
  Search,
  ArrowRight,
  ShieldCheck,
  Smartphone,
  Gem,
  BarChart3,
  Sparkles,
  Phone,
  Mail,
  MapPin,
  Clock,
  Printer,
  Upload,
  MessageSquare,
  ExternalLink,
  Download,
  Filter,
  CheckCircle2,
  Calendar,
  Layers,
  ChevronRight,
  Maximize2,
  X,
  RefreshCw,
  Tag
} from 'lucide-react';
import * as XLSX from 'xlsx';
import { Customer, Category, QRAnalyticsData, StaffUser, StoreSettings } from '../../types/index.ts';
import { getQRAnalytics, getQRStandeeInfo } from '../../api/client.ts';

interface DashboardViewProps {
  customers: Customer[];
  categories: Category[];
  currentUser: StaffUser;
  businessName?: string;
  storeSettings?: StoreSettings;
  onNavigateTab: (tab: string) => void;
  onOpenAddCustomer: () => void;
  onSelectCustomer: (customer: Customer) => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  customers,
  categories,
  currentUser,
  businessName = 'Giri Jewels',
  storeSettings,
  onNavigateTab,
  onOpenAddCustomer,
  onSelectCustomer
}) => {
  const [qrAnalytics, setQrAnalytics] = useState<QRAnalyticsData | null>(null);
  const [qrStandeeInfo, setQrStandeeInfo] = useState<{ qrDataUrl: string; targetUrl: string } | null>(null);
  const [quickSearch, setQuickSearch] = useState('');
  const [sourceFilter, setSourceFilter] = useState<'all' | 'today' | 'walkin_qr' | 'manual' | 'import'>('all');
  const [showFullscreenQR, setShowFullscreenQR] = useState(false);
  const searchInputRef = useRef<HTMLInputElement>(null);

  // Fetch QR standee info & analytics
  useEffect(() => {
    getQRAnalytics('all')
      .then((data) => setQrAnalytics(data))
      .catch((err) => console.warn('Dashboard QR analytics notice:', err));

    getQRStandeeInfo()
      .then((info) => setQrStandeeInfo(info))
      .catch((err) => console.warn('Dashboard QR standee notice:', err));
  }, []);

  // Keyboard shortcuts: [N] for new walkin, [/] for search, [Q] for QR suite, [I] for import
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Don't trigger if user is typing in an input
      if (['INPUT', 'TEXTAREA', 'SELECT'].includes((e.target as HTMLElement)?.tagName)) {
        return;
      }
      if (e.key === 'n' || e.key === 'N') {
        e.preventDefault();
        onOpenAddCustomer();
      } else if (e.key === '/') {
        e.preventDefault();
        searchInputRef.current?.focus();
      } else if (e.key === 'q' || e.key === 'Q') {
        e.preventDefault();
        onNavigateTab('qr_common');
      } else if (e.key === 'i' || e.key === 'I') {
        e.preventDefault();
        onNavigateTab('import');
      } else if (e.key === 'Escape' && showFullscreenQR) {
        setShowFullscreenQR(false);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [onOpenAddCustomer, onNavigateTab, showFullscreenQR]);

  // Metrics
  const totalCustomers = customers.length;
  const qrIntakeCount = customers.filter(c => c.source === 'walkin_qr').length;
  const manualIntakeCount = customers.filter(c => c.source === 'manual').length;
  const importIntakeCount = customers.filter(c => c.source === 'import').length;

  const totalScans = qrAnalytics?.totalScans || 0;
  const conversionRate = qrAnalytics?.scanToRegRate || (totalScans > 0 ? Math.round((qrIntakeCount / totalScans) * 100) : 0);

  // Today's customers
  const todayDateStr = new Date().toISOString().split('T')[0];
  const todayCustomers = customers.filter(c => {
    if (!c.createdAt) return false;
    return c.createdAt.startsWith(todayDateStr);
  });

  // Reachable phone count for WhatsApp/SMS
  const broadcastReadyCustomers = customers.filter(c => c.phone && c.phone.trim().length >= 7);

  // Filtered customers for the instant counter list
  const filteredCustomers = useMemo(() => {
    return customers.filter(c => {
      // Source filter
      if (sourceFilter === 'today') {
        if (!c.createdAt || !c.createdAt.startsWith(todayDateStr)) return false;
      } else if (sourceFilter !== 'all') {
        if (c.source !== sourceFilter) return false;
      }

      // Keyword search
      if (quickSearch.trim()) {
        const q = quickSearch.toLowerCase().trim();
        const matchesName = c.name?.toLowerCase().includes(q);
        const matchesPhone = c.phone?.includes(q);
        const matchesEmail = c.email?.toLowerCase().includes(q);
        const matchesCity = c.city?.toLowerCase().includes(q);
        const matchesCat = c.categoryName?.toLowerCase().includes(q);
        const matchesNotes = c.notes?.toLowerCase().includes(q);
        if (!matchesName && !matchesPhone && !matchesEmail && !matchesCity && !matchesCat && !matchesNotes) {
          return false;
        }
      }

      return true;
    });
  }, [customers, sourceFilter, quickSearch, todayDateStr]);

  // Jewelry category interest breakdown
  const categoryRanking = useMemo(() => {
    const counts: Record<string, number> = {};
    customers.forEach(c => {
      const cat = c.categoryName || 'General Jewellery';
      counts[cat] = (counts[cat] || 0) + 1;
    });
    return Object.entries(counts)
      .map(([name, count]) => ({
        name,
        count,
        percent: totalCustomers > 0 ? Math.round((count / totalCustomers) * 100) : 0
      }))
      .sort((a, b) => b.count - a.count)
      .slice(0, 5);
  }, [customers, totalCustomers]);

  // 1-Click WhatsApp Broadcast List Exporter
  const handleExportBroadcastList = () => {
    const rows = broadcastReadyCustomers.map((c, i) => {
      const cleanPhone = c.phone.replace(/[^0-9]/g, '');
      return {
        'S.No': i + 1,
        'Customer Name': c.name,
        'WhatsApp Mobile': cleanPhone,
        'Preferred Category': c.categoryName || 'General',
        'City': c.city || '-',
        'Registration Date': c.createdAt ? new Date(c.createdAt).toLocaleDateString() : '-',
        'Source': c.source === 'walkin_qr' ? 'Showroom QR' : c.source === 'import' ? 'Imported' : 'Counter Staff'
      };
    });

    const worksheet = XLSX.utils.json_to_sheet(rows);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, 'WhatsApp_Broadcast');
    XLSX.writeFile(workbook, `${businessName.replace(/\s+/g, '_')}_WhatsApp_List_${todayDateStr}.xlsx`);
  };

  // Helper for quick WhatsApp message
  const handleOpenWhatsAppChat = (customer: Customer, e: React.MouseEvent) => {
    e.stopPropagation();
    const cleanPhone = customer.phone.replace(/[^0-9]/g, '');
    const phoneWithCode = cleanPhone.length === 10 ? `91${cleanPhone}` : cleanPhone;
    const greetingText = encodeURIComponent(
      `Hello ${customer.name}! Greetings from ${businessName}. Thank you for visiting our showroom. Please let us know if you need assistance with your jewelry selections.`
    );
    window.open(`https://wa.me/${phoneWithCode}?text=${greetingText}`, '_blank');
  };

  return (
    <div className="space-y-6">
      {/* =========================================================================
          1. ULTRA LUXURY WELCOME & COMMAND STATION HEADER
      ========================================================================= */}
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-r from-blue-950 via-[#070e1f] to-black border border-blue-900/50 p-6 md:p-7 shadow-2xl">
        {/* Subtle decorative glow */}
        <div className="absolute top-0 right-0 w-96 h-96 bg-blue-600/10 rounded-full blur-3xl pointer-events-none -mr-20 -mt-20" />

        <div className="relative z-10 flex flex-col lg:flex-row lg:items-center justify-between gap-6">
          <div className="space-y-2">
            {/* Showroom Status Pill */}
            <div className="flex flex-wrap items-center gap-2.5">
              <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-blue-950/90 border border-blue-800 text-[11px] font-semibold text-blue-300">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                <span>Showroom Active</span>
              </span>
              <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-black/70 border border-slate-800 text-[11px] font-semibold text-slate-300">
                <Gem className="w-3 h-3 text-blue-400" />
                <span>Customer Counter Suite</span>
              </span>
              <span className="text-[11px] text-slate-400 font-medium hidden sm:inline">
                Signed in as <strong className="text-white">{currentUser.name}</strong> ({currentUser.role === 'admin' ? 'Store Admin' : 'Counter Staff'})
              </span>
            </div>

            {/* Title & Showroom Branding */}
            <h1 className="text-2xl sm:text-3xl font-black text-white tracking-tight flex items-center gap-2.5">
              <span>{businessName} Executive Suite</span>
              <span className="text-blue-400 text-xl font-normal">💎</span>
            </h1>

            <p className="text-xs sm:text-sm text-slate-300 max-w-2xl leading-relaxed">
              Executive counter management for <strong className="text-white">{businessName}</strong>. Walk-in customer intake, universal showroom QR portal, search & deduplication center, and WhatsApp messaging.
            </p>
          </div>

          {/* Primary Quick Launch Buttons */}
          <div className="flex flex-wrap items-center gap-2.5">
            <button
              onClick={() => onNavigateTab('import')}
              className="px-3.5 py-2.5 bg-black/80 hover:bg-slate-900 text-blue-300 hover:text-white text-xs font-bold rounded-xl border border-blue-800/80 shadow-md transition-all flex items-center gap-2 cursor-pointer active:scale-98"
              title="Bulk import outside customer records from Excel or CSV [Shortcut: I]"
            >
              <Upload className="w-4 h-4 text-blue-400" />
              <span>Import Data</span>
              <kbd className="hidden sm:inline px-1.5 py-0.5 text-[10px] bg-blue-950 border border-blue-800 rounded text-blue-300 font-mono">I</kbd>
            </button>

            <button
              onClick={() => setShowFullscreenQR(true)}
              className="px-3.5 py-2.5 bg-blue-950 hover:bg-blue-900 text-blue-200 hover:text-white text-xs font-bold rounded-xl border border-blue-700/80 shadow-md transition-all flex items-center gap-2 cursor-pointer active:scale-98"
              title="Show QR code fullscreen for customer on counter screen"
            >
              <QrCode className="w-4 h-4 text-blue-400" />
              <span>Counter QR</span>
              <kbd className="hidden sm:inline px-1.5 py-0.5 text-[10px] bg-blue-900 border border-blue-700 rounded text-blue-200 font-mono">Q</kbd>
            </button>

            <button
              onClick={onOpenAddCustomer}
              className="px-4 py-2.5 bg-white hover:bg-slate-100 text-slate-950 text-xs font-black rounded-xl shadow-xl transition-all flex items-center gap-2 cursor-pointer active:scale-98"
              title="Register a new walk-in customer [Shortcut: N]"
            >
              <Plus className="w-4 h-4 text-blue-600 stroke-[3]" />
              <span>+ Quick Walk-In Entry</span>
              <kbd className="hidden sm:inline px-1.5 py-0.5 text-[10px] bg-slate-200 border border-slate-300 rounded text-slate-900 font-mono">N</kbd>
            </button>
          </div>
        </div>
      </div>

      {/* =========================================================================
          DAILY JEWELLERY COUNTER RATES TICKER
      ========================================================================= */}
      {storeSettings?.showDailyRatesOnDashboard && (
        <div className="bg-[#050b18] border border-blue-900/40 rounded-2xl p-4 flex flex-wrap items-center justify-between gap-3 shadow-xl">
          <div className="flex items-center gap-2.5">
            <div className="w-2.5 h-2.5 rounded-full bg-blue-500 animate-ping" />
            <span className="text-xs font-black tracking-wider uppercase text-blue-300">
              Live Showroom Rates
            </span>
            <span className="text-[11px] text-slate-500 hidden sm:inline">•</span>
            <span className="text-[11px] text-slate-400 hidden sm:inline">Official Counter Reference</span>
          </div>

          <div className="flex flex-wrap items-center gap-2.5 sm:gap-3 text-xs">
            <div className="flex items-center gap-2 bg-black px-3.5 py-1.5 rounded-xl border border-slate-800 shadow-inner">
              <span className="text-[11px] font-bold text-slate-400">22K Gold:</span>
              <span className="text-white font-black font-mono tracking-tight">
                {storeSettings.currency || '₹'}{(storeSettings.rate22kGold || 6850).toLocaleString()}
                <span className="text-[10px] text-slate-500 font-normal"> /g</span>
              </span>
            </div>

            <div className="flex items-center gap-2 bg-black px-3.5 py-1.5 rounded-xl border border-slate-800 shadow-inner">
              <span className="text-[11px] font-bold text-slate-400">24K Gold:</span>
              <span className="text-white font-black font-mono tracking-tight">
                {storeSettings.currency || '₹'}{(storeSettings.rate24kGold || 7470).toLocaleString()}
                <span className="text-[10px] text-slate-500 font-normal"> /g</span>
              </span>
            </div>

            <div className="flex items-center gap-2 bg-black px-3.5 py-1.5 rounded-xl border border-slate-800 shadow-inner">
              <span className="text-[11px] font-bold text-slate-400">Fine Silver:</span>
              <span className="text-white font-black font-mono tracking-tight">
                {storeSettings.currency || '₹'}{(storeSettings.rateSilver || 98).toLocaleString()}
                <span className="text-[10px] text-slate-500 font-normal"> /g</span>
              </span>
            </div>

            <div className="hidden lg:flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-950/40 border border-emerald-800/60 text-emerald-400 text-[11px] font-semibold">
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>100% BIS Hallmarked HUID</span>
            </div>
          </div>
        </div>
      )}

      {/* =========================================================================
          2. SHOWROOM PULSE TILES (4 High-Clarity Vital Signs)
      ========================================================================= */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
        {/* Tile 1: Total Customers */}
        <div
          onClick={() => onNavigateTab('customers')}
          className="bg-[#050b18] hover:bg-[#07132c] border border-blue-900/40 hover:border-blue-500/60 rounded-2xl p-4 sm:p-5 shadow-lg transition-all cursor-pointer group flex flex-col justify-between"
        >
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">Total Customers</span>
            <div className="w-8 h-8 rounded-lg bg-blue-600/20 text-blue-400 flex items-center justify-center group-hover:bg-blue-600 group-hover:text-white transition-colors">
              <Users className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-2">
            <span className="text-2xl sm:text-3xl font-black text-white block tracking-tight">{totalCustomers}</span>
            <div className="text-[11px] text-blue-400 mt-1 flex items-center gap-1">
              <span>{qrIntakeCount} QR</span>
              <span className="text-slate-600">•</span>
              <span>{manualIntakeCount} Staff</span>
              <span className="text-slate-600">•</span>
              <span>{importIntakeCount} Import</span>
            </div>
          </div>
        </div>

        {/* Tile 2: Today's Walk-in Footfall */}
        <div className="bg-[#050b18] border border-blue-900/40 rounded-2xl p-4 sm:p-5 shadow-lg flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">Today's Walk-Ins</span>
            <div className="w-8 h-8 rounded-lg bg-emerald-950 text-emerald-400 border border-emerald-800 flex items-center justify-center">
              <Calendar className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-2">
            <span className="text-2xl sm:text-3xl font-black text-emerald-400 block tracking-tight">
              {todayCustomers.length}
            </span>
            <span className="text-[11px] text-slate-400 mt-1 block">
              Registered today ({todayDateStr})
            </span>
          </div>
        </div>

        {/* Tile 3: Showroom QR Scans */}
        <div
          onClick={() => onNavigateTab('qr_common')}
          className="bg-[#050b18] hover:bg-[#07132c] border border-blue-900/40 hover:border-blue-500/60 rounded-2xl p-4 sm:p-5 shadow-lg transition-all cursor-pointer group flex flex-col justify-between"
        >
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">Counter QR Scans</span>
            <div className="w-8 h-8 rounded-lg bg-blue-950 text-blue-400 border border-blue-800 flex items-center justify-center group-hover:bg-blue-600 group-hover:text-white transition-colors">
              <QrCode className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-2">
            <div className="flex items-baseline gap-2">
              <span className="text-2xl sm:text-3xl font-black text-white tracking-tight">{totalScans}</span>
              <span className="text-xs font-bold text-emerald-400 bg-emerald-950/80 px-2 py-0.5 rounded-full border border-emerald-800">
                {conversionRate}% Rate
              </span>
            </div>
            <span className="text-[11px] text-slate-400 mt-1 block">
              Phone camera hits at counter
            </span>
          </div>
        </div>

        {/* Tile 4: WhatsApp Broadcast Reach */}
        <div
          onClick={handleExportBroadcastList}
          className="bg-[#050b18] hover:bg-[#07132c] border border-blue-900/40 hover:border-emerald-500/60 rounded-2xl p-4 sm:p-5 shadow-lg transition-all cursor-pointer group flex flex-col justify-between"
          title="Click to export WhatsApp broadcast Excel sheet"
        >
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">Broadcast Reach</span>
            <div className="w-8 h-8 rounded-lg bg-emerald-950 text-emerald-400 border border-emerald-800 flex items-center justify-center group-hover:bg-emerald-600 group-hover:text-white transition-colors">
              <MessageSquare className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-2">
            <span className="text-2xl sm:text-3xl font-black text-white block tracking-tight">
              {broadcastReadyCustomers.length}
            </span>
            <div className="text-[11px] text-emerald-400 mt-1 flex items-center gap-1 group-hover:underline">
              <span>Export WhatsApp List (.xlsx)</span>
              <Download className="w-3 h-3" />
            </div>
          </div>
        </div>
      </div>

      {/* =========================================================================
          3. MAIN SPLIT WORKSPACE:
             - LEFT (2/3): Fast Counter Search & Recent Customer Desk
             - RIGHT (1/3): Showroom Quick Station (QR Standee + Category Pulse)
      ========================================================================= */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 items-start">
        {/* -----------------------------------------------------------------------
            LEFT: Instant Counter Register & Customer Action Desk (2 Columns Wide)
        ----------------------------------------------------------------------- */}
        <div className="lg:col-span-2 space-y-4">
          <div className="bg-[#050b18] rounded-2xl border border-slate-800 shadow-xl overflow-hidden">
            {/* Table / Search Header */}
            <div className="p-4 sm:p-5 border-b border-slate-800 bg-black/90 space-y-3">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div>
                  <h2 className="text-base font-black text-white tracking-tight flex items-center gap-2">
                    <span>Recent Walk-Ins & Active Customers</span>
                    <span className="text-xs px-2 py-0.5 rounded-full bg-blue-950 text-blue-300 border border-blue-800 font-mono">
                      {filteredCustomers.length}
                    </span>
                  </h2>
                  <p className="text-xs text-slate-400">
                    Direct 1-click WhatsApp messaging, phone calls, and instant customer edits.
                  </p>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => onNavigateTab('customers')}
                    className="px-3 py-1.5 text-xs font-bold text-blue-400 hover:text-white bg-blue-950/70 hover:bg-blue-900 rounded-xl border border-blue-800/80 transition-colors flex items-center gap-1 cursor-pointer"
                  >
                    <span>Full Directory</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>

              {/* Fast Universal Search Input */}
              <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2">
                <div className="relative flex-1">
                  <Search className="w-4 h-4 text-blue-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                  <input
                    ref={searchInputRef}
                    type="text"
                    value={quickSearch}
                    onChange={(e) => setQuickSearch(e.target.value)}
                    placeholder="Search customer by name, phone, city, or jewelry category... (Press / to focus)"
                    className="w-full pl-10 pr-9 py-2 text-xs bg-slate-900/90 border border-slate-700 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-blue-500/50 focus:border-blue-500 transition-all"
                  />
                  {quickSearch && (
                    <button
                      onClick={() => setQuickSearch('')}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white cursor-pointer"
                    >
                      <X className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>

                {/* Filter tabs: All, Today, QR, Manual, Import */}
                <div className="flex items-center gap-1 overflow-x-auto pb-1 sm:pb-0 scrollbar-none">
                  <button
                    onClick={() => setSourceFilter('all')}
                    className={`px-3 py-1.5 text-[11px] font-bold rounded-lg border transition-all cursor-pointer whitespace-nowrap ${
                      sourceFilter === 'all'
                        ? 'bg-blue-600 border-blue-500 text-white shadow-sm'
                        : 'bg-black/60 border-slate-800 text-slate-400 hover:text-white'
                    }`}
                  >
                    All ({customers.length})
                  </button>
                  <button
                    onClick={() => setSourceFilter('today')}
                    className={`px-3 py-1.5 text-[11px] font-bold rounded-lg border transition-all cursor-pointer whitespace-nowrap ${
                      sourceFilter === 'today'
                        ? 'bg-blue-600 border-blue-500 text-white shadow-sm'
                        : 'bg-black/60 border-slate-800 text-slate-400 hover:text-white'
                    }`}
                  >
                    Today ({todayCustomers.length})
                  </button>
                  <button
                    onClick={() => setSourceFilter('walkin_qr')}
                    className={`px-3 py-1.5 text-[11px] font-bold rounded-lg border transition-all cursor-pointer whitespace-nowrap flex items-center gap-1 ${
                      sourceFilter === 'walkin_qr'
                        ? 'bg-blue-600 border-blue-500 text-white shadow-sm'
                        : 'bg-black/60 border-slate-800 text-slate-400 hover:text-white'
                    }`}
                  >
                    <QrCode className="w-3 h-3" />
                    <span>QR ({qrIntakeCount})</span>
                  </button>
                  <button
                    onClick={() => setSourceFilter('import')}
                    className={`px-3 py-1.5 text-[11px] font-bold rounded-lg border transition-all cursor-pointer whitespace-nowrap ${
                      sourceFilter === 'import'
                        ? 'bg-blue-600 border-blue-500 text-white shadow-sm'
                        : 'bg-black/60 border-slate-800 text-slate-400 hover:text-white'
                    }`}
                  >
                    Imported ({importIntakeCount})
                  </button>
                </div>
              </div>
            </div>

            {/* Customers List / Table */}
            {filteredCustomers.length > 0 ? (
              <div className="divide-y divide-slate-800/80 max-h-[540px] overflow-y-auto">
                {filteredCustomers.slice(0, 10).map((customer) => {
                  const cleanPhone = customer.phone ? customer.phone.replace(/[^0-9]/g, '') : '';
                  return (
                    <div
                      key={customer.id}
                      onClick={() => onSelectCustomer(customer)}
                      className="p-4 hover:bg-slate-900/60 transition-colors flex flex-col sm:flex-row sm:items-center justify-between gap-3 cursor-pointer group"
                    >
                      {/* Name & Contact Info */}
                      <div className="flex items-center gap-3 min-w-0">
                        <div className="w-10 h-10 rounded-xl bg-blue-950 border border-blue-800/80 text-blue-300 font-black text-sm flex items-center justify-center shrink-0 shadow-inner group-hover:scale-105 transition-transform">
                          {customer.name ? customer.name.charAt(0).toUpperCase() : 'C'}
                        </div>
                        <div className="min-w-0">
                          <div className="flex items-center gap-2">
                            <span className="text-sm font-bold text-white group-hover:text-blue-400 transition-colors truncate">
                              {customer.name}
                            </span>
                            {customer.source === 'walkin_qr' && (
                              <span className="inline-flex items-center gap-0.5 px-1.5 py-0.5 rounded text-[10px] font-semibold bg-blue-950 text-blue-300 border border-blue-800/80">
                                <QrCode className="w-2.5 h-2.5" />
                                <span>QR</span>
                              </span>
                            )}
                            {customer.source === 'import' && (
                              <span className="px-1.5 py-0.5 rounded text-[10px] font-semibold bg-purple-950 text-purple-300 border border-purple-800/80">
                                Import
                              </span>
                            )}
                          </div>

                          <div className="flex flex-wrap items-center gap-3 text-xs text-slate-400 mt-0.5">
                            <span className="font-mono text-slate-300 flex items-center gap-1">
                              <Phone className="w-3 h-3 text-blue-400" />
                              <span>{customer.phone || 'No Phone'}</span>
                            </span>
                            {customer.city && (
                              <span className="flex items-center gap-1 text-slate-400">
                                <MapPin className="w-3 h-3 text-slate-500" />
                                <span>{customer.city}</span>
                              </span>
                            )}
                            {customer.categoryName && (
                              <span className="px-2 py-0.5 rounded-full text-[10px] font-semibold bg-slate-900 text-slate-300 border border-slate-700">
                                {customer.categoryName}
                              </span>
                            )}
                          </div>
                        </div>
                      </div>

                      {/* Right Action Buttons: WhatsApp, Call, View */}
                      <div className="flex items-center gap-2 self-end sm:self-center shrink-0">
                        {cleanPhone && (
                          <button
                            onClick={(e) => handleOpenWhatsAppChat(customer, e)}
                            className="px-2.5 py-1.5 bg-emerald-950/80 hover:bg-emerald-900 text-emerald-300 hover:text-white rounded-lg border border-emerald-800 text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer shadow-sm active:scale-95"
                            title="Open WhatsApp chat with this customer"
                          >
                            <MessageSquare className="w-3.5 h-3.5 text-emerald-400" />
                            <span className="hidden sm:inline">WhatsApp</span>
                          </button>
                        )}

                        {cleanPhone && (
                          <a
                            href={`tel:${cleanPhone}`}
                            onClick={(e) => e.stopPropagation()}
                            className="p-1.5 bg-slate-900 hover:bg-slate-800 text-slate-300 hover:text-white rounded-lg border border-slate-700 text-xs transition-colors cursor-pointer"
                            title="Call customer"
                          >
                            <Phone className="w-3.5 h-3.5 text-blue-400" />
                          </a>
                        )}

                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            onSelectCustomer(customer);
                          }}
                          className="px-2.5 py-1.5 bg-blue-950 hover:bg-blue-900 text-blue-300 hover:text-white rounded-lg border border-blue-800 text-xs font-bold transition-colors cursor-pointer"
                        >
                          Details
                        </button>
                      </div>
                    </div>
                  );
                })}

                {filteredCustomers.length > 10 && (
                  <div className="p-3 text-center bg-black/60 border-t border-slate-800">
                    <button
                      onClick={() => onNavigateTab('customers')}
                      className="text-xs font-bold text-blue-400 hover:underline cursor-pointer"
                    >
                      + View all {filteredCustomers.length} customers in Full Directory →
                    </button>
                  </div>
                )}
              </div>
            ) : (
              <div className="p-10 text-center space-y-3">
                <div className="w-12 h-12 rounded-2xl bg-blue-950/60 border border-blue-800/80 text-blue-400 flex items-center justify-center mx-auto">
                  <Search className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-white">No Matching Customers Found</h3>
                  <p className="text-xs text-slate-400 max-w-sm mx-auto mt-1">
                    {quickSearch
                      ? `No customer in the system matches "${quickSearch}". Check phone spelling or add them as a new customer.`
                      : 'No customer records under this view.'}
                  </p>
                </div>
                <button
                  onClick={onOpenAddCustomer}
                  className="px-4 py-2 bg-white text-slate-950 text-xs font-bold rounded-xl shadow-lg hover:bg-slate-100 transition-colors cursor-pointer"
                >
                  + Add Customer Now
                </button>
              </div>
            )}
          </div>
        </div>

        {/* -----------------------------------------------------------------------
            RIGHT: Fast Showroom Tools Station (1 Column Wide)
        ----------------------------------------------------------------------- */}
        <div className="space-y-4">
          {/* Card 1: Interactive Showroom QR Standee Display */}
          <div className="bg-[#050b18] rounded-2xl border border-blue-900/50 p-5 shadow-xl space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-7 h-7 rounded-lg bg-blue-600/20 text-blue-400 flex items-center justify-center border border-blue-500/30">
                  <QrCode className="w-4 h-4" />
                </div>
                <h3 className="text-sm font-black text-white tracking-tight">Counter QR Standee</h3>
              </div>
              <button
                onClick={() => setShowFullscreenQR(true)}
                className="text-xs text-blue-400 hover:text-blue-300 font-bold flex items-center gap-1 cursor-pointer"
                title="Expand QR full screen"
              >
                <Maximize2 className="w-3.5 h-3.5" />
                <span>Fullscreen</span>
              </button>
            </div>

            {/* Visual Miniature Standee Preview */}
            <div
              onClick={() => setShowFullscreenQR(true)}
              className="p-4 bg-gradient-to-b from-black to-slate-950 rounded-xl border border-blue-900/40 text-center cursor-pointer hover:border-blue-500/60 transition-all group shadow-inner"
            >
              <div className="text-[10px] font-black uppercase tracking-widest text-blue-400 mb-1">
                {businessName}
              </div>
              <div className="text-xs font-bold text-white mb-2.5">
                Scan with Phone Camera
              </div>

              {qrStandeeInfo?.qrDataUrl ? (
                <div className="inline-block p-2 bg-white rounded-xl shadow-md group-hover:scale-105 transition-transform">
                  <img
                    src={qrStandeeInfo.qrDataUrl}
                    alt="Showroom QR Code"
                    className="w-32 h-32 object-contain"
                  />
                </div>
              ) : (
                <div className="w-32 h-32 mx-auto bg-slate-900 rounded-xl border border-slate-700 flex items-center justify-center text-slate-400">
                  <RefreshCw className="w-5 h-5 animate-spin text-blue-400" />
                </div>
              )}

              <p className="text-[10px] text-slate-400 mt-2">
                Click to open fullscreen for walk-in customer on monitor
              </p>
            </div>

            {/* Actions for QR */}
            <div className="grid grid-cols-2 gap-2">
              <button
                onClick={() => onNavigateTab('qr_common')}
                className="py-2 px-3 bg-blue-950 hover:bg-blue-900 text-blue-300 hover:text-white rounded-xl border border-blue-800 text-xs font-bold transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
              >
                <Printer className="w-3.5 h-3.5" />
                <span>Print Stand</span>
              </button>
              <button
                onClick={() => setShowFullscreenQR(true)}
                className="py-2 px-3 bg-slate-900 hover:bg-slate-800 text-white rounded-xl border border-slate-700 text-xs font-bold transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
              >
                <Maximize2 className="w-3.5 h-3.5 text-blue-400" />
                <span>Show Large</span>
              </button>
            </div>
          </div>

          {/* Card 2: Popular Jewelry Categories Pulse */}
          <div className="bg-[#050b18] rounded-2xl border border-slate-800 p-5 shadow-xl space-y-3.5">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-7 h-7 rounded-lg bg-blue-950 text-blue-400 flex items-center justify-center border border-blue-800">
                  <Gem className="w-4 h-4" />
                </div>
                <h3 className="text-sm font-black text-white tracking-tight">Jewelry Interests</h3>
              </div>
              <button
                onClick={() => onNavigateTab('categories')}
                className="text-xs text-blue-400 hover:underline font-bold cursor-pointer"
              >
                Manage
              </button>
            </div>

            <div className="space-y-2.5">
              {categoryRanking.length > 0 ? (
                categoryRanking.map((item, idx) => (
                  <div key={idx} className="space-y-1">
                    <div className="flex items-center justify-between text-xs">
                      <span className="font-semibold text-slate-300 truncate">{item.name}</span>
                      <span className="font-mono text-blue-400 text-[11px]">{item.count} ({item.percent}%)</span>
                    </div>
                    <div className="w-full h-1.5 bg-slate-900 rounded-full overflow-hidden border border-slate-800">
                      <div
                        className="h-full bg-gradient-to-r from-blue-600 to-indigo-500 rounded-full"
                        style={{ width: `${Math.max(item.percent, 8)}%` }}
                      />
                    </div>
                  </div>
                ))
              ) : (
                <p className="text-xs text-slate-400 py-3 text-center">
                  Add categories or customer interests to see trends.
                </p>
              )}
            </div>
          </div>

          {/* Card 3: Quick Keyboard & Navigation Dock */}
          <div className="bg-[#050b18] rounded-2xl border border-slate-800 p-4 shadow-xl space-y-2">
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
              Quick Counter Dock
            </span>

            <div className="grid grid-cols-2 gap-2 text-xs">
              <button
                onClick={() => onNavigateTab('customers')}
                className="p-2.5 rounded-xl bg-black/60 hover:bg-slate-900 border border-slate-800 text-left transition-colors flex items-center justify-between cursor-pointer group"
              >
                <div className="flex items-center gap-2">
                  <Users className="w-3.5 h-3.5 text-blue-400" />
                  <span className="font-bold text-slate-200 group-hover:text-white">Directory</span>
                </div>
                <ChevronRight className="w-3 h-3 text-slate-600 group-hover:text-white transition-colors" />
              </button>

              <button
                onClick={() => onNavigateTab('import')}
                className="p-2.5 rounded-xl bg-black/60 hover:bg-slate-900 border border-slate-800 text-left transition-colors flex items-center justify-between cursor-pointer group"
              >
                <div className="flex items-center gap-2">
                  <Upload className="w-3.5 h-3.5 text-blue-400" />
                  <span className="font-bold text-slate-200 group-hover:text-white">Import</span>
                </div>
                <ChevronRight className="w-3 h-3 text-slate-600 group-hover:text-white transition-colors" />
              </button>

              <button
                onClick={() => onNavigateTab('analytics')}
                className="p-2.5 rounded-xl bg-black/60 hover:bg-slate-900 border border-slate-800 text-left transition-colors flex items-center justify-between cursor-pointer group"
              >
                <div className="flex items-center gap-2">
                  <BarChart3 className="w-3.5 h-3.5 text-blue-400" />
                  <span className="font-bold text-slate-200 group-hover:text-white">Analysis</span>
                </div>
                <ChevronRight className="w-3 h-3 text-slate-600 group-hover:text-white transition-colors" />
              </button>

              <button
                onClick={() => onNavigateTab('categories')}
                className="p-2.5 rounded-xl bg-black/60 hover:bg-slate-900 border border-slate-800 text-left transition-colors flex items-center justify-between cursor-pointer group"
              >
                <div className="flex items-center gap-2">
                  <Tag className="w-3.5 h-3.5 text-blue-400" />
                  <span className="font-bold text-slate-200 group-hover:text-white">Categories</span>
                </div>
                <ChevronRight className="w-3 h-3 text-slate-600 group-hover:text-white transition-colors" />
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* =========================================================================
          4. FULLSCREEN COUNTER QR MODAL (Instant display for walk-in customer)
      ========================================================================= */}
      {showFullscreenQR && (
        <div
          className="fixed inset-0 z-50 bg-black/90 backdrop-blur-md flex items-center justify-center p-4"
          onClick={() => setShowFullscreenQR(false)}
        >
          <div
            className="bg-[#050b18] border-2 border-blue-600/80 rounded-3xl p-6 sm:p-8 max-w-md w-full text-center space-y-5 shadow-2xl relative"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Close button */}
            <button
              onClick={() => setShowFullscreenQR(false)}
              className="absolute top-4 right-4 p-2 rounded-full bg-slate-900 hover:bg-slate-800 text-slate-400 hover:text-white border border-slate-700 transition-colors cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>

            <div className="space-y-1">
              <span className="text-[11px] font-black uppercase tracking-widest text-blue-400">
                Official Customer Intake
              </span>
              <h2 className="text-2xl font-black text-white">
                {businessName}
              </h2>
              <p className="text-xs text-slate-300">
                Point any smartphone camera to register digital membership & warranty
              </p>
            </div>

            {/* QR Code Container */}
            <div className="p-4 bg-white rounded-2xl inline-block shadow-2xl">
              {qrStandeeInfo?.qrDataUrl ? (
                <img
                  src={qrStandeeInfo.qrDataUrl}
                  alt="Giri Jewels Walk-in QR"
                  className="w-56 h-56 sm:w-64 sm:h-64 object-contain"
                />
              ) : (
                <div className="w-56 h-56 flex items-center justify-center">
                  <RefreshCw className="w-8 h-8 text-blue-600 animate-spin" />
                </div>
              )}
            </div>

            <div className="space-y-2">
              <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-blue-950 border border-blue-800 text-xs text-blue-300 font-semibold">
                <Smartphone className="w-3.5 h-3.5 text-blue-400" />
                <span>No app download needed • Works instantly</span>
              </div>
              <div>
                <button
                  onClick={() => {
                    setShowFullscreenQR(false);
                    onNavigateTab('qr_common');
                  }}
                  className="text-xs text-slate-400 hover:text-blue-300 underline cursor-pointer"
                >
                  Print physical acrylic standee or counter sticker →
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
