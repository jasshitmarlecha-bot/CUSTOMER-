import React, { useState } from 'react';
import {
  Gem,
  Lock,
  Key,
  Mail,
  Eye,
  EyeOff,
  AlertCircle,
  CheckCircle2,
  ArrowRight,
  RefreshCw,
  ShieldCheck,
  ArrowLeft
} from 'lucide-react';
import { resetPassword } from '../../api/client.ts';
import { StaffUser } from '../../types/index.ts';

interface AuthPortalProps {
  onLoginSuccess: (user: StaffUser) => void;
  onLoginSubmit: (email: string, password?: string) => Promise<StaffUser>;
  businessName?: string;
}

export const AuthPortal: React.FC<AuthPortalProps> = ({
  onLoginSuccess,
  onLoginSubmit,
  businessName = 'Giri Jewels'
}) => {
  const [viewMode, setViewMode] = useState<'login' | 'forgot_password'>('login');

  // Login form state
  const [loginEmail, setLoginEmail] = useState('');
  const [loginPassword, setLoginPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [isLoggingIn, setIsLoggingIn] = useState(false);
  const [loginError, setLoginError] = useState<string | null>(null);

  // Forgot / Reset Password state
  const [resetEmail, setResetEmail] = useState('');
  const [recoveryPin, setRecoveryPin] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showNewPassword, setShowNewPassword] = useState(false);
  const [isResetting, setIsResetting] = useState(false);
  const [resetSuccessMessage, setResetSuccessMessage] = useState<string | null>(null);
  const [resetError, setResetError] = useState<string | null>(null);

  // Handle Login
  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError(null);

    const emailTrimmed = loginEmail.trim();
    const passTrimmed = loginPassword.trim();

    if (!emailTrimmed) {
      setLoginError('Please enter your registered email address or username.');
      return;
    }

    if (!passTrimmed) {
      setLoginError('Please enter your account password.');
      return;
    }

    setIsLoggingIn(true);

    try {
      const user = await onLoginSubmit(emailTrimmed, passTrimmed);
      onLoginSuccess(user);
    } catch (err: any) {
      setLoginError(err.message || 'Invalid email or password. Access denied.');
    } finally {
      setIsLoggingIn(false);
    }
  };

  // Handle Password Reset
  const handleResetPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setResetError(null);
    setResetSuccessMessage(null);

    if (!resetEmail.trim()) {
      setResetError('Please enter your account email address.');
      return;
    }
    if (!recoveryPin.trim()) {
      setResetError('Please enter the Store Master Recovery PIN (e.g. GIRI-7788).');
      return;
    }
    if (!newPassword.trim() || newPassword.trim().length < 4) {
      setResetError('New password must be at least 4 characters long.');
      return;
    }
    if (newPassword !== confirmPassword) {
      setResetError('New password and confirmation do not match.');
      return;
    }

    setIsResetting(true);
    try {
      const result = await resetPassword(resetEmail.trim(), recoveryPin.trim(), newPassword.trim());
      setResetSuccessMessage(result.message || 'Password updated successfully! You can now sign in.');
      setLoginEmail(resetEmail.trim());
      setLoginPassword(newPassword.trim());
    } catch (err: any) {
      setResetError(err.message || 'Failed to reset password. Please verify the master recovery PIN.');
    } finally {
      setIsResetting(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#030712] text-white flex flex-col justify-center items-center p-4 font-sans selection:bg-blue-600 selection:text-white">
      {/* Background Subtle Ambient Glow in Navy Blue */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-blue-600/10 rounded-full blur-3xl pointer-events-none" />

      <div className="w-full max-w-md bg-[#070e1f] border border-slate-800 rounded-3xl shadow-2xl overflow-hidden relative z-10">
        {/* Brand Header */}
        <div className="bg-gradient-to-br from-black via-[#060e22] to-blue-950/60 p-6 text-center border-b border-slate-800 relative space-y-2">
          <div className="w-14 h-14 rounded-2xl bg-blue-600 flex items-center justify-center mx-auto shadow-lg shadow-blue-900/40 border border-blue-400/40">
            <Gem className="w-7 h-7 text-white" />
          </div>
          <h1 className="text-2xl font-black tracking-tight text-white uppercase">
            {businessName}
          </h1>
          <div className="inline-flex items-center gap-1.5 px-3 py-0.5 rounded-full bg-blue-950 text-blue-300 text-[10px] font-bold tracking-wider uppercase border border-blue-800">
            <Lock className="w-3 h-3 text-blue-400" />
            <span>Store Staff & Admin Portal</span>
          </div>
        </div>

        {/* ========================================================================= */}
        {/* MODE 1: CREDENTIAL LOGIN                                                  */}
        {/* ========================================================================= */}
        {viewMode === 'login' ? (
          <div className="p-6 space-y-5">
            {loginError && (
              <div className="p-3.5 bg-red-950/80 border border-red-800 rounded-xl text-xs text-red-200 flex items-start gap-2.5 animate-in fade-in">
                <AlertCircle className="w-4 h-4 text-red-400 shrink-0 mt-0.5" />
                <div className="space-y-1 flex-1">
                  <p className="font-semibold text-red-300">{loginError}</p>
                  <button
                    type="button"
                    onClick={() => {
                      setResetEmail(loginEmail);
                      setViewMode('forgot_password');
                    }}
                    className="block text-[11px] text-blue-400 hover:text-blue-300 font-medium hover:underline cursor-pointer"
                  >
                    Forgot or need to reset password with Master PIN?
                  </button>
                </div>
              </div>
            )}

            {/* Login Form */}
            <form onSubmit={handleLogin} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                  Email Address or Username
                </label>
                <div className="relative">
                  <Mail className="w-4 h-4 text-slate-500 absolute left-3.5 top-3" />
                  <input
                    type="text"
                    required
                    autoFocus
                    value={loginEmail}
                    onChange={(e) => setLoginEmail(e.target.value)}
                    placeholder="e.g. admin@girijewels.com or staff@girijewels.com"
                    className="w-full text-xs pl-10 pr-3 py-2.5 bg-black border border-slate-700 rounded-xl text-white placeholder:text-slate-600 focus:outline-none focus:ring-1 focus:ring-blue-500 font-medium"
                  />
                </div>
              </div>

              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label className="text-xs font-semibold text-slate-300">
                    Account Password
                  </label>
                  <button
                    type="button"
                    onClick={() => {
                      setResetEmail(loginEmail);
                      setViewMode('forgot_password');
                    }}
                    className="text-[11px] text-blue-400 hover:text-blue-300 hover:underline cursor-pointer font-medium"
                  >
                    Forgot Password?
                  </button>
                </div>
                <div className="relative">
                  <Key className="w-4 h-4 text-slate-500 absolute left-3.5 top-3" />
                  <input
                    type={showPassword ? 'text' : 'password'}
                    required
                    value={loginPassword}
                    onChange={(e) => setLoginPassword(e.target.value)}
                    placeholder="Enter account password..."
                    className="w-full text-xs pl-10 pr-10 py-2.5 bg-black border border-slate-700 rounded-xl text-white placeholder:text-slate-600 focus:outline-none focus:ring-1 focus:ring-blue-500 font-medium"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-2.5 text-slate-500 hover:text-white cursor-pointer p-0.5"
                    title={showPassword ? 'Hide password' : 'Show password'}
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              <button
                type="submit"
                disabled={isLoggingIn}
                className="w-full py-3 px-4 bg-blue-600 hover:bg-blue-500 disabled:opacity-50 text-white font-bold text-xs rounded-xl shadow-lg shadow-blue-900/40 active:scale-[0.99] transition-all flex items-center justify-center gap-2 cursor-pointer border border-blue-400/30"
              >
                {isLoggingIn ? (
                  <>
                    <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                    <span>Authenticating Credentials...</span>
                  </>
                ) : (
                  <>
                    <span>Sign In to Management System</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </>
                )}
              </button>
            </form>

            {/* Security Guard Notice */}
            <div className="p-3.5 bg-black/60 border border-slate-800 rounded-2xl text-[11px] text-slate-400 space-y-1.5 flex items-start gap-2.5">
              <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
              <p className="leading-relaxed">
                Role-based privileges (Customer Directory, Data Export, Auto-Merge & Store Settings) are granted strictly by verified credentials.
              </p>
            </div>
          </div>
        ) : (
          /* ========================================================================= */
          /* MODE 2: FORGOT & RESET PASSWORD                                           */
          /* ========================================================================= */
          <div className="p-6 space-y-5">
            <div className="flex items-center gap-2 border-b border-slate-800 pb-3">
              <button
                type="button"
                onClick={() => setViewMode('login')}
                className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
                title="Back to Login"
              >
                <ArrowLeft className="w-4 h-4" />
              </button>
              <div>
                <h2 className="text-sm font-bold text-white flex items-center gap-1.5">
                  <Key className="w-4 h-4 text-blue-400" />
                  <span>Reset Account Password</span>
                </h2>
                <p className="text-[11px] text-slate-400">
                  Authorized recovery using Store Master PIN
                </p>
              </div>
            </div>

            {resetError && (
              <div className="p-3 bg-red-950/80 border border-red-800 rounded-xl text-xs text-red-200 flex items-center gap-2">
                <AlertCircle className="w-4 h-4 text-red-400 shrink-0" />
                <span>{resetError}</span>
              </div>
            )}

            {resetSuccessMessage ? (
              <div className="p-6 bg-black rounded-2xl border border-blue-500/40 text-center space-y-3">
                <div className="w-12 h-12 rounded-full bg-blue-950 text-blue-400 border border-blue-800 flex items-center justify-center mx-auto shadow-inner">
                  <CheckCircle2 className="w-6 h-6" />
                </div>
                <h3 className="text-sm font-bold text-white">Password Reset Successful!</h3>
                <p className="text-xs text-slate-300 leading-relaxed">
                  {resetSuccessMessage}
                </p>
                <button
                  type="button"
                  onClick={() => {
                    setViewMode('login');
                    setResetSuccessMessage(null);
                  }}
                  className="w-full py-2.5 px-4 bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs rounded-xl shadow-md transition-all cursor-pointer"
                >
                  Return to Sign In
                </button>
              </div>
            ) : (
              <form onSubmit={handleResetPassword} className="space-y-3.5">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    Registered Account Email
                  </label>
                  <input
                    type="email"
                    required
                    value={resetEmail}
                    onChange={(e) => setResetEmail(e.target.value)}
                    placeholder="e.g. admin@girijewels.com or staff@girijewels.com"
                    className="w-full text-xs px-3 py-2.5 bg-black border border-slate-700 rounded-xl text-white font-medium focus:outline-none focus:ring-1 focus:ring-blue-500 font-mono"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    Store Master Recovery PIN *
                  </label>
                  <input
                    type="password"
                    required
                    value={recoveryPin}
                    onChange={(e) => setRecoveryPin(e.target.value)}
                    placeholder="Enter Store Master PIN (e.g. GIRI-7788)..."
                    className="w-full text-xs px-3 py-2.5 bg-black border border-slate-700 rounded-xl text-white font-mono focus:outline-none focus:ring-1 focus:ring-blue-500"
                  />
                  <p className="text-[10px] text-slate-500 mt-1">Secret master PIN configured in Store Settings.</p>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    New Password
                  </label>
                  <div className="relative">
                    <input
                      type={showNewPassword ? 'text' : 'password'}
                      required
                      value={newPassword}
                      onChange={(e) => setNewPassword(e.target.value)}
                      placeholder="Minimum 4 characters..."
                      className="w-full text-xs pl-3 pr-10 py-2.5 bg-black border border-slate-700 rounded-xl text-white focus:outline-none focus:ring-1 focus:ring-blue-500 font-medium"
                    />
                    <button
                      type="button"
                      onClick={() => setShowNewPassword(!showNewPassword)}
                      className="absolute right-3 top-2.5 text-slate-500 hover:text-white cursor-pointer p-0.5"
                    >
                      {showNewPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    Confirm New Password
                  </label>
                  <input
                    type="password"
                    required
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    placeholder="Re-type new password..."
                    className="w-full text-xs px-3 py-2.5 bg-black border border-slate-700 rounded-xl text-white focus:outline-none focus:ring-1 focus:ring-blue-500 font-medium"
                  />
                </div>

                <div className="pt-2 flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => setViewMode('login')}
                    className="w-1/3 py-2.5 px-3 text-xs font-semibold text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 rounded-xl transition-colors cursor-pointer"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    disabled={isResetting}
                    className="flex-1 py-2.5 px-3 text-xs font-bold text-white bg-blue-600 hover:bg-blue-500 disabled:opacity-50 rounded-xl shadow-md transition-all flex items-center justify-center gap-1.5 cursor-pointer"
                  >
                    {isResetting ? (
                      <>
                        <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                        <span>Verifying...</span>
                      </>
                    ) : (
                      <span>Reset Password</span>
                    )}
                  </button>
                </div>
              </form>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
