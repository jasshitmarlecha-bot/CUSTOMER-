import React, { useState, useEffect, useRef } from 'react';
import {
  QrCode,
  Printer,
  Download,
  Copy,
  ExternalLink,
  Smartphone,
  Eye,
  BarChart3,
  Clock,
  CheckCircle2,
  Users,
  TrendingUp,
  RefreshCw,
  Check,
  Gem,
  AlertCircle,
  Activity,
  Layers,
  ArrowRight,
  ShieldCheck,
  Sparkles,
  Sliders,
  RotateCcw
} from 'lucide-react';
import {
  getQRStandeeInfo,
  getQRAnalytics,
  recordPublicScan,
  recordPublicInteraction,
  submitPublicIntake,
  clearAllQRScans
} from '../../api/client.ts';
import { QRAnalyticsData, QRScanEvent, Category } from '../../types/index.ts';
import { ConfirmationModal } from '../common/ConfirmationModal.tsx';

export type QRSubTab = 'common_qr' | 'analytics' | 'activity' | 'simulator' | 'print_display';

interface QRIntakePortalViewProps {
  businessName: string;
  categories: Category[];
  initialSubTab?: QRSubTab;
  onRefreshData?: () => void;
}

export const QRIntakePortalView: React.FC<QRIntakePortalViewProps> = ({
  businessName = 'Giri Jewels',
  categories,
  initialSubTab = 'common_qr',
  onRefreshData
}) => {
  const [activeTab, setActiveTab] = useState<QRSubTab>(initialSubTab);
  const [qrDataUrl, setQrDataUrl] = useState<string>('');
  const [targetUrl, setTargetUrl] = useState<string>('');
  const [analytics, setAnalytics] = useState<QRAnalyticsData | null>(null);
  const [analyticsRange, setAnalyticsRange] = useState<'all' | 'today' | '7days' | '30days'>('all');
  const [isLoadingAnalytics, setIsLoadingAnalytics] = useState(false);
  const [copied, setCopied] = useState(false);
  const [activityFilter, setActivityFilter] = useState<'all' | 'completed' | 'dropped'>('all');
  const [showClearConfirm, setShowClearConfirm] = useState(false);

  const handleClearAllQRData = async () => {
    try {
      await clearAllQRScans();
      await loadAnalytics();
      if (onRefreshData) onRefreshData();
    } catch (err) {
      console.error('Failed to clear QR scans', err);
    }
  };

  // Customizer for Print Displays
  const [displayTagline, setDisplayTagline] = useState('Scan with Phone Camera for Instant Digital Intake & Warranty');
  const [displayFormat, setDisplayFormat] = useState<'counter_stand' | 'table_tent' | 'badge'>('counter_stand');

  // Simulator Form State
  const [simName, setSimName] = useState('');
  const [simPhone, setSimPhone] = useState('');
  const [simEmail, setSimEmail] = useState('');
  const [simCity, setSimCity] = useState('');
  const [simIsSubmitting, setSimIsSubmitting] = useState(false);
  const [simSuccess, setSimSuccess] = useState(false);
  const [simError, setSimError] = useState<string | null>(null);
  const simScanIdRef = useRef<string | null>(null);

  useEffect(() => {
    if (initialSubTab) {
      setActiveTab(initialSubTab);
    }
  }, [initialSubTab]);

  useEffect(() => {
    loadQR();
    loadAnalytics();
  }, [analyticsRange]);

  const loadQR = async () => {
    try {
      const data = await getQRStandeeInfo();
      setQrDataUrl(data.qrDataUrl);
      setTargetUrl(data.targetUrl);
    } catch (err) {
      console.error('Failed to load QR code', err);
    }
  };

  const loadAnalytics = async () => {
    setIsLoadingAnalytics(true);
    try {
      const data = await getQRAnalytics(analyticsRange);
      setAnalytics(data);
    } catch (err) {
      console.error('Failed to load QR analytics', err);
    } finally {
      setIsLoadingAnalytics(false);
    }
  };

  const handleCopyLink = () => {
    navigator.clipboard.writeText(targetUrl || window.location.href);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handlePrint = () => {
    window.print();
  };

  const handleDownloadQR = () => {
    if (!qrDataUrl) return;
    const link = document.createElement('a');
    link.href = qrDataUrl;
    link.download = `${businessName.toLowerCase().replace(/\s+/g, '_')}_showroom_qr.png`;
    link.click();
  };

  // Simulator Actions
  const handleStartSim = async () => {
    setSimSuccess(false);
    setSimError(null);
    setSimName('');
    setSimPhone('');
    setSimEmail('');
    setSimCity('');
    try {
      const res = await recordPublicScan();
      simScanIdRef.current = res.scanId;
    } catch {
      // simulator fallback
    }
  };

  const handleSimInteraction = () => {
    if (simScanIdRef.current) {
      recordPublicInteraction(simScanIdRef.current).catch(() => {});
    }
  };

  const handleSimSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!simName.trim()) {
      setSimError('Please enter a name');
      return;
    }
    if (!simPhone.trim() || simPhone.replace(/\D/g, '').length < 7) {
      setSimError('Please enter a valid phone number');
      return;
    }

    setSimIsSubmitting(true);
    setSimError(null);
    try {
      await submitPublicIntake({
        name: simName.trim(),
        phone: simPhone.trim(),
        email: simEmail.trim() || undefined,
        city: simCity.trim() || undefined,
        scanId: simScanIdRef.current || undefined
      });
      setSimSuccess(true);
      loadAnalytics();
      if (onRefreshData) onRefreshData();
    } catch (err: any) {
      setSimError(err.message || 'Submission failed');
    } finally {
      setSimIsSubmitting(false);
    }
  };

  const filteredScans = (analytics?.recentScans || []).filter(s => {
    if (activityFilter === 'completed') return s.completed;
    if (activityFilter === 'dropped') return !s.completed;
    return true;
  });

  return (
    <div className="space-y-6">
      {/* Top Banner / Breadcrumb Area for QR Management - Navy Blue, Black, White */}
      <div className="bg-[#050b18] border border-blue-900/40 rounded-2xl p-5 shadow-xl space-y-4">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-blue-600/20 border border-blue-500/40 flex items-center justify-center text-blue-400">
                <QrCode className="w-4 h-4" />
              </div>
              <h1 className="text-xl font-bold text-white tracking-tight">Showroom QR Center</h1>
              <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full bg-blue-950 text-blue-300 border border-blue-800">
                All QR Features
              </span>
            </div>
            <p className="text-xs text-slate-300">
              Universal QR code for counter scanning, scan vs. fill analytics, real-time footfall logs, and mobile intake simulator.
            </p>
          </div>

          {/* Quick Metrics Badge */}
          <div className="flex items-center gap-3 bg-black px-4 py-2 rounded-xl border border-slate-800 text-xs">
            <div>
              <span className="text-[10px] text-slate-400 uppercase tracking-wider block">Total Scans</span>
              <span className="font-black text-white text-sm">{analytics?.totalScans ?? 0}</span>
            </div>
            <div className="h-6 w-px bg-slate-800" />
            <div>
              <span className="text-[10px] text-slate-400 uppercase tracking-wider block">Filled Form</span>
              <span className="font-black text-emerald-400 text-sm">{analytics?.totalCompleted ?? 0}</span>
            </div>
            <div className="h-6 w-px bg-slate-800" />
            <div>
              <span className="text-[10px] text-slate-400 uppercase tracking-wider block">Conversion</span>
              <span className="font-black text-blue-400 text-sm">{analytics?.scanToRegRate ?? 0}%</span>
            </div>
          </div>
        </div>

        {/* 5-Item Navigation Tabs for All QR Features */}
        <div className="flex flex-wrap items-center gap-1.5 pt-2 border-t border-slate-800/80">
          <button
            onClick={() => setActiveTab('common_qr')}
            className={`px-3.5 py-2 text-xs font-semibold rounded-xl transition-all flex items-center gap-2 cursor-pointer ${
              activeTab === 'common_qr'
                ? 'bg-blue-600 text-white font-bold shadow-md shadow-blue-600/30'
                : 'text-slate-300 hover:text-white hover:bg-slate-800'
            }`}
          >
            <QrCode className="w-3.5 h-3.5" />
            <span>Common QR Code</span>
          </button>

          <button
            onClick={() => setActiveTab('analytics')}
            className={`px-3.5 py-2 text-xs font-semibold rounded-xl transition-all flex items-center gap-2 cursor-pointer ${
              activeTab === 'analytics'
                ? 'bg-blue-600 text-white font-bold shadow-md shadow-blue-600/30'
                : 'text-slate-300 hover:text-white hover:bg-slate-800'
            }`}
          >
            <BarChart3 className="w-3.5 h-3.5" />
            <span>Scan vs. Fill Analytics</span>
          </button>

          <button
            onClick={() => setActiveTab('activity')}
            className={`px-3.5 py-2 text-xs font-semibold rounded-xl transition-all flex items-center gap-2 cursor-pointer ${
              activeTab === 'activity'
                ? 'bg-blue-600 text-white font-bold shadow-md shadow-blue-600/30'
                : 'text-slate-300 hover:text-white hover:bg-slate-800'
            }`}
          >
            <Activity className="w-3.5 h-3.5" />
            <span>Live Scan Activity</span>
          </button>

          <button
            onClick={() => {
              setActiveTab('simulator');
              handleStartSim();
            }}
            className={`px-3.5 py-2 text-xs font-semibold rounded-xl transition-all flex items-center gap-2 cursor-pointer ${
              activeTab === 'simulator'
                ? 'bg-blue-600 text-white font-bold shadow-md shadow-blue-600/30'
                : 'text-slate-300 hover:text-white hover:bg-slate-800'
            }`}
          >
            <Smartphone className="w-3.5 h-3.5" />
            <span>Test Mobile Intake</span>
          </button>

          <button
            onClick={() => setActiveTab('print_display')}
            className={`px-3.5 py-2 text-xs font-semibold rounded-xl transition-all flex items-center gap-2 cursor-pointer ${
              activeTab === 'print_display'
                ? 'bg-blue-600 text-white font-bold shadow-md shadow-blue-600/30'
                : 'text-slate-300 hover:text-white hover:bg-slate-800'
            }`}
          >
            <Printer className="w-3.5 h-3.5" />
            <span>Counter Display & Print</span>
          </button>
        </div>
      </div>

      {/* ========================================================================= */}
      {/* FEATURE 1: COMMON QR CODE DISPLAY & QUICK ACTIONS                         */}
      {/* ========================================================================= */}
      {activeTab === 'common_qr' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          {/* Left: Summary & Instructions */}
          <div className="lg:col-span-5 bg-[#050b18] p-5 rounded-2xl border border-slate-800 shadow-md space-y-4">
            <div className="flex items-center gap-2.5 border-b border-slate-800 pb-3">
              <Gem className="w-4 h-4 text-blue-400" />
              <h2 className="text-sm font-bold text-white">Universal Customer Intake QR</h2>
            </div>

            <p className="text-xs text-slate-300 leading-relaxed">
              This single, common QR code is all your showroom needs. Place it at the entrance, billing counter, or jewelry display tables.
            </p>

            <div className="p-3.5 bg-black rounded-xl border border-slate-800 text-xs space-y-2">
              <div className="flex items-center gap-2 font-semibold text-blue-300">
                <CheckCircle2 className="w-4 h-4 text-blue-400" />
                <span>Zero Link Sharing Workflow:</span>
              </div>
              <ul className="space-y-1.5 text-[11px] text-slate-400 pl-4 list-disc">
                <li>Walk-in customer aims their phone camera at the QR code.</li>
                <li>Instant digital intake opens without downloading an app.</li>
                <li>Customer types Name & Phone (no category or notes asked).</li>
                <li>Record appears immediately in your store customer directory.</li>
              </ul>
            </div>

            {/* Quick Actions */}
            <div className="space-y-2 pt-2">
              <button
                onClick={() => setActiveTab('print_display')}
                className="w-full flex items-center justify-center gap-2 py-2.5 px-4 bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs rounded-xl shadow-md transition-all cursor-pointer"
              >
                <Printer className="w-4 h-4" />
                <span>Print Counter Sign / Standee</span>
              </button>

              <div className="grid grid-cols-2 gap-2">
                <button
                  onClick={handleDownloadQR}
                  className="flex items-center justify-center gap-1.5 py-2 px-3 bg-slate-900 hover:bg-slate-800 text-slate-200 text-xs font-semibold rounded-xl border border-slate-700 transition-colors cursor-pointer"
                >
                  <Download className="w-3.5 h-3.5 text-blue-400" />
                  <span>Download PNG</span>
                </button>

                <button
                  onClick={handleCopyLink}
                  className="flex items-center justify-center gap-1.5 py-2 px-3 bg-slate-900 hover:bg-slate-800 text-slate-200 text-xs font-semibold rounded-xl border border-slate-700 transition-colors cursor-pointer"
                >
                  {copied ? (
                    <>
                      <Check className="w-3.5 h-3.5 text-emerald-400" />
                      <span className="text-emerald-300">Copied!</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5 text-slate-400" />
                      <span>Copy Intake URL</span>
                    </>
                  )}
                </button>
              </div>

              <button
                onClick={() => {
                  setActiveTab('simulator');
                  handleStartSim();
                }}
                className="w-full flex items-center justify-center gap-2 py-2.5 px-4 bg-black hover:bg-slate-900 text-blue-300 text-xs font-semibold rounded-xl border border-blue-900/50 transition-all cursor-pointer mt-1"
              >
                <Smartphone className="w-3.5 h-3.5 text-blue-400" />
                <span>Open Mobile Intake Simulator</span>
              </button>
            </div>
          </div>

          {/* Right: High-Res Scannable Display */}
          <div className="lg:col-span-7 flex justify-center">
            <div className="w-full max-w-md bg-white text-slate-900 rounded-3xl p-8 border-4 border-blue-950 shadow-2xl flex flex-col items-center text-center space-y-5">
              <div className="space-y-1">
                <div className="w-12 h-12 rounded-2xl bg-blue-600 text-white flex items-center justify-center mx-auto shadow-md">
                  <Gem className="w-6 h-6" />
                </div>
                <h3 className="text-2xl font-black tracking-tight text-slate-950 uppercase">
                  {businessName}
                </h3>
                <p className="text-xs font-bold text-blue-900 tracking-wider uppercase">
                  Fine Jewelry & Exclusive Showroom
                </p>
              </div>

              {/* QR Image */}
              <div className="p-4 bg-slate-50 rounded-2xl border-2 border-dashed border-slate-300 flex items-center justify-center shadow-inner">
                {qrDataUrl ? (
                  <img
                    src={qrDataUrl}
                    alt="Showroom Intake QR"
                    className="w-64 h-64 object-contain rounded-lg"
                  />
                ) : (
                  <div className="w-64 h-64 flex items-center justify-center text-slate-400 text-xs">
                    Generating high-res QR...
                  </div>
                )}
              </div>

              <div className="space-y-2">
                <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-slate-950 text-white text-xs font-bold">
                  <Smartphone className="w-3.5 h-3.5 text-blue-400" />
                  <span>Scan with Phone Camera</span>
                </div>
                <p className="text-xs text-slate-600 max-w-xs mx-auto">
                  Open your camera and scan to register directly at the counter.
                </p>
              </div>

              <div className="w-full pt-3 border-t border-slate-200 flex items-center justify-between text-[10px] text-slate-500 font-medium">
                <span>Fast Billing</span>
                <span>•</span>
                <span>Zero Manual Links</span>
                <span>•</span>
                <span>Warranty Lookup</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* FEATURE 2: SCAN VS. FILL CONVERSION ANALYSIS                              */}
      {/* ========================================================================= */}
      {activeTab === 'analytics' && (
        <div className="space-y-6">
          {/* Range Switcher */}
          <div className="flex items-center justify-between bg-[#050b18] p-4 rounded-xl border border-slate-800">
            <div>
              <h2 className="text-sm font-bold text-white flex items-center gap-2">
                <BarChart3 className="w-4 h-4 text-blue-400" />
                <span>Scan-to-Registration Conversion Funnel</span>
              </h2>
              <p className="text-xs text-slate-400">
                Detailed comparison of how many people scanned vs. how many filled and submitted.
              </p>
            </div>

            <div className="flex items-center gap-1.5 bg-black p-1 rounded-lg border border-slate-800 text-xs">
              {(['all', '30days', '7days', 'today'] as const).map((r) => (
                <button
                  key={r}
                  onClick={() => setAnalyticsRange(r)}
                  className={`px-2.5 py-1 rounded-md font-semibold capitalize transition-all cursor-pointer ${
                    analyticsRange === r
                      ? 'bg-blue-600 text-white'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  {r === 'all' ? 'All Time' : r === '30days' ? 'Last 30D' : r === '7days' ? 'Last 7D' : 'Today'}
                </button>
              ))}
            </div>
          </div>

          {/* 4 Conversion Metrics */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="bg-[#050b18] p-4 rounded-xl border border-slate-800 shadow-md space-y-1">
              <div className="flex items-center justify-between text-slate-400 text-xs">
                <span>1. Scanned QR</span>
                <QrCode className="w-4 h-4 text-blue-400" />
              </div>
              <p className="text-2xl font-black text-white">{analytics?.totalScans ?? 0}</p>
              <p className="text-[11px] text-slate-500">Walk-in visitors with phone camera</p>
            </div>

            <div className="bg-[#050b18] p-4 rounded-xl border border-slate-800 shadow-md space-y-1">
              <div className="flex items-center justify-between text-slate-400 text-xs">
                <span>2. Started Typing</span>
                <Eye className="w-4 h-4 text-blue-400" />
              </div>
              <p className="text-2xl font-black text-white">{analytics?.totalStarted ?? 0}</p>
              <p className="text-[11px] text-slate-500">Opened form and began entry</p>
            </div>

            <div className="bg-[#050b18] p-4 rounded-xl border border-slate-800 shadow-md space-y-1">
              <div className="flex items-center justify-between text-slate-400 text-xs">
                <span>3. Completed Intake</span>
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
              </div>
              <p className="text-2xl font-black text-emerald-400">{analytics?.totalCompleted ?? 0}</p>
              <p className="text-[11px] text-emerald-500/80">Saved to store customer directory</p>
            </div>

            <div className="bg-[#050b18] p-4 rounded-xl border border-slate-800 shadow-md space-y-1">
              <div className="flex items-center justify-between text-slate-400 text-xs">
                <span>Scan Conversion Rate</span>
                <TrendingUp className="w-4 h-4 text-blue-400" />
              </div>
              <p className="text-2xl font-black text-blue-400">{analytics?.scanToRegRate ?? 0}%</p>
              <p className="text-[11px] text-slate-500">
                {analytics?.startToCompleteRate ?? 0}% form completion rate
              </p>
            </div>
          </div>

          {/* Visual 3-Step Funnel Chart */}
          <div className="bg-[#050b18] p-5 rounded-2xl border border-slate-800 shadow-md space-y-4">
            <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider">
              Intake Conversion Progression
            </h3>

            <div className="space-y-3">
              {/* Step 1 */}
              <div>
                <div className="flex justify-between text-xs font-medium mb-1">
                  <span className="text-white">Step 1: Scanned QR at Counter</span>
                  <span className="text-slate-400">{analytics?.totalScans ?? 0} scans (100%)</span>
                </div>
                <div className="w-full h-3 bg-black rounded-full overflow-hidden border border-slate-800">
                  <div className="h-full bg-blue-600 rounded-full w-full" />
                </div>
              </div>

              {/* Step 2 */}
              <div>
                <div className="flex justify-between text-xs font-medium mb-1">
                  <span className="text-white">Step 2: Touched & Interacted with Form</span>
                  <span className="text-slate-400">
                    {analytics?.totalStarted ?? 0} users ({analytics?.totalScans ? Math.round(((analytics?.totalStarted ?? 0) / analytics.totalScans) * 100) : 0}%)
                  </span>
                </div>
                <div className="w-full h-3 bg-black rounded-full overflow-hidden border border-slate-800">
                  <div
                    className="h-full bg-blue-400 rounded-full transition-all"
                    style={{
                      width: `${analytics?.totalScans ? Math.round(((analytics?.totalStarted ?? 0) / analytics.totalScans) * 100) : 0}%`
                    }}
                  />
                </div>
              </div>

              {/* Step 3 */}
              <div>
                <div className="flex justify-between text-xs font-medium mb-1">
                  <span className="text-emerald-400 font-semibold">Step 3: Registered Customer</span>
                  <span className="text-emerald-400 font-bold">
                    {analytics?.totalCompleted ?? 0} customers ({analytics?.scanToRegRate ?? 0}% final conversion)
                  </span>
                </div>
                <div className="w-full h-3 bg-black rounded-full overflow-hidden border border-slate-800">
                  <div
                    className="h-full bg-emerald-500 rounded-full transition-all"
                    style={{ width: `${analytics?.scanToRegRate ?? 0}%` }}
                  />
                </div>
              </div>
            </div>
          </div>

          {/* Deep Breakdown Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            {/* Device & OS Breakdown */}
            <div className="lg:col-span-6 bg-[#050b18] p-5 rounded-2xl border border-slate-800 shadow-md space-y-4">
              <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                <div className="flex items-center gap-2">
                  <Smartphone className="w-4 h-4 text-blue-400" />
                  <h3 className="text-sm font-bold text-white">Visitor Phones & Operating Systems</h3>
                </div>
                <span className="text-xs text-slate-400">{analytics?.uniqueVisitors ?? 0} devices</span>
              </div>

              <div className="space-y-3">
                {analytics?.deviceBreakdown && analytics.deviceBreakdown.length > 0 ? (
                  analytics.deviceBreakdown.map((item, idx) => (
                    <div key={idx} className="space-y-1">
                      <div className="flex justify-between text-xs font-medium">
                        <span className="text-slate-200">{item.name}</span>
                        <span className="text-slate-400">{item.count} scans ({item.percentage}%)</span>
                      </div>
                      <div className="w-full h-2 bg-slate-800 rounded-full overflow-hidden">
                        <div
                          className="h-full bg-blue-500 rounded-full transition-all"
                          style={{ width: `${item.percentage}%` }}
                        />
                      </div>
                    </div>
                  ))
                ) : (
                  <p className="text-xs text-slate-500 py-4 text-center">Scan data will appear here.</p>
                )}
              </div>
            </div>

            {/* Peak Scanning Hours */}
            <div className="lg:col-span-6 bg-[#050b18] p-5 rounded-2xl border border-slate-800 shadow-md space-y-4">
              <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                <div className="flex items-center gap-2">
                  <Clock className="w-4 h-4 text-blue-400" />
                  <h3 className="text-sm font-bold text-white">Peak Scanning Hours</h3>
                </div>
                <span className="text-xs text-slate-400">Avg Intake: {analytics?.avgTimeSeconds ?? 35}s</span>
              </div>

              <div className="space-y-3">
                {analytics?.peakHours && analytics.peakHours.length > 0 ? (
                  analytics.peakHours.slice(0, 6).map((hour, idx) => {
                    const maxScans = Math.max(...analytics.peakHours.map(h => h.scans), 1);
                    const pct = Math.round((hour.scans / maxScans) * 100);
                    return (
                      <div key={idx} className="space-y-1">
                        <div className="flex justify-between text-xs font-medium">
                          <span className="text-slate-200">{hour.label}</span>
                          <span className="text-blue-400 font-semibold">{hour.scans} scans</span>
                        </div>
                        <div className="w-full h-2 bg-slate-800 rounded-full overflow-hidden">
                          <div
                            className="h-full bg-blue-500 rounded-full transition-all"
                            style={{ width: `${pct}%` }}
                          />
                        </div>
                      </div>
                    );
                  })
                ) : (
                  <p className="text-xs text-slate-500 py-4 text-center">Peak hour records will show as visitors scan.</p>
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* FEATURE 3: LIVE QR SCAN ACTIVITY AUDIT LOG                                */}
      {/* ========================================================================= */}
      {activeTab === 'activity' && (
        <div className="bg-[#050b18] p-5 rounded-2xl border border-slate-800 shadow-md space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-3">
            <div>
              <h2 className="text-sm font-bold text-white flex items-center gap-2">
                <Activity className="w-4 h-4 text-blue-400" />
                <span>Real-Time QR Scan Activity Stream</span>
              </h2>
              <p className="text-xs text-slate-400">
                Audit trail of each walk-in visitor camera scan, form interactions, and completion status.
              </p>
            </div>

            <div className="flex items-center gap-2">
              <div className="flex items-center gap-1 bg-black p-1 rounded-lg border border-slate-800 text-xs">
                <button
                  onClick={() => setActivityFilter('all')}
                  className={`px-2.5 py-1 rounded-md font-semibold cursor-pointer ${
                    activityFilter === 'all' ? 'bg-blue-600 text-white' : 'text-slate-400 hover:text-white'
                  }`}
                >
                  All ({analytics?.recentScans?.length ?? 0})
                </button>
                <button
                  onClick={() => setActivityFilter('completed')}
                  className={`px-2.5 py-1 rounded-md font-semibold cursor-pointer ${
                    activityFilter === 'completed' ? 'bg-blue-600 text-white' : 'text-slate-400 hover:text-white'
                  }`}
                >
                  Completed ({analytics?.totalCompleted ?? 0})
                </button>
                <button
                  onClick={() => setActivityFilter('dropped')}
                  className={`px-2.5 py-1 rounded-md font-semibold cursor-pointer ${
                    activityFilter === 'dropped' ? 'bg-blue-600 text-white' : 'text-slate-400 hover:text-white'
                  }`}
                >
                  Dropped Off ({(analytics?.totalScans ?? 0) - (analytics?.totalCompleted ?? 0)})
                </button>
              </div>

              <button
                onClick={() => setShowClearConfirm(true)}
                className="px-2.5 py-1 text-xs text-amber-300 hover:text-white rounded-lg bg-amber-950/60 hover:bg-amber-900 border border-amber-800/80 transition-colors cursor-pointer flex items-center gap-1"
                title="Clear all QR scan activity and reset logs"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Clear Logs</span>
              </button>

              <button
                onClick={loadAnalytics}
                className="p-1.5 text-slate-400 hover:text-white rounded-lg bg-slate-800 hover:bg-slate-700 transition-colors cursor-pointer"
                title="Refresh scan feed"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${isLoadingAnalytics ? 'animate-spin' : ''}`} />
              </button>
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="text-slate-400 border-b border-slate-800 bg-black">
                  <th className="py-2.5 px-3">Scan Time</th>
                  <th className="py-2.5 px-3">Device & OS</th>
                  <th className="py-2.5 px-3">Form Interaction</th>
                  <th className="py-2.5 px-3">Outcome</th>
                  <th className="py-2.5 px-3 text-right">Time on Form</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {filteredScans.length > 0 ? (
                  filteredScans.map((scan) => (
                    <tr key={scan.id} className="hover:bg-slate-800/40 transition-colors">
                      <td className="py-2 px-3 text-slate-300">
                        {new Date(scan.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
                        <span className="text-[10px] text-slate-500 block">
                          {new Date(scan.timestamp).toLocaleDateString()}
                        </span>
                      </td>
                      <td className="py-2 px-3 text-slate-200">
                        <span className="font-semibold">{scan.os}</span>
                        <span className="text-[10px] text-slate-500 block capitalize">{scan.deviceType}</span>
                      </td>
                      <td className="py-2 px-3">
                        {scan.startedFilling ? (
                          <span className="px-2 py-0.5 rounded-full bg-blue-950 text-blue-300 text-[10px] font-semibold border border-blue-800">
                            Started Typing
                          </span>
                        ) : (
                          <span className="text-slate-500 text-[10px]">Opened without typing</span>
                        )}
                      </td>
                      <td className="py-2 px-3">
                        {scan.completed ? (
                          <span className="px-2 py-0.5 rounded-full bg-emerald-950 text-emerald-300 text-[10px] font-bold border border-emerald-800 inline-flex items-center gap-1">
                            <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                            <span>Registered</span>
                          </span>
                        ) : (
                          <span className="px-2 py-0.5 rounded-full bg-slate-800 text-slate-400 text-[10px] font-medium">
                            Left / Dropped Off
                          </span>
                        )}
                      </td>
                      <td className="py-2 px-3 text-right text-slate-300 font-mono">
                        {scan.timeSpentSeconds ? `${scan.timeSpentSeconds}s` : '-'}
                      </td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan={5} className="py-8 text-center text-slate-500">
                      No matching scan activity recorded.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* FEATURE 4: INTERACTIVE MOBILE INTAKE SIMULATOR                            */}
      {/* ========================================================================= */}
      {activeTab === 'simulator' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          {/* Simulator Controls & Explainer */}
          <div className="lg:col-span-5 bg-[#050b18] p-5 rounded-2xl border border-slate-800 shadow-md space-y-4">
            <div className="flex items-center gap-2 border-b border-slate-800 pb-3">
              <Smartphone className="w-4 h-4 text-blue-400" />
              <h2 className="text-sm font-bold text-white">Customer Phone Simulator</h2>
            </div>

            <p className="text-xs text-slate-300 leading-relaxed">
              This interactive simulator replicates exactly what walk-in customers experience on their iPhone or Android screen after scanning the showroom QR code.
            </p>

            <div className="p-3 bg-black rounded-xl border border-slate-800 text-xs space-y-2 text-slate-300">
              <p className="font-semibold text-blue-300">Features Tested in Real-Time:</p>
              <ul className="space-y-1 text-[11px] text-slate-400 list-disc pl-4">
                <li>Zero login required for customers</li>
                <li>No category selector or staff notes asked</li>
                <li>Real-time scan event recording in analytics</li>
                <li>Direct insertion into Customer Directory upon submit</li>
              </ul>
            </div>

            <div className="pt-2">
              <button
                type="button"
                onClick={handleStartSim}
                className="w-full py-2 px-3 text-xs font-semibold text-slate-200 bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded-xl transition-colors cursor-pointer"
              >
                Reset Simulator Session
              </button>
            </div>
          </div>

          {/* Interactive Phone Frame */}
          <div className="lg:col-span-7 flex justify-center">
            <div className="w-full max-w-sm bg-black rounded-[40px] p-4 border-4 border-slate-800 shadow-2xl relative">
              {/* Speaker notch */}
              <div className="w-24 h-4 bg-slate-900 rounded-full mx-auto mb-3" />

              {/* Phone Screen */}
              <div className="bg-[#050b18] rounded-[28px] overflow-hidden border border-slate-800 min-h-[500px] flex flex-col font-sans">
                {/* Phone Header */}
                <div className="bg-gradient-to-br from-blue-900 via-blue-950 to-black text-white p-5 text-center space-y-1.5 border-b border-blue-900/40">
                  <div className="w-10 h-10 rounded-xl bg-blue-600 flex items-center justify-center mx-auto shadow-md">
                    <Gem className="w-5 h-5 text-white" />
                  </div>
                  <h3 className="text-base font-black tracking-tight">{businessName}</h3>
                  <p className="text-[10px] text-blue-200 font-medium">Showroom Customer Digital Intake</p>
                </div>

                {/* Form or Success State */}
                {simSuccess ? (
                  <div className="p-6 text-center space-y-3 my-auto">
                    <div className="w-12 h-12 rounded-full bg-emerald-950 text-emerald-400 border border-emerald-800 flex items-center justify-center mx-auto">
                      <CheckCircle2 className="w-7 h-7" />
                    </div>
                    <h4 className="text-sm font-bold text-white">Registration Complete!</h4>
                    <p className="text-xs text-slate-300">
                      Thank you, <span className="font-semibold text-blue-400">{simName}</span>. Your record is now active at the counter.
                    </p>
                    <button
                      type="button"
                      onClick={handleStartSim}
                      className="text-xs text-blue-400 hover:underline pt-2 cursor-pointer"
                    >
                      Test another entry
                    </button>
                  </div>
                ) : (
                  <form onSubmit={handleSimSubmit} className="p-5 space-y-3.5 flex-1 flex flex-col justify-between">
                    {simError && (
                      <div className="p-2 bg-red-950/80 border border-red-800 rounded-lg text-[11px] text-red-200">
                        {simError}
                      </div>
                    )}

                    <div className="space-y-2.5">
                      <div>
                        <label className="block text-[11px] font-semibold text-slate-300 mb-1">
                          Full Name <span className="text-blue-400">*</span>
                        </label>
                        <input
                          type="text"
                          required
                          value={simName}
                          onFocus={handleSimInteraction}
                          onChange={(e) => {
                            setSimName(e.target.value);
                            handleSimInteraction();
                          }}
                          placeholder="e.g. Priyadarshini Sharma"
                          className="w-full text-xs px-3 py-2 bg-black border border-slate-700 rounded-lg text-white placeholder:text-slate-600 focus:outline-none focus:ring-1 focus:ring-blue-500"
                        />
                      </div>

                      <div>
                        <label className="block text-[11px] font-semibold text-slate-300 mb-1">
                          Mobile Phone <span className="text-blue-400">*</span>
                        </label>
                        <input
                          type="tel"
                          required
                          value={simPhone}
                          onFocus={handleSimInteraction}
                          onChange={(e) => {
                            setSimPhone(e.target.value);
                            handleSimInteraction();
                          }}
                          placeholder="e.g. 9845012345"
                          className="w-full text-xs px-3 py-2 bg-black border border-slate-700 rounded-lg text-white placeholder:text-slate-600 focus:outline-none focus:ring-1 focus:ring-blue-500"
                        />
                      </div>

                      <div>
                        <label className="block text-[11px] font-semibold text-slate-300 mb-1">
                          Email (Optional)
                        </label>
                        <input
                          type="email"
                          value={simEmail}
                          onFocus={handleSimInteraction}
                          onChange={(e) => setSimEmail(e.target.value)}
                          placeholder="e.g. priya@example.com"
                          className="w-full text-xs px-3 py-2 bg-black border border-slate-700 rounded-lg text-white placeholder:text-slate-600 focus:outline-none focus:ring-1 focus:ring-blue-500"
                        />
                      </div>

                      <div>
                        <label className="block text-[11px] font-semibold text-slate-300 mb-1">
                          City (Optional)
                        </label>
                        <input
                          type="text"
                          value={simCity}
                          onFocus={handleSimInteraction}
                          onChange={(e) => setSimCity(e.target.value)}
                          placeholder="e.g. Trivandrum"
                          className="w-full text-xs px-3 py-2 bg-black border border-slate-700 rounded-lg text-white placeholder:text-slate-600 focus:outline-none focus:ring-1 focus:ring-blue-500"
                        />
                      </div>
                    </div>

                    <button
                      type="submit"
                      disabled={simIsSubmitting}
                      className="w-full py-2.5 px-3 bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs rounded-xl shadow-md transition-all cursor-pointer"
                    >
                      {simIsSubmitting ? 'Registering...' : 'Submit & Register'}
                    </button>
                  </form>
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* FEATURE 5: COUNTER DISPLAY SIGNAGE & PRINT PRESETS                         */}
      {/* ========================================================================= */}
      {activeTab === 'print_display' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          {/* Signage Customizer Controls */}
          <div className="lg:col-span-5 bg-[#050b18] p-5 rounded-2xl border border-slate-800 shadow-md space-y-4">
            <div className="flex items-center gap-2 border-b border-slate-800 pb-3">
              <Sliders className="w-4 h-4 text-blue-400" />
              <h2 className="text-sm font-bold text-white">Print Layout Customizer</h2>
            </div>

            <div className="space-y-3">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Display Preset Format
                </label>
                <div className="grid grid-cols-3 gap-2 text-xs">
                  <button
                    type="button"
                    onClick={() => setDisplayFormat('counter_stand')}
                    className={`p-2 rounded-xl border text-center transition-all cursor-pointer ${
                      displayFormat === 'counter_stand'
                        ? 'bg-blue-600 text-white font-bold border-blue-500'
                        : 'bg-black border-slate-800 text-slate-400'
                    }`}
                  >
                    Counter Stand (A4)
                  </button>
                  <button
                    type="button"
                    onClick={() => setDisplayFormat('table_tent')}
                    className={`p-2 rounded-xl border text-center transition-all cursor-pointer ${
                      displayFormat === 'table_tent'
                        ? 'bg-blue-600 text-white font-bold border-blue-500'
                        : 'bg-black border-slate-800 text-slate-400'
                    }`}
                  >
                    Table Tent (A5)
                  </button>
                  <button
                    type="button"
                    onClick={() => setDisplayFormat('badge')}
                    className={`p-2 rounded-xl border text-center transition-all cursor-pointer ${
                      displayFormat === 'badge'
                        ? 'bg-blue-600 text-white font-bold border-blue-500'
                        : 'bg-black border-slate-800 text-slate-400'
                    }`}
                  >
                    Compact Sticker
                  </button>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Signage Headline
                </label>
                <input
                  type="text"
                  value={displayTagline}
                  onChange={(e) => setDisplayTagline(e.target.value)}
                  className="w-full text-xs px-3 py-2 bg-black border border-slate-700 rounded-xl text-white font-medium focus:outline-none focus:ring-1 focus:ring-blue-500"
                />
              </div>

              <div className="pt-2">
                <button
                  type="button"
                  onClick={handlePrint}
                  className="w-full py-2.5 px-4 bg-white hover:bg-slate-100 text-slate-950 font-bold text-xs rounded-xl shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer"
                >
                  <Printer className="w-4 h-4 text-blue-600" />
                  <span>Print Display Card Now</span>
                </button>
              </div>
            </div>
          </div>

          {/* Printable Preview Sheet */}
          <div className="lg:col-span-7 flex justify-center">
            <div
              id="printable-display-sign"
              className={`bg-white text-slate-900 rounded-3xl p-8 border-4 border-slate-900 shadow-2xl flex flex-col items-center text-center space-y-4 ${
                displayFormat === 'table_tent'
                  ? 'w-full max-w-sm'
                  : displayFormat === 'badge'
                  ? 'w-full max-w-xs p-5 space-y-2'
                  : 'w-full max-w-md'
              }`}
            >
              <div className="space-y-1">
                <div className="w-12 h-12 rounded-2xl bg-blue-600 text-white flex items-center justify-center mx-auto shadow-md">
                  <Gem className="w-6 h-6" />
                </div>
                <h3 className="text-2xl font-black tracking-tight text-slate-950 uppercase">
                  {businessName}
                </h3>
                <p className="text-xs font-bold text-blue-900 tracking-wider uppercase">
                  Fine Jewelry & Exclusive Showroom
                </p>
              </div>

              {/* QR Image */}
              <div className="p-3 bg-slate-50 rounded-2xl border-2 border-dashed border-slate-300 flex items-center justify-center">
                {qrDataUrl ? (
                  <img
                    src={qrDataUrl}
                    alt="QR Sign"
                    className={displayFormat === 'badge' ? 'w-40 h-40 object-contain' : 'w-56 h-56 object-contain'}
                  />
                ) : (
                  <div className="w-56 h-56 flex items-center justify-center text-slate-400 text-xs">
                    Generating...
                  </div>
                )}
              </div>

              <div className="space-y-1.5 max-w-xs">
                <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-slate-900 text-white text-xs font-bold">
                  <Smartphone className="w-3.5 h-3.5 text-blue-400" />
                  <span>Scan with Phone Camera</span>
                </div>
                <p className="text-xs text-slate-700 font-medium">
                  {displayTagline}
                </p>
              </div>

              <div className="w-full pt-2 border-t border-slate-200 flex items-center justify-between text-[10px] text-slate-500 font-medium">
                <span>Fast Service</span>
                <span>•</span>
                <span>Warranty Security</span>
                <span>•</span>
                <span>Loyalty Benefits</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Showroom QR Logs Clear Confirmation */}
      <ConfirmationModal
        isOpen={showClearConfirm}
        onClose={() => setShowClearConfirm(false)}
        onConfirm={handleClearAllQRData}
        title="Reset & Clear All Showroom QR Scan Activity?"
        description="This will wipe all historical visitor camera scans, drop-off events, and analytics charts. Active customer records and category tags will not be affected."
        confirmText="Clear All QR Logs"
        variant="warning"
        itemDetails={[
          { label: 'Target', value: 'Showroom QR Standee Scans & Device Logs' },
          { label: 'Customer Directory', value: '100% Protected (Not affected)' }
        ]}
      />
    </div>
  );
};
