import React, { useState, useEffect, useRef } from 'react';
import { CheckCircle2, Smartphone, ShieldCheck, Gem, AlertCircle } from 'lucide-react';
import { recordPublicScan, recordPublicInteraction, submitPublicIntake } from '../../api/client.ts';

interface PublicIntakeFormProps {
  businessName?: string;
  onClosePreview?: () => void;
  isPreview?: boolean;
}

export const PublicIntakeForm: React.FC<PublicIntakeFormProps> = ({
  businessName = 'Giri Jewels',
  onClosePreview,
  isPreview = false
}) => {
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [city, setCity] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Scan tracking
  const scanIdRef = useRef<string | null>(null);
  const startTimeRef = useRef<number>(Date.now());
  const hasInteractedRef = useRef<boolean>(false);

  useEffect(() => {
    // 1. Initial QR scan event logging
    recordPublicScan()
      .then((res) => {
        scanIdRef.current = res.scanId;
      })
      .catch((err) => console.warn('QR scan tracking notice:', err));
  }, []);

  const handleInteraction = () => {
    if (!hasInteractedRef.current && scanIdRef.current) {
      hasInteractedRef.current = true;
      recordPublicInteraction(scanIdRef.current).catch(() => {});
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      setErrorMessage('Please enter your full name');
      return;
    }
    const cleanPhone = phone.replace(/\D/g, '');
    if (!phone.trim() || cleanPhone.length < 7) {
      setErrorMessage('Please enter a valid phone number');
      return;
    }

    setIsSubmitting(true);
    setErrorMessage(null);

    const timeSpentSeconds = Math.round((Date.now() - startTimeRef.current) / 1000);

    try {
      const res = await submitPublicIntake({
        name: name.trim(),
        phone: phone.trim(),
        email: email.trim() || undefined,
        address: city.trim() || undefined,
        city: city.trim() || undefined,
        scanId: scanIdRef.current || undefined,
        timeSpentSeconds
      });
      setIsReturning(Boolean(res.isReturningCustomer));
      setSuccessMsg(res.message || 'Registration complete');
      setIsSuccess(true);
    } catch (err: any) {
      setErrorMessage(err.message || 'Failed to submit details. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const [isReturning, setIsReturning] = useState(false);
  const [successMsg, setSuccessMsg] = useState('');

  return (
    <div className="min-h-screen bg-black py-8 px-4 flex flex-col items-center justify-center font-sans selection:bg-blue-600 selection:text-white">
      {isPreview && onClosePreview && (
        <div className="mb-4">
          <button
            onClick={onClosePreview}
            className="px-4 py-1.5 rounded-full bg-slate-900 hover:bg-slate-800 text-slate-200 text-xs font-semibold border border-slate-700 shadow-md transition-colors"
          >
            ← Back to Store Admin Dashboard
          </button>
        </div>
      )}

      <div className="w-full max-w-md bg-[#050b18] rounded-3xl shadow-2xl overflow-hidden border border-blue-900/40">
        {/* Mobile Header Banner - Deep Navy Blue, Black, White */}
        <div className="bg-gradient-to-br from-blue-950 via-[#070e1f] to-black text-white p-6 text-center space-y-2 relative border-b border-blue-900/40">
          <div className="w-14 h-14 rounded-2xl bg-blue-600 flex items-center justify-center mx-auto border border-blue-400/40 shadow-lg shadow-blue-900/50">
            <Gem className="w-7 h-7 text-white" />
          </div>
          <h1 className="text-xl font-black tracking-tight text-white">{businessName}</h1>
          <p className="text-xs text-blue-200/90 font-medium">
            Welcome to our showroom! Complete this fast digital intake for seamless counter service & warranty records.
          </p>
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-blue-950 text-blue-300 text-[10px] font-semibold border border-blue-800">
            <Smartphone className="w-3 h-3 text-blue-400" />
            <span>Showroom QR Verified Session</span>
          </div>
        </div>

        {/* Content */}
        {isSuccess ? (
          <div className="p-8 text-center space-y-4">
            <div className={`w-16 h-16 rounded-full border flex items-center justify-center mx-auto shadow-inner ${
              isReturning
                ? 'bg-blue-950/80 border-blue-500/50 text-blue-400'
                : 'bg-emerald-950/80 border-emerald-500/50 text-emerald-400'
            }`}>
              <CheckCircle2 className="w-10 h-10" />
            </div>
            <h2 className="text-xl font-bold text-white">
              {isReturning ? `Welcome Back, ${name}!` : 'Registration Complete!'}
            </h2>
            <p className="text-sm text-slate-300 leading-relaxed">
              {isReturning
                ? `We recognized your mobile number (${phone}). Your profile has been refreshed and our counter staff is ready to assist you!`
                : `Thank you, ${name}. Your details are now registered with ${businessName}.`}
            </p>
            <div className="p-4 bg-black rounded-2xl border border-slate-800 text-xs text-slate-400 space-y-1 text-left">
              <p className="font-semibold text-white">You are all set at the counter.</p>
              <p>
                {isReturning
                  ? 'Your visit has been recorded with no duplicate records created.'
                  : `Our sales executive can look up your profile by your phone number (${phone}).`}
              </p>
            </div>
            {isPreview ? (
              <button
                onClick={onClosePreview}
                className="w-full py-2.5 px-4 bg-white hover:bg-slate-100 text-slate-950 text-xs font-bold rounded-xl transition-all"
              >
                Return to Admin
              </button>
            ) : (
              <button
                onClick={() => {
                  setIsSuccess(false);
                  setName('');
                  setPhone('');
                  setEmail('');
                  setCity('');
                }}
                className="text-xs font-semibold text-blue-400 hover:underline pt-2 block mx-auto cursor-pointer"
              >
                Register another person
              </button>
            )}
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="p-6 space-y-4">
            {errorMessage && (
              <div className="p-3 bg-red-950/80 border border-red-800 rounded-xl text-xs text-red-200 flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0 text-red-400" />
                <span>{errorMessage}</span>
              </div>
            )}

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                Your Full Name <span className="text-blue-400">*</span>
              </label>
              <input
                type="text"
                required
                value={name}
                onFocus={handleInteraction}
                onChange={(e) => {
                  setName(e.target.value);
                  handleInteraction();
                }}
                placeholder="e.g. Priya Sharma"
                className="w-full text-sm px-3.5 py-2.5 bg-black border border-slate-700 rounded-xl focus:outline-none focus:ring-1 focus:ring-blue-500 text-white placeholder:text-slate-600 font-medium"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                Mobile Phone Number <span className="text-blue-400">*</span>
              </label>
              <input
                type="tel"
                required
                value={phone}
                onFocus={handleInteraction}
                onChange={(e) => {
                  setPhone(e.target.value);
                  handleInteraction();
                }}
                placeholder="e.g. 9845012345"
                className="w-full text-sm px-3.5 py-2.5 bg-black border border-slate-700 rounded-xl focus:outline-none focus:ring-1 focus:ring-blue-500 text-white placeholder:text-slate-600 font-medium"
              />
              <p className="text-[10px] text-slate-500 mt-1">Used for billing lookups, receipts, and order tracking.</p>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                Email Address (Optional)
              </label>
              <input
                type="email"
                value={email}
                onFocus={handleInteraction}
                onChange={(e) => {
                  setEmail(e.target.value);
                  handleInteraction();
                }}
                placeholder="e.g. priya@example.com"
                className="w-full text-sm px-3.5 py-2.5 bg-black border border-slate-700 rounded-xl focus:outline-none focus:ring-1 focus:ring-blue-500 text-white placeholder:text-slate-600 font-medium"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                City / Location (Optional)
              </label>
              <input
                type="text"
                value={city}
                onFocus={handleInteraction}
                onChange={(e) => {
                  setCity(e.target.value);
                  handleInteraction();
                }}
                placeholder="e.g. Trivandrum"
                className="w-full text-sm px-3.5 py-2.5 bg-black border border-slate-700 rounded-xl focus:outline-none focus:ring-1 focus:ring-blue-500 text-white placeholder:text-slate-600 font-medium"
              />
            </div>

            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full py-3 px-4 bg-blue-600 hover:bg-blue-500 text-white font-bold text-sm rounded-xl shadow-lg shadow-blue-600/30 active:scale-[0.99] disabled:opacity-50 transition-all cursor-pointer"
            >
              {isSubmitting ? 'Registering Details...' : 'Submit & Register'}
            </button>

            <div className="flex items-center justify-center gap-1.5 text-[11px] text-slate-500 pt-2">
              <ShieldCheck className="w-3.5 h-3.5 text-blue-400" />
              <span>Direct showroom intake. Your privacy is protected.</span>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};
